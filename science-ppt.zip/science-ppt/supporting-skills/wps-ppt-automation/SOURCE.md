# WPS adapter source

- Upstream: https://github.com/yb2460/harness-anything
- Commit: `e1924f8499ad6aaa11c579d5492205cfaa89c5d6`
- Reviewed source: `WPS/ppt-engine/pptengine/wps.py`
- Download archive SHA-256: `e1034be764126fb24c12d4154e07a520d52b1f69894560b4964646cb7a251d39`
- Upstream license: MIT, Copyright (c) 2026 cli-anything-wps contributors.

`scripts/harness_wps_adapter.py` adapts the upstream `KWPP.Application`,
`Presentations.Open`, `SaveAs`, and owned-presentation close concepts. It removes
the upstream forced process termination and application quit behavior, balances
COM initialization per thread, reuses an available application, and explicitly
uses `ppSaveAsOpenXMLPresentation=24` for legal PPTX output. The independent
`wps_ppt_bridge.py` adds copy isolation, output collision rejection, PNG evidence,
source hashes, and text persistence checks. No upstream assets or other harness
modules are bundled in this auxiliary skill.
