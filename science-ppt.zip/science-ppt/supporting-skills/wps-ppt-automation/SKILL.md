---
name: wps-ppt-automation
description: 使用 WPS 原生命令行、精确文稿 COM 绑定和自有窗口验证辅助科研 PPT 在独立新窗口可见构建，尊重用户焦点与窗口尺寸，完成应用渲染和中文原生文本编辑验证；支持显式选择 PowerPoint。
---

# WPS 科研 PPT 辅助

主技能负责科研内容、图形与布局；此辅助提供 WPS 演示连接、独立窗口可见构建、逐页渲染和原生中文标签编辑的实际证据。读取 [WPS 接入说明](../../references/wps-integration.md)。普通主题和修订使用主技能 `scripts/run_science_ppt.py` 或 MCP `export_scene` 默认完整构建，固定示例用各自完整入口；`scripts/wps_ppt_bridge.py` 只做额外兼容性与编辑验证，不能替代绘制。

- 默认连接 `KWPP.Application`；PowerPoint 必须显式使用 `--engine powerpoint`，结果记录实际引擎。注册检查不启动应用，也不扫描软件安装目录。
- 新制作通过 `scripts/wps_owned_window.py` 使用真实 `wpp.exe /n <owned-blank.pptx>` 创建独立顶层窗口；从 ROT 按完整文件路径获取 `IDispatch`，绑定正确文稿及其 `Application`。枚举启动前后顶层窗口，验证不同标识、进程和任务文稿后再绘制。让 WPS 正常启动显示窗口，不额外聚焦或调整大小。这是 WPS 专用原生流程，不要求通用 UI 点击。
- `KWPP.Application` 默认对象可能落到旧窗口，`NewWindow()`、新增标签或 `DocumentWindow` 也可能仅为同一主窗口内的视图，不能替代上述验证。跨版本原生启动失败时保留 pending，可通过可用桌面工具“在新窗口中打开”或等效分离任务标签，重新验证后继续。
- 独立新窗口确认后保留原设计与对象顺序，在任务文稿视图中快速构建整套页面；更新该视图当前页，不调用 `Activate`、`SetForegroundWindow`、`AttachThreadInput`，不置顶、还原或最大化。仅等待应用或剪贴板就绪，不增加演示停顿。未确认时保留源文件与 pending，不在旧窗口中先绘制。
- 用户切换应用、移动、缩放或最小化窗口后继续原生对象模型操作，尊重焦点与窗口状态，不抢回前台；完成后保存、保留打开，不重新激活。
- 只打开新建的自有文件或副本，只关闭脚本打开的源和验证副本，不执行进程终止或退出用户应用；最终文稿保留在新窗口打开，不关闭用户其他文档。
- 输入 PPTX 保留；输出目录、输出 PPTX 和报告均拒绝覆盖。`verify-edit` 更改单个已有中文原生标签，仅在测试副本执行。
- 页图导出成功、文本保存并重开成功分别是应用渲染和可编辑性证据。`visual_qa: pending` 表示仍需查看导出的每页 PNG；不能由 COM 成功直接宣称视觉通过。
- 独立顶层窗口与原生对象构建单独记录本次证据；实际前台、可见和最小化状态记入 `window_observation`，不作为执行成功条件。文档打开、应用可见或 COM 视图数量增加不能代替新窗口验收。
- 图形坐标用 point，导出的 PNG 尺寸用 pixel。需按目标页宽转换，不直接把像素数传入 COM 布局坐标。

此模块取自 harness-anything 的 WPS 连接思路；没有导入其其他应用模块、默认背景素材或卡片样式。来源与 MIT 归属见 [SOURCE.md](SOURCE.md) 和 [LICENSE](LICENSE)。
