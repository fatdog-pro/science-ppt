# 独立科研与演示辅助模块

辅助知识保存在下面各模块自己的 `SKILL.md`，不复制进主 skill。主流程按当前任务读取需要的模块；不要求豆包自动扫描嵌套 skill，不需要全局安装，也不使用来源机器的绝对路径执行。

| 当前需要 | 独立模块 | 交回主任务的内容 |
| --- | --- | --- |
| 机制、架构、装置与流程关系 | [doubao-science-schematics](doubao-science-schematics/SKILL.md) | 实体/关系、分区、图例、原生部件计划与检查对象 |
| 多面板、真实数据及比较尺度 | [doubao-scientific-visualization](doubao-scientific-visualization/SKILL.md) | 面板、编码、数值坐标映射与证据检查 |
| 具体 HEX 配色与跨页色义 | [editaplot-palette](editaplot-palette/SKILL.md) | 配色方案、对象颜色表和冗余编码 |
| 科研组会、综述或论文的逐页主线 | [scientific-talk-design](scientific-talk-design/SKILL.md) | 叙事、页计划、版式节奏、来源与讨论落点 |
| 中文排版、复杂矢量对象与验收 | [native-ppt-layout](native-ppt-layout/SKILL.md) | 对象分解、字级、间距、连接与最终文件审阅 |
| WPS 独立新窗口可见构建、预览与编辑验证 | [wps-ppt-automation](wps-ppt-automation/SKILL.md) | 顶层新窗口与对象构建证据、实际窗口状态、COM 可用性、逐页 PNG、真实修改与保存重开证据 |

输出合并到当前 `brief.json`、设计记录、受支持的 `scene.json` 字段和 `qa.json`。辅助设计字段不能直接变成 scene 的未知字段；分页、页序和一个 PPTX 汇总导出由主流程负责。全套共用命名、字体、色义和线型，每页按自己的科学问题选择主图。只读取任务需要的模块，不另外启动一套流程。

核心绘图工作方式为“材料 → 科学内容与设计 → 原生对象场景 → 独立 WPS 空白文稿可见构建 → 保存最终 PPTX”，不要求生图或图片描摹。普通主题和修订由 `run_science_ppt.py` 或 MCP `export_scene` 默认完整执行，固定示例使用专用完整入口；只有用户明确仅导出时才跳过应用。没有人工演示停顿，构图与对象不因可见执行而改变。不主动最大化或抢占前台，用户切换应用或调整窗口后继续原生对象模型执行。WPS 模块不能把上游卡片、底图和素材生成方式变成默认科研设计。真实图像证据需要独立补充操作及验证，不能冒充矢量部件。结构、科学、新窗口身份与构建、窗口状态观察、渲染和应用编辑分别检查；源稿导出和打开成品不能替代绘制证据。

## GitHub 检索与许可

核对日期：2026-10-10。先查看 skills.sh 榜单，再使用已缓存 Skills CLI 搜索 `scientific slides` 和 `pptx`，没有全局安装。安装量只是查询界面的近似快照，不能证明本适配模块的质量。

| 上游资源 | 具体许可与版本 | 本包采用范围 |
| --- | --- | --- |
| K-Dense [scientific-schematics](https://github.com/K-Dense-AI/scientific-agent-skills/tree/92ace75ac21efe19a620434e0ca4e356081fe807/skills/scientific-schematics) | MIT，提交 `92ace75ac21efe19a620434e0ca4e356081fe807` | 实体关系、机制布局、符号与标签审阅 |
| K-Dense [scientific-visualization](https://github.com/K-Dense-AI/scientific-agent-skills/tree/92ace75ac21efe19a620434e0ca4e356081fe807/skills/scientific-visualization) | 同一提交 MIT | 多面板、数据编码、坐标与来源 |
| K-Dense [scientific-slides](https://github.com/K-Dense-AI/scientific-agent-skills/tree/92ace75ac21efe19a620434e0ca4e356081fe807/skills/scientific-slides) | 同一提交 MIT；CLI 约 2K 安装 | 科研叙事、信息层级、不同版式、最终预览审阅 |
| OpenAI 历史版 [slides](https://github.com/openai/skills/tree/e6afb0d74cc75d220df2faf3dd6c635c2dc6a108/skills/.curated/slides) | 该目录 LICENSE.txt 为 Apache-2.0，提交 `e6afb0d74cc75d220df2faf3dd6c635c2dc6a108` | 原生对象、字体、对齐与渲染检查方法；不是整套上游运行环境 |
| 本机 EditaPlot 配色资源 | Apache-2.0，保留 NOTICE | 原样配色目录和当前对象字段映射；公开仓库未核实 |

OpenAI skills 仓库当前已标为 deprecated，这里明确固定开放许可的历史资料，不称为最新运行方案。每个模块的 `SOURCE.json` 保存来源、文件 SHA256、改写范围与排除的运行依赖；原许可证保存在模块目录。

[PptxGenJS 官方库](https://github.com/gitbrent/PptxGenJS) 使用 MIT，支持程序化 PowerPoint 对象，是扩展原生图表和备注时可评估的资源。本包没有下载或安装它，当前仍用已有 Python 标准库 scene 导出器，保持豆包部署轻量。库的能力不等于本包已实现的能力。

热门 Anthropic pptx 的具体许可证限制复制、衍生和分发，未打包该材料。上游 K-Dense 模型、完整绘图库、CLI 和 API 配置也未打包；只保留本任务适用的独立设计模块。

