# WPS 接入与应用验证

本辅助负责独立 WPS 新窗口中的可见构建，以及已有科研 PPTX 的兼容性验证。主技能决定科学表达、版式、配色和原生可编辑元素；连接代码不施加背景或卡片模板。默认每次新 PPT 任务都执行下方独立窗口流程，用户明确只需导出或不启动 WPS 时除外。

普通主题、论文汇报、指定页数和修订均通过 `scripts/run_science_ppt.py` 或连接器 `export_scene` 的默认完整入口执行；固定示例通过各自的完整重跑入口。内部源稿导出仅是准备阶段。`wps_ppt_bridge.py render` / `wps_render` 负责现有文件的兼容性预览，不能替代从空白文稿开始的本次可见构建。普通任务命令见 [通用可见绘制入口](ordinary-visible-workflow.md)。

## 新窗口与前台构建

1. 绘制开始前，WPS 专用辅助 `scripts/wps_owned_window.py` 枚举真实 WPS 顶层窗口，记录窗口标识、标题与进程。创建本任务的空白演示文稿，保存到全新输出路径，不能借用或覆盖用户文稿。
2. 使用实际安装的演示程序执行 `wpp.exe /n <owned-blank.pptx>`，参数各自独立传递，不通过拼接 shell 命令执行。本机此原生命令能创建独立进程与顶层窗口；迁移时由本机真实 WPS 路径和版本执行并验证，不把本机结果当成另一电脑的证据。
3. 从 ROT 枚举文件 moniker，用本任务文稿的完整绝对路径匹配并获取 `IDispatch`，绑定正确的 `Presentation.Application`，避免 `KWPP.Application` 默认对象落到旧窗口。核对启动前后新增的不同顶层窗口标识、进程和本任务文稿标题，确认自有文稿仍是空白。让 WPS 正常启动显示新窗口，不额外聚焦或调整大小；独立窗口身份验证不以 `GetForegroundWindow()` 相等为条件。
4. 只有独立窗口确认通过后，才在该窗口中构建全部页面。复制源文稿的原生对象时保留对象顺序、语义分组、坐标、尺寸、文字、字体和配色；不能因展示过程而重新设计。更新本任务文稿视图的当前页以显示实际绘制，不调用 `window.Activate()` 来翻页；不先把完整成品打开后宣称显示了绘制过程。
5. 尽量快地执行。只做应用、剪贴板、复制粘贴和保存就绪所必需的同步，不增加演示用 sleep、不要求逐项手工确认。保存最终稿并保持独立窗口打开，完成时不重新激活或带到前台；关闭操作只针对本任务自己打开的源或验证副本。

`Presentation.NewWindow()`、`DocumentWindow.NewWindow()`、`Presentation.Windows.Count` 增加或标题出现 `: 1`/`: 2` 只证明文档视图变化，部分 WPS 版本仍使用同一主窗口；不能据此通过验收。跨版本原生命令行未能创建或绑定独立窗口时，源 PPTX 保留，窗口与构建保持 pending；可通过当前可用桌面工具在本任务标签上执行“在新窗口中打开”或等效分离操作，再重新枚举、绑定与验证后继续。没有可用恢复办法时保留任务，不在未确认独立窗口时开始可见绘制。应用可见或文稿打开不能替代顶层窗口证据。

“前台运行”只要求新窗口可供观看。辅助代码在启动、绘制、翻页及完成时均不调用 `Activate`、`SetForegroundWindow`、`AttachThreadInput`，不置顶、不还原、不最大化。窗口位置、尺寸和最小化状态由 WPS 正常启动及用户操作决定。用户切换其他应用、移动、缩放或最小化 WPS 时，继续通过已绑定的原生对象模型绘制与保存，不等待焦点返回、不抢回前台，也不将执行状态改成失败。每页和完成时可以读取实际窗口状态，但只能作为观察记录；执行成功取决于文稿身份、原生对象构建和保存。

## 连接与应用验证

依赖为 Windows、已注册的 WPS 演示 COM (`KWPP.Application`) 和运行脚本的 Python 中可用的 `pywin32`。默认完整可见过程需要 pywin32，纯 PPTX 源稿生成和结构审计不需要它。可以用已有的 `D:\windows mcp\harness-anything\.venv\Scripts\python.exe` 运行桥接。先只检查准备状态：

```powershell
python scripts/wps_ppt_bridge.py readiness
```

准备检查只检查模块和 COM 注册，不启动应用。缺失时报告原因；不搜索安装目录、不自动装其他 harness 模块。每个命令向 stdout 输出一个 JSON 结果，失败退出码非零，诊断写 stderr。

```powershell
python scripts/wps_ppt_bridge.py render --pptx "D:\科研 PPT\science-visible.pptx" --out-dir "D:\科研 PPT\wps-render-01"
python scripts/wps_ppt_bridge.py verify-edit --pptx "D:\科研 PPT\science-visible.pptx" --out "D:\科研 PPT\wps-edit-verified.pptx"
```

输出路径必须全新。`render` 将原文件复制到新目录后打开，逐页导出 PNG；结果含 WPS 版本、页数、每页 PNG、原文件哈希、原文件未改变证据和 `render-report.json`。随后逐页查看 PNG，检查溢出、字体替换、重叠、轴标和科学符号。

`verify-edit` 在独立工作目录中打开副本，寻找一个已有中文原生标签，修改其文本，按 OpenXML PPTX 格式另存为全新输出，关闭副本并重开输出核对文字。旁边的 `.verification.json` 保存对象位置、修改前文字、内存中修改后文字与重开后的文字。它是编辑验证副本，不能直接冒充最终科研版面；需要时使用 `render` 再渲染该副本检查变更后的视觉效果。

COM 操作设置 `Visible=-1`，可复用现有应用进程；新制作任务仍须先建立上述独立顶层窗口。渲染与编辑验证只关闭本脚本打开的副本，不退出应用，不关闭最终稿或用户文档。默认 WPS。若用户选择 PowerPoint，在命令中显式加入 `--engine powerpoint`；失败不能静默改用另一引擎，结果记录实际引擎和版本。

COM 图形坐标和 `SlideWidth/SlideHeight` 单位是 point（1 inch = 72 pt）；PNG 导出参数单位是 pixel。固定目标像素宽度时按页宽高比例计算图像高度。需要从设计像素坐标到 COM 坐标时使用 `x_pt = x_px × slide_width_pt / design_width_px`，字体字号本来就是 pt，不再次缩放。

纯命令解析、依赖准备和文件格式验证不能证明 WPS 已渲染。完整构建已输出本次真实预览时直接查看这些 PNG；另需兼容性检查或编辑实测才执行上述 `render` 和 `verify-edit`。只有报告完成、PNG 可读、保存的 PPTX 合法且重开文字一致时，才报告对应应用证据。`visual_qa: pending` 始终等待人工或智能体查看 PNG 后作视觉结论。任何打开或渲染证据均不能代替本次独立窗口中的原生对象构建证据。

`qa.json` 的 `wps_execution.new_top_level_window` 记录绘制前的实际窗口标识、本任务新窗口标识、文稿标题/路径和本次验证证据；保留兼容字段 `wps_execution.foreground_build`，它记录实际页数、原生对象构建完成情况及无人工延时证据，不要求持续占用前台。`wps_execution.window_observation` 单独保存各页及完成时观察到的前台、可见和最小化状态。过程报告同时记录 `focus_policy: respect_user_focus` 与 `window_size_policy: respect_user_geometry`。`foreground: false` 不影响构建状态。窗口身份、对象执行、渲染、视觉检查与编辑验证各有独立状态，不用一个 COM 成功结果替代全部检查。
