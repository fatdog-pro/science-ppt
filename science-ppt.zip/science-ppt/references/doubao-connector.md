# 豆包本地 STDIO 连接器

随包连接器提供七个工具：`readiness/export_scene`、`wps_readiness/wps_render/wps_verify_edit` 和可重跑示例 `run_multimodal_route_example/run_chip_packaging_history_example`。`export_scene` 是普通任务完整入口，默认源稿导出后继续在独立 WPS 新窗口逐项构建、保存和生成真实预览；不是只导出文件。内部导出只依赖 Python 标准库，完整可见构建使用带 pywin32 的解释器，通过原生 WPS 启动与精确文稿 COM 绑定验证独立新窗口，无需通用 UI 点击。技能加载与连接器启用是独立配置，不能把本地脚本测试称为豆包 UI 内调用。

## 配置字段

只在当前客户端实际提供自定义本地 STDIO 连接器时使用。名称 `science-ppt`，命令填本机 Python 3.10+ 可执行文件，参数逐项填写：

```text
-E
-X
utf8
<skill-root>/scripts/mcp_server.py
--output-root
<absolute-output-root>
--wps-python
<absolute-python-with-pywin32>
```

最后两项可省略，默认使用服务器自身解释器运行 WPS 辅助。脚本只在明确的输出 root 下新建任务，不执行任意 shell、不监听 HTTP、不读取全局客户端配置。中文与空格路径保持为一个参数。

本次安装电脑可用的 WPS 解释器：`D:\windows mcp\harness-anything\.venv\Scripts\python.exe`。技能目录使用当前真实安装目录，输出 root 使用用户授权目录；迁移时必须替换路径。核心脚本仍可在 `-S` 下工作，但 WPS 子进程必须加载 site-packages。

菜单以当前版本界面为准，不假定固定 JSON 配置文件或导入协议。没有入口时使用本地文件和脚本能力；没有执行能力时保留规划与 scene 并说明缺项。

## 普通任务完整执行

先调用 `readiness`，确认真实解释器、导出器与输出目录。然后按照 [scene 格式](scene-schema.md)调用：

```text
export_scene {"job_name":"research-20261011-001","scene":<完整 scene 对象>}
```

`job_name` 为 1–80 位 ASCII 字母、数字、下划线或连字符，首位是字母或数字，不能为 Windows 保留名。已有名称拒绝覆盖；修订创建新任务。所有页放同一 `scene.slides`，一次得到一个完整 PPTX。scene 上限 4 MiB，核心导出器上限 100 页/10000 对象，不静默删页。

默认流程为内部源稿导出与审计 → 独立 WPS 空白文稿验证 → 所有页原生对象依次构建 → 保存 `science-visible.pptx`、真实预览、过程报告与 `qa.json`，并保持新文稿打开。读取返回的真实 `job_dir/pptx_path`、报告及预览路径；`figure-editable.pptx` 是内部源稿。连接器只保存自身实现的场景、产物与运行记录，brief、设计记录、事实来源仍由智能体按已有文件能力保存。完整入口已生成实际预览时直接查看全部页，不必为了完成绘制再调用 `wps_render`。

任何新主题、页数或按反馈重做的科研 PPT 都使用该流程。只有用户明确要求仅导出或不启动 WPS 才加 `"export_only":true`，不能由智能体为了快一点而自行跳过。未完成 WPS 新窗口、对象构建或保存时保留源稿和诊断，报告可见执行 pending/error，不能直接交付源稿并称制作完成。用户切换应用或调整窗口不影响构建完成判定。详细步骤见 [通用可见绘制入口](ordinary-visible-workflow.md)。

## 额外应用验证

先 `wps_readiness {}`。它只查依赖与 COM 注册，不能代表渲染和编辑已通过。

```text
wps_render {"job_name":"research-20261011-001"}
wps_verify_edit {"job_name":"research-20261011-001"}
```

这两个工具用于额外兼容性或编辑验证，不能代替可见构建。它们仅接受 root 下已经生成的任务，不接受任意文件路径；优先验证已存在的 `science-visible.pptx` 最终稿，纯导出任务使用 `figure-editable.pptx`。原始纯导出任务的渲染写入 `wps-preview`；完整构建已存在该目录时写入新的 `wps-render-preview`，已有输出仍拒绝覆盖。编辑验证写入新的 `wps-edit-test.pptx`，修改测试副本中的一个真实文本对象并保存重开，测试副本不能代替最终稿。

返回 `verification` 中的真实 PNG、应用信息、编辑证据和报告。逐页查看 PNG 后才能判定视觉质量，WPS 结果不能推断 PowerPoint。缺 pywin32 或 COM 时保留现有成果，将相应验证记为 pending；默认可见过程未完成时仍不能称任务完成。额外 WPS 验证调用最多 120 秒，超时保留诊断，不强杀用户 WPS。

应用操作与限制见 [wps-integration.md](wps-integration.md)，完整验收见 [acceptance.md](acceptance.md)。STDIO 使用 UTF-8 单行 JSON-RPC，stdout 只输出协议，诊断写 stderr。

## 完整重跑内置示例

用户要求复现“多模态传感与智能诊断技术路线”时直接调用：

```text
run_multimodal_route_example {"job_name":"multimodal-demo-20261011-001"}
```

用户要求复现“芯片封装的发展历程”十页时调用：

```text
run_chip_packaging_history_example {"job_name":"chip-history-demo-20261011-001"}
```

两个入口均不必由智能体重新编写 scene，也不必先调用 `export_scene`。默认重新导出、结构审计，用原生 `wpp.exe /n` 创建本任务独立 WPS 顶层新窗口，再按精确文件 ROT 绑定和启动前后窗口枚举验证，在任务文稿视图中按固定顺序构建原版原生对象，保存最终稿和本次实际预览并保持打开；无需通用 UI 点击，无人工停顿。WPS 正常启动显示窗口，程序不额外激活、置顶、还原或最大化；换页只更新本任务视图，用户切换应用或调整窗口后继续执行，不抢回前台，完成时也不重新聚焦。新标签页或 COM 文档视图不能替代独立顶层窗口。跨版本原生启动或绑定失败时保留源 PPTX 与 pending；可以通过当前可用桌面能力分离任务标签，重新验证后继续，不能在旧窗口中直接绘制并宣称通过。每次必须使用新 `job_name`。仅在用户选择不运行 WPS 时可加 `"export_only":true`，应用状态为 pending。单页示例工具最长 300 秒，十页示例最长 900 秒；超时保留任务和 WPS 会话，不能把超时报告改写为完成。其他 WPS 工具的 120 秒限制不变。

返回真实 `pptx_path`、`qa_path` 与过程报告。构建完成后检查本次所有实际预览并报告证据；过去预览不能代替本次渲染。保留兼容字段 `foreground_build` 记录构建结果，`window_observation` 单独描述实际前台、可见或最小化状态，用户切换焦点不导致执行失败。详细说明及没有连接器时的本地入口见 [单页技术路线示例](multimodal-route-example.md) 与 [十页芯片封装示例](chip-packaging-history-example.md)。
