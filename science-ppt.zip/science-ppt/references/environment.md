# 本地执行与 WPS 辅助环境

核心绘图与 WPS 辅助分开检查，只有真实可用的工具才能创建文件与验证应用。

## 原生绘图

内部源稿导出器 `build_pptx.py` 与结构审计器 `audit_pptx.py` 需要 Python 3.10+，仅依赖标准库，无需模型 API 或转换服务。普通任务完整入口 `run_science_ppt.py` 和连接器 `export_scene` 默认还会运行 WPS 可见构建，需要下方应用环境。对象与单位见 [scene-schema.md](scene-schema.md)。

使用本机真实解释器和新输出目录，正确引用中文与空格路径。核心 scene 不支持图片、备注、原生图表、Office 公式或未知字段。

## WPS 演示辅助

需要 Windows、已安装并注册 COM 的 WPS 演示，以及带 `pywin32` 的 Python 3.10+。可使用独立虚拟环境：

```text
python -m venv <local-env>
<local-env>/Scripts/python.exe -m pip install pywin32
<local-env>/Scripts/python.exe <skill-root>/scripts/wps_ppt_bridge.py readiness
```

`readiness` 仅查依赖和 COM 注册，不启动应用。真实连接、渲染和编辑见 [wps-integration.md](wps-integration.md)。注册表存在不能证明应用操作已验证。

默认新制作任务用 `scripts/wps_owned_window.py` 的 WPS 专用辅助，通过真实 `wpp.exe /n` 创建独立窗口，按本任务文件的完整路径从 ROT 绑定正确的演示文稿，枚举并验证自有顶层窗口。WPS 正常启动显示窗口，辅助代码不强制聚焦、还原或最大化；绘制、换页及保存均尊重用户对窗口和前台的操作。Python 需要 pywin32 的 COM 与窗口接口；不需要额外通用 UI 点击工具。COM 默认应用或 `NewWindow()` 不保证连接到独立主窗口，必须在绘制前按 [独立窗口流程](wps-integration.md) 取得本次证据。跨版本原生启动或绑定失败时先保留源 PPTX、状态 pending，可用当前桌面能力分离任务标签并验证后继续；不能把同一主窗口内新增视图当作完成。独立窗口确认后，用户切换应用或最小化 WPS 不阻止原生对象模型继续执行。

本次安装机器的 Harness Anything 独立解释器在 `D:\windows mcp\harness-anything\.venv\Scripts\python.exe`；迁移时换成本机真实路径，技能不依赖此固定目录。

WPS 不可用时保留内部源稿与诊断，可见过程尚未完成，不能把纯导出当作默认任务完成。只有用户明确仅需导出或不启动 WPS 时，完整入口才可使用 `--export-only` / `"export_only":true`。PowerPoint 是明确选择的另一引擎，不能用其结果证明 WPS 已实测。

## 连接器与文件

连接器的 `readiness` 仅检查准备状态，`export_scene` 默认执行完整普通任务。用 `--wps-python` 指定带 pywin32 的解释器；省略时使用服务器自身解释器，见 [doubao-connector.md](doubao-connector.md)。不要在需要 pywin32 的辅助子进程中使用禁用 site-packages 的 `-S`。

技能加载、Python 安装和连接器启用是独立事项，本地脚本测试不等于豆包 UI 内调用。缺执行能力时可以完成计划与 scene，但不能声称创建了文件。STDIO stdout 只用于协议。

每次任务用新目录，应用操作用自有副本，修订另存版本。生成稿、验证副本与最终稿区分保存，只记录实际文件、预览和验证证据。
