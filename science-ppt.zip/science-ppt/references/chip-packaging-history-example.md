# 芯片封装的发展历程 · 十页可重跑示例

固定十页顺序为：发展概览、DIP、表面贴装与 QFP、BGA、引线键合与倒装、CSP/晶圆级/扇出、SiP、2.5D 与 HBM、3D 与混合键合、Chiplet。示例使用原生可编辑文字、结构剖面、连接线和分组；不含虚构性能曲线。发布、计划导入、量产和标准公开分别标明，技术之间可组合并长期并存。

## 在豆包中完整重跑

安装完整 `science-ppt` 文件夹后输入：

> 使用 science-ppt，完整重跑“芯片封装的发展历程”十页示例。打开独立的新 WPS 窗口供我观看全部原生对象构建过程。保持固定内容、版式、配色、字号和分组，不加演示停顿，不主动最大化或抢占前台；保存完成的十页可编辑 PPT，并保持新窗口打开。

智能体执行下方入口，不重新生成或改写示例 scene。每次确定全新任务目录，由程序通过真实 `wpp.exe /n` 原生启动独立窗口，按完整任务文件路径从 ROT 绑定正确文稿与应用，验证新增顶层窗口身份后再绘制；让 WPS 自身正常显示窗口，不额外聚焦或改变大小，无需通用 UI 点击。同一主窗口内的新标签页或 `DocumentWindow` 不算满足要求。跨版本原生启动或绑定失败时保留源文件与 pending；若有可用桌面能力，可将本任务标签“在新窗口中打开”或等效分离，重新验证后继续。详细流程见 [主技能](../SKILL.md) 和 [WPS 集成](wps-integration.md)。

## 程序入口

`<skill-root>` 为实际加载的技能绝对目录，`<new-job-dir>` 为用户授权位置中尚不存在的新目录，每个路径分别作为一个参数。

```text
python <skill-root>/scripts/run_chip_packaging_history_example.py --out-dir <new-job-dir> --wps-python <python-with-pywin32>
```

本机可使用 `D:\windows mcp\harness-anything\.venv\Scripts\python.exe`；迁移时改用新电脑实际的 Python 3.10+、pywin32 和 WPS 演示。运行脚本、场景路径都相对于安装的技能目录解析，不依赖本机开发目录。只要求导出、明确无需 WPS 时加 `--export-only`；此模式仍将应用和视觉验收标为待检。

程序校验固定场景哈希，复制场景、任务简述和来源说明到新任务目录，导出原生 PPTX并进行结构审计；随后调用通用 WPS 前台构建程序完成十页，逐页保存与导出当前运行的实际预览，最后再次检查结构。stdout 输出一个 JSON，包含产物路径、完成状态与待检项目。WPS 不可用时保留核心导出文件并如实报告应用状态；不能以导出成功替代前台完成。

已启用本地 STDIO 连接器时可直接调用：

```text
run_chip_packaging_history_example {"job_name":"chip-history-demo-20261011-001"}
```

每次使用新名称，参数 `export_only` 仅在用户明确不运行 WPS 时设为 `true`。工具最长 900 秒，用于完整十页导出、前台构建及审计；没有人为演示延时，实际就绪后立即继续。连接器配置见 [豆包连接器](doubao-connector.md)。

## 内置资源

- [scene.json](../assets/examples/chip-packaging-history/scene.json)：1600×900、十页固定原生场景。
- [brief.json](../assets/examples/chip-packaging-history/brief.json)：主题、假设、材料语义配色和页面问题。
- [sources.md](../assets/examples/chip-packaging-history/sources.md)：经核验的博物馆、IEEE 与厂商原始资料，逐页说明适用范围。
- [manifest.json](../assets/examples/chip-packaging-history/manifest.json)：固定场景 SHA-256 和对象数量。
- [运行入口](../scripts/run_chip_packaging_history_example.py) 与 [WPS 前台构建](../scripts/assemble_wps_foreground.py)：完整可重跑程序。

技能包只保留以上复现输入和程序，不内置 PPT/PPTX、预览 PNG 或过去运行输出。实际 PPTX、报告与预览在每次运行的新任务目录中产生；它们用于用户查看和当前运行验收。

## 验收与复现边界

固定场景 SHA-256 为 `f520a1e46266f27aa93795906e92dc45574a6c5930706e3b4b6215103650e805`。十页共 963 个原生对象，包括组内部件；306 个顶层对象，188 个可编辑文本对象，29 个组，0 个光栅对象。导出审计和最终 WPS 审计都必须匹配这些数量，源 scene 不得被运行改写。

智能体必须查看本次 WPS 实际渲染的全部十页，确认字体、文字、接点标注、边界和层次无错位、遮挡、裁字；结构审计不等同于视觉验收。需要验证编辑时，在本次最终 PPTX 的副本上改动并验证，测试文字不得进入最终文稿。报告中的视觉状态在实际看图前保持 pending。

新 WPS 窗口供用户随时观看；不人为放慢、停顿或改动设计。每次翻页只更新本任务文稿视图，不调用窗口 `Activate` 或抢占焦点，不主动置顶、还原、最大化。用户移动、缩放、最小化 WPS 或切换其他应用后继续原生对象模型绘制；各页与完成时的前台状态仅作 `window_observation` 观察记录，不影响构建成功判断。仅允许对象模型和剪贴板完成所需同步，复制粘贴会使用系统剪贴板。保存并保持当前任务文稿打开，完成时不重新带到前台，不退出 WPS 或关闭用户其他文稿。不同 WPS 版本的坐标取整可能产生极小像素差异，固定内容和原生对象结构应保持一致。
