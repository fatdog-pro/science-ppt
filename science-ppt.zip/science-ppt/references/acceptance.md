# 验收：内容、科学含义、原生对象与精致程度

## 页数、页序与完整性

用户指定页数时以该数量为准；未指定时以已说明的 `brief.pages` 计划为准。依次核对 brief 的页 ID/标题、`scene.slides`、PPT 实际页序、审计报告的 `slide_count` 和每页文字，确认所有页位于一个 PPTX 文件中。各页非空，没有漏页、复制页面补数或把页内分面板误算为多页。

完整汇报须检查内容覆盖与叙事：每页是否回答计划的问题，论点是否有对应技术图或证据，前后页是否承接，是否以重复卡片或空泛文字填充。达到页数只证明数量。逐页设计方法见 [deck-design.md](deck-design.md)。

## 独立 WPS 新窗口与前台过程

普通主题、指定页数、论文汇报和修订，与两个固定示例采用同一过程要求。普通任务必须运行通用 CLI `run_science_ppt.py` 或 MCP `export_scene` 默认完整入口，不能只执行离线导出器。任务没有明确要求仅导出时，可见构建属于本次完成范围。

默认新制作任务在可见绘制前，通过 WPS 专用辅助执行真实 `wpp.exe /n <owned-blank.pptx>` 创建并确认独立顶层窗口；从 ROT 按完整任务文件路径绑定正确文稿与 `Application`。记录绘制前已有的 WPS 窗口标识、本任务新增的不同标识、进程、标题和文稿对应关系，确认自有空白文稿和窗口身份后逐页构建，不需要通用 UI 点击工具。让 WPS 正常启动显示新窗口，辅助代码不强制激活、置顶、还原或最大化。`Presentation.NewWindow()`、`DocumentWindow.NewWindow()`、COM 视图增加、增加标签页或仅设置 `Visible=-1` 不能证明独立顶层窗口已建立。跨版本原生启动失败时可通过可用桌面工具将本任务标签“在新窗口中打开”或等效分离，再重新枚举与绑定验证。

验收顺序必须是“新窗口确认 → 任务文稿可见构建 → 保存保留打开”。把成品打开到新窗口只能证明交付时显示，不能证明整个绘制过程发生在新窗口。核对本次构建页数、对象顺序、组与坐标保持原设计，过程无人工演示延时；只有应用、剪贴板或保存就绪所必需的同步可等待。前台展示不能通过更改构图、配色、字号或降低内容质量实现。翻页只更新任务文稿视图，不调用窗口 `Activate`。用户切换应用、移动、缩放或最小化 WPS 后继续原生对象模型操作，保存后不重新带到前台。

没有 WPS、原生启动/精确文稿绑定失败或顶层窗口未验证时，源稿可保留，窗口与应用执行为 pending；构建或保存失败如实记 failed/error，不能把纯导出成功写成默认任务完成。通用 UI 工具缺失不影响已支持环境的 WPS 原生辅助流程。已在未确认独立窗口时绘制则本次窗口流程为 failed，不能把文稿打开成功改记为通过。用户明确只需导出或不启动 WPS 时，记录其选择与未执行状态，相应应用过程不纳入本次必需范围。窗口身份、对象构建、窗口状态观察、渲染、视觉与编辑测试分别记录，不互相替代。`window_observation` 中的前台状态只是事实记录，`foreground: false` 或用户最小化不导致构建 failed/pending。

## 科学与语义覆盖

逐页用用户材料和实际核验的来源检查实体、结构、关系、技术判断与文字。brief 是内容计划，只有记录事实及证据后才能作为核对依据。检查单位、方向、术语、上下标、符号、版本和适用条件；跨页名称、色义与图例保持一致。概念示意也要满足科学结构，不能以没有实验数据为理由免检。

对照 `design.md` 的部件清单，确认每个必需部件、标签和关系都有对应原生对象/组；重要空间层次、接口、材料边界和作用路径须在图形中可辨认，只有主体名称不算覆盖。审查代表性重复单元是否合理：有定量含义时数量准确，仅作示意时明确其性质。

证据记录实际查阅的位置与支持的具体判断，不能只列资料链接。定量图核对数据到坐标的计算、单位、误差条及统计含义，不能从模型生成的外观猜测数值。修正科学问题时逐页记录原值、修改、依据与原因。关键判断没有来源支持为 pending；已发现错误而未修正为 failed。

## 原生结构

实际运行 `audit_pptx.py` 并读取报告。严格矢量交付须达到：

- 幻灯片比例与任务一致。
- 标签为原生文本，可在 `<a:t>` 中提取，不转成轮廓代替文字。
- 无 `<p:pic>`、图片填充或 image 关系，无位图媒体或 SVG 图片。
- 实体为原生形状、自由路径或语义对象组，主要技术部件可分别编辑。
- 普通方向关系由带自身箭头的单个连接符表达，物理布线没有无依据的流程箭头。
- 实际页面、文字和对象与 scene 对应，没有漏页、漏对象或失效端点引用。

文件审计不等于视觉检查。移动整体 SVG 或图片不算编辑其中的部件。没有最少对象数量门槛：对象必须覆盖技术内容，堆砌无意义形状同样不能通过内容与视觉验收。

## 实际查看每页外观

完整构建入口已经生成本次最终稿的逐页实际预览时，优先查看该批 PNG。额外兼容性验证或缺少本次预览时，先执行 `wps_ppt_bridge.py readiness`，再将本次最终 PPTX 的自有副本渲染到新目录：

```text
python <skill-root>/scripts/wps_ppt_bridge.py render --pptx <absolute-pptx> --out-dir <new-preview-directory>
python <skill-root>/scripts/wps_ppt_bridge.py verify-edit --pptx <absolute-pptx> --out <new-test-copy.pptx>
```

查看返回的真实图片与报告；`verify-edit` 的测试副本不可当成最终稿。具体参数、依赖与限制见 [wps-integration.md](wps-integration.md)。

有 PowerPoint 时可运行：

```powershell
& "$skillRoot\scripts\render_pptx.ps1" -PptxPath $pptxPath -OutDir "$jobDir\preview"
```

`$pptxPath` 使用本次实际 PPTX 的绝对路径，本地与连接器导出以各自返回的文件为准。也可使用环境现有的可信 PPT 渲染方式。取得按序覆盖全部页的预览后，实际查看每一页；脚本完成 PNG 导出不能代替看图。结合该页部件清单与设计规范检查：

- 主体图足够明确，结构、投影、层次、线路、接点和必要重复单元均清楚可辨。
- 标题、主图、说明与来源有清楚层级，图形占比与内容密度适合用途，没有用大段文字挤走技术主体。
- 关键标签在实际阅读尺度清晰，无字体溢出、裁切、遮挡、意外重叠和靠缩小字体掩盖内容过多。
- 元素对齐、边距、间距和线条一致；引线不穿文字，箭头指向明确，色彩承担稳定语义而非随机装饰。
- 每页构图服务其科学任务，全套有连贯节奏；连续相同卡片模板、空洞流程或图标墙没有替代实际技术图。

记录具体观察与已修复问题，不使用未执行的自动评分或空泛“符合预期”作为证据。主要装置只有带名称的方框、空间层次缺失、多道接口退化成一条线、结构比较只有两段文字均属语义图形缺失，未修复为 failed。发现问题后修改实际 scene、重新导出完整 PPTX 并再次检查，不能仅更新 QA 状态。

没有渲染环境或渲染失败时保留结构结果，将视觉状态记为 pending。预览成功只证明对应渲染器执行成功；实际查看后才能判定视觉质量，也不能据此将应用编辑标为 passed。

## WPS 与 PowerPoint 分别验证

Harness Anything 提取的 WPS 模块辅助应用操作，不改变科学内容的验收标准。它不强杀或退出用户应用，只关闭自有副本；开机环境的实际能力与本次任务验证分开记录。若任务通过 COM 增加原生表格、图表或真实图片，逐项核对其内容与编辑范围，严格矢量审计仍仅适用于核心矢量稿，不把其失败或未覆盖项目改写为通过。

两种应用的打开/渲染与编辑分开记录。实际编辑测试在另存副本中修改本任务存在的代表性对象，例如中文标签、形状颜色/位置、关系线端点或自由曲线顶点，再保存并重开，记录修改前后值、文件路径与观察。没有自由曲线时不虚构自由曲线测试。

只打开/渲染、修改 scene 后重新生成或仅依据 OOXML 推断均不算应用内编辑实测。WPS 是默认可见绘制的执行依赖，离线源稿生成不依赖应用；不可用时默认制作尚未完成。用户明确禁止启动应用时调整本次范围，保持相应应用验证 pending，并明确可编辑性来自原生结构证据。不要关闭或覆盖用户已有演示文稿。

## QA 记录

```json
{
  "workflow": "text-brief-to-native-scene-to-pptx",
  "pptx": "science-visible.pptx",
  "page_count": {"expected": 2, "actual": null, "status": "pending"},
  "page_order": {"expected": ["page_001", "page_002"], "status": "pending"},
  "structure": {"status": "pending", "report": "audit-report.json"},
  "pages": [
    {
      "id": "page_001", "order": 1, "design": "pages/page-001/design.md",
      "scientific": {"status": "pending", "evidence": []},
      "semantic_coverage": {"status": "pending", "checked_components": [], "missing_components": []},
      "visual": {"status": "pending", "preview": null, "evidence": [], "issues": []},
      "corrections": []
    },
    {
      "id": "page_002", "order": 2, "design": "pages/page-002/design.md",
      "scientific": {"status": "pending", "evidence": []},
      "semantic_coverage": {"status": "pending", "checked_components": [], "missing_components": []},
      "visual": {"status": "pending", "preview": null, "evidence": [], "issues": []},
      "corrections": []
    }
  ],
  "application_render": {
    "powerpoint": {"status": "pending", "evidence": []},
    "wps": {"status": "pending", "evidence": []}
  },
  "application_edit": {
    "powerpoint": {"status": "pending", "evidence": []},
    "wps": {"status": "pending", "evidence": []}
  },
  "wps_execution": {
    "new_top_level_window": {
      "status": "pending", "existing_window_ids": [], "task_window_id": null,
      "document_path": null, "verified_before_drawing": false, "evidence": []
    },
    "foreground_build": {
      "status": "pending", "actual_pages": null, "artificial_delays": false, "evidence": []
    },
    "window_observation": {
      "focus_policy": "respect_user_focus", "window_size_policy": "respect_user_geometry",
      "pages": [], "final": null
    },
    "saved_and_left_open": {"status": "pending", "evidence": []}
  },
  "overall": {"status": "pending", "scope": "页数、内容覆盖、科学、原生结构、视觉与独立 WPS 新窗口中的对象构建和保存；应用编辑实测单列"},
  "limitations": []
}
```

这里的两页仅演示格式，`pages` 必须覆盖全部实际页面，单页保留一个条目。实际页数来自审计/PPT，不从期望值复制。`preview` 仅在文件已生成时填写真实路径；状态通过必须有本次任务的具体证据。部件覆盖填写已核对对象与其含义，空列表不代表检查完成。

兼容字段 `foreground_build.status` 表示任务窗口中的原生对象构建结果，不表示持续占有前台。`window_observation.pages` 和 `final` 记录实际观察到的窗口前台、可见、最小化及几何状态；缺少某次观察时如实保留未知，不以观察结果替代执行结果。

`overall.scope` 必须明确。默认制作范围为页数、内容覆盖、科学、原生结构、视觉，以及独立 WPS 新窗口中的对象构建和保存保留打开；用户明确只导出或不启动 WPS 时调整应用执行范围，并记录该要求。用户要求应用编辑实测时也纳入范围。范围内任何必需页或项目 failed 时为 failed，没有 failed 但存在 pending 时为 pending，全部有本次通过证据才能为 passed。用户切换前台或调整窗口不属于失败项，窗口状态观察不纳入执行成败条件。即使其余项目通过，未实测应用编辑仍保持 pending 并在交付中单列。顶层窗口标识只能填写本次实际枚举值，不能填写 COM 视图编号代替。

默认交付本次可见构建保存的最终稿，报告实际完成/计划页数、对象可编辑范围和未验证项。可见过程未完成时报告源稿与具体缺项，不直接交付源稿并称已完成；只导出模式必须有用户明确选择。不把 exporter 成功当作精致程度或可见过程验收，也不把开发机验证说成已经在豆包内实际调用。
