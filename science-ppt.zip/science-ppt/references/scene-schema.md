# scene.json 对象格式

这是 agent 根据文本 brief、科学关系和版式计划直接编写的原生对象描述。导出器拒绝未知字段和图片元素，错误指出具体字段。文件为 UTF-8 JSON；文本内容不会自动变成几何，需由 agent 明确指定对象和构图。

## 画布和页

```json
{
  "version": 1,
  "title": "科研示意图",
  "canvas": {"width": 1600, "height": 900, "slide_width_in": 13.333333333333334, "slide_height_in": 7.5},
  "slides": [{"id": "page1", "title": "标题", "background": "#FFFFFF", "elements": []}]
}
```

`slides` 有一个元素时导出单页，有多个元素时按数组顺序导出到同一个 PPTX；不需要额外合并命令。页数由用户需求确定。`elements` 必须非空。最多 100 页、全文件最多 10000 个元素。`canvas` 是整套幻灯片的统一尺寸，不能在各页设置不同画幅。设计像素宽高比和英寸宽高比必须一致；改成 4:3 时同时调整两组尺寸。根对象可用 `metadata` 保存各页来源或辅助元数据；它保留在 `scene.json` 中，不嵌入幻灯片。此版本不支持演讲者备注，任何 `notes` 字段均被拒绝；需要展示的说明使用普通文本对象。多页任务的资料组织见 [multi-page.md](multi-page.md)。

元素按数组顺序从后到前绘制。所有页和所有对象的 `id` 全文件唯一，ASCII 字母或下划线开头，后续允许字母、数字、下划线、句点和短横线，最多 128 字符。多页建议页 ID 用 `page_001/page_002`，对象和组内成员用 `p001_/p002_` 前缀；连接绑定也引用加前缀后的本页 ID。可用中文 `name` 让 PowerPoint 选择窗格更易识别，`description` 提供对象说明。

## 坐标与外观

除 line 外，元素使用 `x,y,w,h`；宽高为正，位置以设计像素计。对象及其线宽不能越过父组或画布。`rotation` 为度数，单对象支持 -360 至 360；组不支持旋转，可旋转组内对象。

`fill` 是 `#RRGGBB` 或 null，`fill_opacity` 为 0～1。`stroke` 是 null 或如下对象：

```json
{"color":"#243447","width":3,"opacity":1,"dash":"solid","head":"none","tail":"triangle"}
```

线宽为设计像素，dash 支持 `solid/dash/dot/dashDot/longDash`。head 是起点的箭头，tail 是终点的箭头，对应 DrawingML headEnd/tailEnd；常用单向流程箭头设置 `tail:"triangle"`。箭头值为 `none/triangle/stealth/diamond/oval/arrow`，只适用于 line/path。不能用颜色名称、8位HEX或百分比字符串。

## 原生文本

```json
{"id":"label1","type":"text","name":"中文标签","x":100,"y":80,"w":500,"h":70,"text":"样品制备 → 检测","font":{"family":"Arial","east_asian":"Microsoft YaHei","size":40,"bold":true,"color":"#18324B"},"align":"left","valign":"middle","margin":4}
```

`text` 是非空 Unicode 字符串，换行产生独立段落。`font.size` 是设计像素，不是 pt；1600×900 对应 13⅓×7½ 英寸时 40px = 24pt。字体还支持 `italic`。微软雅黑需目标机器安装；未安装时渲染软件可能替换字体。`align` 为 left/center/right；`valign` 为 top/middle/bottom；`margin` 为设计像素；`line_spacing` 默认 1.1。无法用同一文本对象表达混合字号、复杂公式或富文本上下标，不要把这些当作已支持功能。

## 原生形状

```json
{"id":"node1","type":"shape","shape":"roundRect","x":100,"y":230,"w":380,"h":400,"fill":"#EEF5FA","stroke":{"color":"#AFC9DD","width":2}}
```

形状支持 `rect/roundRect/ellipse/triangle/diamond/chevron/rightArrow/upArrow/hexagon/arc`。可在同一 shape 中加入 `text,font,align,valign,margin,line_spacing`，文本和该形状一起编辑。复杂装置拆为多个形状或自由路径。

## 单对象连接符

```json
{"id":"arrow1","type":"line","x1":480,"y1":430,"x2":610,"y2":430,"stroke":{"color":"#44697F","width":4,"tail":"triangle"},"connect":{"start":{"id":"node1","site":3},"end":{"id":"node2","site":1}}}
```

line 不使用 `x,y,w,h,rotation,fill`。支持水平、竖直和反向端点。可选 `connect.start/end` 指向本页现有 shape/text/path，site 为 0～3；连接点的实际位置和编号取决于目标几何，不猜测所有形状都相同。先在预览确认绑定未改变箭头位置；难以确定接点时保留按坐标的可编辑连接符。

## 原生自由路径

```json
{"id":"outline1","type":"path","x":150,"y":300,"w":100,"h":180,"fill":"#D5EDF3","stroke":{"color":"#3585A2","width":3},"commands":[["M",10,10],["L",90,10],["L",90,130],["C",90,175,10,175,10,130],["Z"]]}
```

commands 使用相对当前路径边框的设计像素。支持 M(x,y)、L(x,y)、C(x1,y1,x2,y2,x,y)、Q(x1,y1,x,y)、Z。至少有一个绘制段，2～5000 条命令；第一条必须为 M，Z 后新子路径也须 M，所有控制点和端点都在 w/h 内。路径导出为原生 `<a:custGeom>`，可在 PowerPoint 编辑顶点，不作为 SVG 图片导入。减少多余节点，按对象或语义部件划分路径。

## 对象组

```json
{"id":"device1","type":"group","x":150,"y":300,"w":250,"h":200,"children":[{"id":"part1","type":"shape","shape":"ellipse","x":20,"y":20,"w":80,"h":80,"fill":"#A8DADC"}]}
```

children 坐标相对组左上角，嵌套最多 12 层，必须在组边框内。组本身不使用 fill/stroke。PPT 中可整体移动，也可进入组或取消组合编辑成员。

完整可运行的单页示例在 [../assets/example-scene.json](../assets/example-scene.json)，三页示例在 [../assets/example-multipage-scene.json](../assets/example-multipage-scene.json)。直接文本设计示例的 brief 在 [../assets/example-text-vector-brief.md](../assets/example-text-vector-brief.md)，对象场景在 [../assets/example-text-vector-scene.json](../assets/example-text-vector-scene.json)。按当前任务的事实与设计改写，不将示例内容当作用户已有结果。
