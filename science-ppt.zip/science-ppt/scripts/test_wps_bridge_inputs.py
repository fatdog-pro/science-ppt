"""Input/output preservation checks; no presentation application is started."""
from __future__ import annotations

from pathlib import Path
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wps_ppt_bridge import PPTX_MAIN_TYPE, new_path, parse_args, validate_pptx


class InputsTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(
            prefix="wps-bridge-inputs-", dir=Path(__file__).resolve().parent
        )
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def package(self, name="中文 科研图.pptx", content_type=PPTX_MAIN_TYPE):
        path = self.root / name
        with zipfile.ZipFile(path, "w") as package:
            package.writestr("[Content_Types].xml", (
                '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                f'<Override PartName="/ppt/presentation.xml" ContentType="{content_type}"/>'
                '</Types>'
            ))
            package.writestr("ppt/presentation.xml", (
                '<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"/>'
            ))
        return path

    def test_unicode_space_input_is_read_without_mutation(self):
        source = self.package()
        original = source.read_bytes()
        self.assertEqual(validate_pptx(source), source.resolve())
        self.assertEqual(source.read_bytes(), original)

    def test_binary_ppt_renamed_to_pptx_is_rejected(self):
        source = self.root / "legacy.pptx"
        source.write_bytes(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1")
        with self.assertRaises(zipfile.BadZipFile):
            validate_pptx(source)

    def test_macro_or_other_package_type_is_rejected(self):
        source = self.package(content_type="application/vnd.ms-powerpoint.presentation.macroEnabled.main+xml")
        with self.assertRaises(ValueError):
            validate_pptx(source)

    def test_missing_presentation_part_is_rejected(self):
        source = self.root / "incomplete.pptx"
        with zipfile.ZipFile(source, "w") as package:
            package.writestr("[Content_Types].xml", "<Types/>")
        with self.assertRaises(KeyError):
            validate_pptx(source)

    def test_existing_file_and_directory_outputs_are_rejected(self):
        source = self.package()
        for path in (source, self.root):
            with self.subTest(path=path), self.assertRaises(FileExistsError):
                new_path(path)

    def test_new_pptx_requires_pptx_extension(self):
        with self.assertRaises(ValueError):
            new_path(self.root / "output.ppt", ".pptx")
        self.assertEqual(new_path(self.root / "新 图.PPTX", ".pptx"),
                         (self.root / "新 图.PPTX").resolve())

    def test_engine_is_explicit_and_valid_in_either_position(self):
        self.assertEqual(parse_args(["readiness"]).engine, "wps")
        self.assertEqual(parse_args(["--engine", "powerpoint", "readiness"]).engine, "powerpoint")
        self.assertEqual(parse_args(["readiness", "--engine", "powerpoint"]).engine, "powerpoint")


if __name__ == "__main__":
    unittest.main()
