"""Build any reviewed scene, then visibly assemble its native objects in WPS.

The default path is complete only after a separate WPS window has been verified,
every page has been assembled object by object, and the final native PPTX passes
its audit. Export-only is an explicit preparation mode, never visible completion.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

from audit_pptx import audit_pptx
from run_multimodal_route_example import checked_path, read_json, run_step, write_json


SOURCE_NAME = "figure-editable.pptx"
FINAL_NAME = "science-visible.pptx"
VISIBLE_OUTPUTS = (
    FINAL_NAME, "foreground-report.json", "wps-preview", "foreground.log",
    "foreground-audit-report.json", "foreground-audit.log", "qa.json",
)


def _path(value, existing=False):
    raw = Path(value)
    if ".." in raw.parts:
        raise ValueError("Use an absolute path without '..'.")
    # On Windows a colon inside a component denotes an alternate data stream.
    if any(":" in part for part in raw.parts if part != raw.anchor):
        raise ValueError("Alternate data stream paths are not allowed.")
    return checked_path(value, existing)


def _scripts():
    root = _path(os.path.abspath(__file__), True).parent
    for name in ("build_pptx.py", "audit_pptx.py", "assemble_wps_foreground.py"):
        _path(str(root / name), True)
    return root


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _scene_info(scene_path):
    scene = read_json(scene_path)
    if not isinstance(scene, dict):
        raise ValueError("Scene must be a JSON object.")
    pages = scene.get("slides")
    if not isinstance(pages, list) or not 1 <= len(pages) <= 100:
        raise ValueError("Scene must contain 1-100 slides.")
    if any(not isinstance(p, dict) or not isinstance(p.get("elements"), list) for p in pages):
        raise ValueError("Every scene slide must contain an elements list.")
    return len(pages), [len(page["elements"]) for page in pages]


def _result(job, scene_path, source_hash):
    return {
        "status": "pending",
        "workflow": "science-ppt-generic-visible",
        "job_dir": str(job),
        "output_directory": str(job),
        "source_scene": str(scene_path),
        "scene_path": str(job / "scene.json"),
        "scene_sha256": source_hash,
        "scene_unchanged": True,
        "export_pptx": str(job / SOURCE_NAME),
        "source_pptx_path": str(job / SOURCE_NAME),
        "foreground_pptx": str(job / FINAL_NAME),
        "final_pptx_path": str(job / FINAL_NAME),
        "qa_path": str(job / "qa.json"),
        "qa_report": str(job / "qa.json"),
        "build_report_path": str(job / "build-report.json"),
        "audit_report_path": str(job / "audit-report.json"),
        "source_export": "pending",
        "structural_validation": "pending",
        "visual_execution": "pending",
        "visible_process_complete": False,
        "foreground_status": "pending",
        "application_validation": "pending",
        "visual_inspection": "pending",
        "physical_new_window_verified": False,
        "left_open_for_user": False,
        "new_window_required": True,
        "no_deliberate_delays": True,
        "step_logs": {},
    }


def _validate_source(job, result):
    """Check the current source, not merely a previously written audit flag."""
    paths = {
        name: _path(str(job / name), True)
        for name in ("scene.json", SOURCE_NAME, "build-report.json", "audit-report.json")
    }
    slide_count, top_level_counts = _scene_info(paths["scene.json"])
    build_report = read_json(paths["build-report.json"])
    saved_audit = read_json(paths["audit-report.json"])
    current_audit = audit_pptx(paths[SOURCE_NAME])
    for name, report in (("Build", build_report), ("Saved audit", saved_audit), ("Current audit", current_audit)):
        if not isinstance(report, dict) or report.get("passed") is not True:
            raise RuntimeError(name + " validation failed.")
        if report.get("slide_count") != slide_count:
            raise RuntimeError(name + " slide count does not match the scene.")
    if current_audit["counts"] != saved_audit["counts"]:
        raise RuntimeError("Source native counts changed after its structural audit.")
    for name, count in build_report.get("counts", {}).items():
        if current_audit["counts"].get(name) != count:
            raise RuntimeError("Source native counts do not match the build report.")
    if current_audit["counts"].get("raster_count") != 0:
        raise RuntimeError("The generic visible workflow requires native editable objects.")
    if _hash(paths["scene.json"]) != result["scene_sha256"]:
        raise RuntimeError("The job scene differs from the original scene bytes.")
    result.update(
        source_export="complete", structural_validation="passed",
        slide_count=slide_count, native_counts=current_audit["counts"],
        top_level_object_counts=top_level_counts,
        source_pptx_sha256=_hash(paths[SOURCE_NAME]),
    )
    return current_audit, top_level_counts


def _visible(job, result, source_audit, top_level_counts, scripts, wps_python):
    report_path = job / "foreground-report.json"
    result.update(foreground_report=str(report_path), foreground_report_path=str(report_path))
    result["step_logs"]["visible_assembly"] = str(job / "foreground.log")
    try:
        interpreter = _path(wps_python or sys.executable, True)
    except (ValueError, FileNotFoundError, PermissionError) as exc:
        result.update(
            status="pending", visual_execution="unavailable", foreground_status="unavailable",
            error="WPS Python interpreter is unavailable: " + str(exc),
        )
        write_json(report_path, {"status": "unavailable", "error": result["error"]})
        return
    process = run_step([
        str(interpreter), "-B", "-E", "-X", "utf8", str(scripts / "assemble_wps_foreground.py"),
        "--source", result["source_pptx_path"], "--out", result["final_pptx_path"],
        "--report", str(report_path), "--preview-dir", str(job / "wps-preview"),
    ], job / "foreground.log", 900)
    foreground = read_json(report_path) if report_path.is_file() else {}
    if not isinstance(foreground, dict):
        raise RuntimeError("WPS did not produce a valid assembly report.")
    state = foreground.get("status", "error")
    result["foreground_status"] = state
    result["physical_new_window_verified"] = foreground.get("physical_new_window_verified") is True
    for field in (
        "focus_policy", "window_size_policy", "foreground_activation",
        "initial_window_observation", "window_observation", "foreground_verified",
        "new_window_hwnd", "new_window_pid", "left_open_for_user", "source_unchanged",
        "construction_mode", "visible_drawing_verified", "source_reference_hidden",
    ):
        if field in foreground:
            result[field] = foreground[field]
    if process.returncode or state != "complete":
        result.update(
            status="pending" if state in {"pending", "unavailable"} else "error",
            visual_execution=state if state in {"pending", "unavailable"} else "error",
            error=foreground.get("error", "WPS visible assembly is unfinished; inspect foreground.log."),
        )
        return
    if not result["physical_new_window_verified"]:
        result.update(status="pending", visual_execution="pending", foreground_status="pending",
                      error="A separate new WPS top-level window has not been verified.")
        return
    if (foreground.get("construction_mode") != "sequential_native_objects"
            or foreground.get("visible_drawing_verified") is not True):
        raise RuntimeError("WPS did not verify sequential visible construction from empty pages.")
    if foreground.get("source_reference_hidden") is not True:
        raise RuntimeError("WPS did not confirm that the completed source remained hidden during construction.")
    pages = foreground.get("pages")
    if not isinstance(pages, list) or len(pages) != len(top_level_counts):
        raise RuntimeError("WPS did not provide assembly evidence for every page.")
    previews = []
    for index, (page, expected_count) in enumerate(zip(pages, top_level_counts), 1):
        if (not isinstance(page, dict) or page.get("slide") != index
                or page.get("top_level_objects") != expected_count
                or page.get("object_order_preserved") is not True
                or page.get("initial_top_level_objects") != 0
                or page.get("objects_added") != expected_count
                or page.get("incremental_objects_verified") is not True):
            raise RuntimeError("Native object assembly evidence is incomplete on page " + str(index) + ".")
        preview = _path(str(job / "wps-preview" / ("slide-%03d.png" % index)), True)
        if preview.stat().st_size == 0:
            raise RuntimeError("WPS page preview is empty: " + str(preview))
        previews.append(str(preview))
    if foreground.get("slide_count") != len(top_level_counts):
        raise RuntimeError("WPS assembly slide count changed.")
    if foreground.get("native_top_level_objects") != sum(top_level_counts):
        raise RuntimeError("WPS assembly native object count changed.")
    if foreground.get("source_unchanged") is not True or _hash(job / SOURCE_NAME) != result["source_pptx_sha256"]:
        raise RuntimeError("The source PPTX changed during visible assembly.")
    if foreground.get("left_open_for_user") is not True:
        raise RuntimeError("WPS did not confirm that the visibly drawn presentation remains open.")
    result["step_logs"]["final_audit"] = str(job / "foreground-audit.log")
    final_audit_path = job / "foreground-audit-report.json"
    final = run_step([
        sys.executable, "-B", "-E", "-S", "-X", "utf8", str(scripts / "audit_pptx.py"),
        result["final_pptx_path"], "--out", str(final_audit_path),
    ], job / "foreground-audit.log", 60)
    final_report = read_json(final_audit_path) if final_audit_path.is_file() else {}
    if final.returncode or final_report.get("passed") is not True:
        raise RuntimeError("Visible final PPTX failed its native structural audit.")
    if (final_report.get("slide_count") != source_audit["slide_count"]
            or final_report.get("counts") != source_audit["counts"]):
        raise RuntimeError("Visible assembly changed native slide or object counts.")
    result.update(
        status="complete", visual_execution="complete", visible_process_complete=True,
        application_validation="passed; WPS visibly assembled, saved and rendered every page",
        source_pptx_unchanged=True, pptx_path=result["final_pptx_path"],
        foreground_audit_report_path=str(final_audit_path), preview_paths=previews,
        native_progress_evidence=pages,
        message="Visible construction is complete. The new WPS window remains open. Inspect each current preview before claiming visual quality passed.",
    )


def _finish(job, result, original_scene):
    result["scene_unchanged"] = (
        original_scene.is_file() and _hash(original_scene) == result["scene_sha256"]
        and _hash(job / "scene.json") == result["scene_sha256"]
    )
    if not result["scene_unchanged"]:
        result.update(status="error", visual_execution="error", visible_process_complete=False,
                      error="The scene changed during the run.")
    write_json(job / "qa.json", result)
    return result


def run(scene, out_dir, wps_python=None, export_only=False):
    """Create a new job for an arbitrary scene; visible WPS execution is default."""
    if not isinstance(export_only, bool):
        raise ValueError("export_only must be a Boolean.")
    scene = _path(scene, True)
    if scene.suffix.lower() != ".json":
        raise ValueError("Scene must be an existing absolute JSON file.")
    _scene_info(scene)
    job = _path(out_dir)
    if job.exists():
        raise ValueError("Use a new output directory; existing outputs are never overwritten.")
    scripts = _scripts()
    source_hash = _hash(scene)
    job.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(scene, job / "scene.json")
    result = _result(job, scene, source_hash)
    try:
        result["step_logs"]["build"] = str(job / "build.log")
        build = run_step([
            sys.executable, "-B", "-E", "-S", "-X", "utf8", str(scripts / "build_pptx.py"),
            str(job / "scene.json"), "--out", result["source_pptx_path"],
            "--report", result["build_report_path"],
        ], job / "build.log", 60)
        if build.returncode:
            raise RuntimeError("Native PPTX build failed; inspect build.log.")
        result["step_logs"]["source_audit"] = str(job / "audit.log")
        audit = run_step([
            sys.executable, "-B", "-E", "-S", "-X", "utf8", str(scripts / "audit_pptx.py"),
            result["source_pptx_path"], "--out", result["audit_report_path"],
        ], job / "audit.log", 60)
        if audit.returncode:
            raise RuntimeError("Native PPTX source audit failed; inspect audit.log.")
        source_audit, top_level_counts = _validate_source(job, result)
        if export_only:
            result.update(
                status="complete", export_only=True, visual_execution="skipped_by_request",
                foreground_status="skipped_by_request", application_validation="skipped_by_request",
                pptx_path=result["source_pptx_path"],
                message="Source export is complete because export-only was explicitly requested. Visible WPS construction was skipped and has not been completed.",
            )
        else:
            _visible(job, result, source_audit, top_level_counts, scripts, wps_python)
    except Exception as exc:
        result.update(status="error", visual_execution="error", visible_process_complete=False, error=str(exc))
    return _finish(job, result, scene)


def assemble_exported_job(out_dir, wps_python=None):
    """Finish an owned MCP export job without overwriting any existing outputs.

    Required: scene.json, figure-editable.pptx, build-report.json,
    audit-report.json. The caller must have created/selected this job inside its
    configured output root; this function never derives a destination from input
    report strings and refuses any pre-existing visible outputs or QA report.
    """
    job = _path(out_dir)
    if not job.is_dir():
        raise ValueError("Resume requires an existing owned export job directory.")
    for name in VISIBLE_OUTPUTS:
        path = _path(str(job / name))
        if path.exists():
            raise ValueError("Refusing to overwrite an existing job output: " + str(path))
    scene = _path(str(job / "scene.json"), True)
    scripts = _scripts()
    result = _result(job, scene, _hash(scene))
    result["resumed_source_export"] = True
    try:
        source_audit, top_level_counts = _validate_source(job, result)
        result["step_logs"].update(build=str(job / "build.log"), source_audit=str(job / "audit.log"))
        _visible(job, result, source_audit, top_level_counts, scripts, wps_python)
    except Exception as exc:
        result.update(status="error", visual_execution="error", visible_process_complete=False, error=str(exc))
    return _finish(job, result, scene)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scene", help="Existing absolute reviewed scene JSON")
    parser.add_argument("--out-dir", required=True, help="New absolute job directory, or owned export job with --resume-export")
    parser.add_argument("--wps-python", help="Absolute Python executable with pywin32; defaults to this interpreter")
    parser.add_argument("--export-only", action="store_true", help="Explicitly skip WPS; completes source export only")
    parser.add_argument("--resume-export", action="store_true", help="Visibly finish an existing owned export job with no visible/QA outputs")
    args = parser.parse_args(argv)
    try:
        if args.resume_export:
            if args.scene or args.export_only:
                raise ValueError("--resume-export cannot be combined with --scene or --export-only.")
            result = assemble_exported_job(args.out_dir, args.wps_python)
        else:
            if not args.scene:
                raise ValueError("--scene is required unless --resume-export is used.")
            result = run(args.scene, args.out_dir, args.wps_python, args.export_only)
    except Exception as exc:
        result = {"status": "error", "visual_execution": "error", "visible_process_complete": False, "error": str(exc)}
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0 if result["status"] in {"complete", "pending"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
