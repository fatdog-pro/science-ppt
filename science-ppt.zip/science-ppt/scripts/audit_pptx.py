#!/usr/bin/env python3
"""Audit editable, vector-only PPTX object structure with Python's standard library.

Run: python audit_pptx.py figure.pptx --out audit-report.json
This checks OOXML packaging and native objects. It does not render slides or
establish scientific correctness, font availability, or visual fidelity.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import posixpath
import re
import sys
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET
import zipfile

NS = {
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
    "ct": "http://schemas.openxmlformats.org/package/2006/content-types",
}
COUNTS = ("text_count", "shape_count", "path_count", "connector_count",
          "group_count", "raster_count", "element_count", "arrow_count")
MAX_PARTS = 2000
MAX_UNCOMPRESSED = 100 * 1024 * 1024
ARROWS = {"none", "triangle", "stealth", "diamond", "oval", "arrow"}


def tag(prefix, name):
    return f"{{{NS[prefix]}}}{name}"


def relationship_part(owner):
    if not owner:
        return "_rels/.rels"
    folder, filename = posixpath.split(owner)
    return posixpath.join(folder, "_rels", filename + ".rels")


def relationship_owner(part):
    if part == "_rels/.rels":
        return ""
    folder, filename = posixpath.split(part)
    if posixpath.basename(folder) != "_rels" or not filename.endswith(".rels"):
        return None
    return posixpath.join(posixpath.dirname(folder), filename[:-5])


def resolve_target(owner, target):
    """Resolve OPC targets without extracting ZIP entries onto the filesystem."""
    parsed = urlsplit(target)
    if parsed.scheme or parsed.netloc or parsed.query or parsed.fragment or "\\" in target:
        raise ValueError("invalid internal relationship target")
    target = unquote(parsed.path)
    if not target or "\x00" in target:
        raise ValueError("empty or invalid relationship target")
    joined = target.lstrip("/") if target.startswith("/") else posixpath.join(posixpath.dirname(owner), target)
    resolved = posixpath.normpath(joined)
    if resolved in {"", ".", ".."} or resolved.startswith("../"):
        raise ValueError("relationship target escapes package")
    return resolved


def integer(value, where, errors, minimum=0):
    if value is None or not re.fullmatch(r"-?\d+", value):
        errors.append(f"{where}: expected an integer")
        return None
    result = int(value)
    if result < minimum:
        errors.append(f"{where}: must be >= {minimum}")
        return None
    return result


def audit_slide(xml, part, errors):
    counts = {key: 0 for key in COUNTS}
    objects, ids, text_records, arrow_records = [], {}, [], []
    for nv in xml.iter(tag("p", "cNvPr")):
        num = integer(nv.get("id"), f"{part} object id", errors, 1)
        if num is not None:
            if num in ids:
                errors.append(f"{part}: duplicate object id {num}")
            ids[num] = nv.get("name", "")
    object_kinds = {tag("p", "sp"), tag("p", "cxnSp"), tag("p", "grpSp")}
    forbidden = {tag("p", "pic"), tag("p", "graphicFrame"), tag("p", "oleObj"),
                 tag("p", "contentPart"), tag("a", "blip"), tag("a", "videoFile"),
                 tag("a", "audioFile"), tag("a", "wavAudioFile")}
    for element in xml.iter():
        if element.tag in forbidden:
            errors.append(f"{part}: non-native drawing object {element.tag.split('}')[-1]} is forbidden")
            if element.tag in {tag("p", "pic"), tag("a", "blip")}:
                counts["raster_count"] += 1
        if element.tag not in object_kinds:
            continue
        counts["element_count"] += 1
        nv = element.find("./*/p:cNvPr", NS)
        object_id, name = (nv.get("id"), nv.get("name", "")) if nv is not None else (None, "")
        if nv is None:
            errors.append(f"{part}: drawing object lacks nonvisual id/name properties")
        kind = "group" if element.tag == tag("p", "grpSp") else "line" if element.tag == tag("p", "cxnSp") else "shape"
        props = element.find("p:grpSpPr" if kind == "group" else "p:spPr", NS)
        if props is None:
            errors.append(f"{part} {name}: missing native shape properties")
        else:
            tx = props.find("a:xfrm", NS)
            if tx is None:
                errors.append(f"{part} {name}: missing transform")
            else:
                for child, names in (("off", ("x", "y")), ("ext", ("cx", "cy"))):
                    coord = tx.find("a:" + child, NS)
                    if coord is None:
                        errors.append(f"{part} {name}: missing transform {child}")
                    else:
                        for attr in names:
                            integer(coord.get(attr), f"{part} {name} {child}.{attr}", errors, 0)
                if kind == "group":
                    for child in ("chOff", "chExt"):
                        coord = tx.find("a:" + child, NS)
                        if coord is None:
                            errors.append(f"{part} {name}: missing group {child}")
                        else:
                            for attr in (("x", "y") if child == "chOff" else ("cx", "cy")):
                                integer(coord.get(attr), f"{part} {name} {child}.{attr}", errors, 1 if child == "chExt" else 0)
                ext = tx.find("a:ext", NS)
                if ext is not None:
                    if kind == "line":
                        if ext.get("cx") == "0" and ext.get("cy") == "0":
                            errors.append(f"{part} {name}: zero-length connector")
                    elif ext.get("cx") == "0" or ext.get("cy") == "0":
                        errors.append(f"{part} {name}: shape/group dimensions must be positive")
        if kind == "group":
            counts["group_count"] += 1
        elif kind == "line":
            counts["connector_count"] += 1
        elif props is not None and props.find("a:custGeom", NS) is not None:
            counts["path_count"] += 1
            kind = "path"
            paths = props.findall("a:custGeom/a:pathLst/a:path", NS)
            if not paths:
                errors.append(f"{part} {name}: custom geometry has no paths")
            for path in paths:
                for axis in ("w", "h"):
                    integer(path.get(axis), f"{part} {name} path.{axis}", errors, 1)
                if not list(path) or list(path)[0].tag != tag("a", "moveTo"):
                    errors.append(f"{part} {name}: custom path must begin with moveTo")
                for point in path.iter(tag("a", "pt")):
                    for axis in ("x", "y"):
                        integer(point.get(axis), f"{part} {name} path point.{axis}", errors, 0)
        elif kind == "shape":
            textbox = element.find("p:nvSpPr/p:cNvSpPr", NS)
            if textbox is not None and textbox.get("txBox") in {"1", "true"}:
                kind = "text"
            else:
                counts["shape_count"] += 1
            if props is not None and props.find("a:prstGeom", NS) is None:
                errors.append(f"{part} {name}: missing preset/custom geometry")
        text_body = element.find("p:txBody", NS)
        if text_body is not None:
            counts["text_count"] += 1
            text = "\n".join("".join(p.itertext()) for p in text_body.findall("a:p", NS))
            fonts = sorted({f.get("typeface") for f in text_body.iter() if f.tag in {tag("a", "latin"), tag("a", "ea")} and f.get("typeface")})
            text_records.append({"id": object_id, "name": name, "text": text, "fonts": fonts})
        elif kind == "text":
            errors.append(f"{part} {name}: textbox has no editable text body")
        if props is not None:
            for endpoint in ("headEnd", "tailEnd"):
                end = props.find("a:ln/a:" + endpoint, NS)
                if end is None:
                    continue
                arrow = end.get("type", "none")
                if arrow not in ARROWS:
                    errors.append(f"{part} {name}: unsupported native arrow {arrow}")
                if arrow != "none":
                    counts["arrow_count"] += 1
                    arrow_records.append({"id": object_id, "name": name, "endpoint": "start" if endpoint == "headEnd" else "end", "type": arrow})
        objects.append({"id": object_id, "name": name, "type": kind})
    valid_targets = {int(o["id"]) for o in objects if o["id"] and o["id"].isdigit() and o["type"] in {"shape", "text", "path"}}
    for ref in list(xml.iter(tag("a", "stCxn"))) + list(xml.iter(tag("a", "endCxn"))):
        target = integer(ref.get("id"), f"{part} connector target", errors, 1)
        if target not in valid_targets:
            errors.append(f"{part}: connector references missing or unsupported object {ref.get('id')}")
        site = integer(ref.get("idx"), f"{part} connector site", errors, 0)
        if site is not None and site > 3:
            errors.append(f"{part}: connector site must be 0..3 in this scene format")
    if counts["text_count"] + counts["shape_count"] + counts["path_count"] + counts["connector_count"] == 0:
        errors.append(f"{part}: no native editable drawing objects")
    return {"part": part, "counts": counts, "objects": objects, "texts": text_records, "arrows": arrow_records}


def audit_pptx(path):
    path = Path(path)
    errors, warnings, slides = [], [], []
    dimensions = None
    relationship_count = 0
    xml_parts, relationship_maps = {}, {}
    try:
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            filenames = [entry.filename for entry in entries]
            duplicates = [name for name, count in Counter(filenames).items() if count > 1]
            errors.extend(f"duplicate ZIP part: {name}" for name in duplicates)
            if len(entries) > MAX_PARTS or sum(e.file_size for e in entries) > MAX_UNCOMPRESSED:
                raise ValueError("PPTX exceeds audit size limits (2000 parts / 100 MiB uncompressed)")
            names = set(filenames)
            for entry in entries:
                name = entry.filename
                if name.endswith("/"):
                    continue
                if name.startswith("/") or "\\" in name or posixpath.normpath(name) != name or name.startswith("../"):
                    errors.append(f"invalid ZIP part name: {name}")
                if entry.flag_bits & 1:
                    errors.append(f"encrypted ZIP part is forbidden: {name}")
                    continue
                if name.startswith("ppt/media/") or name.startswith("ppt/embeddings/"):
                    errors.append(f"media/embedded part is forbidden in native vector mode: {name}")
                if name.endswith(".xml") or name.endswith(".rels"):
                    try:
                        xml_parts[name] = ET.fromstring(archive.read(entry))
                    except ET.ParseError as exc:
                        errors.append(f"{name}: invalid XML: {exc}")
            for required in ("[Content_Types].xml", "_rels/.rels", "ppt/presentation.xml", "ppt/_rels/presentation.xml.rels"):
                if required not in xml_parts:
                    errors.append(f"missing or invalid required part: {required}")
            for name, xml in xml_parts.items():
                if not name.endswith(".rels"):
                    continue
                owner = relationship_owner(name)
                if owner is None:
                    errors.append(f"invalid relationship part location: {name}")
                    continue
                if owner and owner not in names:
                    errors.append(f"{name}: relationship owner is missing: {owner}")
                if xml.tag != tag("rel", "Relationships"):
                    errors.append(f"{name}: incorrect relationship root")
                mapping = {}
                for rel in xml.findall("rel:Relationship", NS):
                    relationship_count += 1
                    rid, target, typ = rel.get("Id"), rel.get("Target"), rel.get("Type", "")
                    if not rid or rid in mapping:
                        errors.append(f"{name}: missing/duplicate relationship id {rid}")
                    if rel.get("TargetMode", "Internal") != "Internal":
                        errors.append(f"{name}: external relationship is forbidden: {target}")
                        continue
                    try:
                        resolved = resolve_target(owner, target or "")
                    except ValueError as exc:
                        errors.append(f"{name}: {exc}: {target}")
                        continue
                    if resolved not in names:
                        errors.append(f"{name}: missing relationship target: {resolved}")
                    if any(typ.endswith("/" + kind) for kind in ("image", "oleObject", "video", "audio", "vbaProject")):
                        errors.append(f"{name}: forbidden relationship type: {typ}")
                    if not typ.startswith((NS["r"] + "/", NS["rel"] + "/")):
                        errors.append(f"{name}: unsupported relationship type URI: {typ}")
                    mapping[rid] = {"target": resolved, "type": typ}
                relationship_maps[owner] = mapping
            for name, xml in xml_parts.items():
                if name.endswith(".rels"):
                    continue
                if any(element.tag in {tag("p", "pic"), tag("a", "blip"), tag("p", "oleObj"), tag("a", "videoFile"), tag("a", "audioFile")} for element in xml.iter()):
                    errors.append(f"{name}: embedded picture/media markup is forbidden in native vector mode")
                mapping = relationship_maps.get(name, {})
                for element in xml.iter():
                    for attr, value in element.attrib.items():
                        if attr.startswith("{" + NS["r"] + "}") and value not in mapping:
                            errors.append(f"{name}: unresolved relationship reference {value}")
            top = relationship_maps.get("", {})
            offices = [r for r in top.values() if r["type"] == NS["r"] + "/officeDocument"]
            if len(offices) != 1 or offices[0]["target"] != "ppt/presentation.xml":
                errors.append("root relationships: expected exactly one presentation officeDocument")
            ct = xml_parts.get("[Content_Types].xml")
            if ct is not None:
                defaults = {e.get("Extension"): e.get("ContentType") for e in ct.findall("ct:Default", NS)}
                overrides = {e.get("PartName", "").lstrip("/"): e.get("ContentType") for e in ct.findall("ct:Override", NS)}
                for name in names:
                    if name == "[Content_Types].xml" or name.endswith("/"):
                        continue
                    if not overrides.get(name) and not defaults.get(name.rsplit(".", 1)[-1]):
                        errors.append(f"{name}: no content type declaration")
                for name in overrides:
                    if name not in names:
                        errors.append(f"content type override references missing part: {name}")
                expected_types = {
                    "ppt/presentation.xml": "presentationml.presentation.main",
                    "ppt/theme/theme1.xml": "theme",
                }
                for name in names:
                    for pattern, kind in ((r"ppt/slides/slide\d+\.xml", "presentationml.slide"),
                                          (r"ppt/slideMasters/slideMaster\d+\.xml", "presentationml.slideMaster"),
                                          (r"ppt/slideLayouts/slideLayout\d+\.xml", "presentationml.slideLayout"),
                                          (r"ppt/notesSlides/notesSlide\d+\.xml", "presentationml.notesSlide"),
                                          (r"ppt/notesMasters/notesMaster\d+\.xml", "presentationml.notesMaster")):
                        if re.fullmatch(pattern, name):
                            expected_types[name] = kind
                for name, kind in expected_types.items():
                    expected = "application/vnd.openxmlformats-officedocument." + kind + "+xml"
                    if name in names and overrides.get(name) != expected:
                        errors.append(f"{name}: incorrect OOXML content type; expected {expected}")
            pres = xml_parts.get("ppt/presentation.xml")
            ordered_slides = []
            if pres is not None:
                size = pres.find("p:sldSz", NS)
                if size is None:
                    errors.append("presentation: slide dimensions missing")
                else:
                    width = integer(size.get("cx"), "slide width", errors, 1)
                    height = integer(size.get("cy"), "slide height", errors, 1)
                    if width and height:
                        dimensions = {"width_emu": width, "height_emu": height, "width_in": width / 914400, "height_in": height / 914400, "aspect_ratio": width / height}
                slide_ids = set()
                for entry in pres.findall("p:sldIdLst/p:sldId", NS):
                    sid = integer(entry.get("id"), "presentation slide id", errors, 256)
                    if sid in slide_ids:
                        errors.append(f"presentation: duplicate slide id {sid}")
                    slide_ids.add(sid)
                    rel = relationship_maps.get("ppt/presentation.xml", {}).get(entry.get(tag("r", "id")))
                    if rel is not None:
                        if rel["type"] != NS["r"] + "/slide":
                            errors.append("presentation: slide id does not reference a slide relationship")
                        ordered_slides.append(rel["target"])
                if not ordered_slides:
                    errors.append("presentation: no slides")
                if len(set(ordered_slides)) != len(ordered_slides):
                    errors.append("presentation: duplicate slide references")
            actual_slides = {name for name in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", name)}
            if actual_slides != set(ordered_slides):
                errors.append("presentation slide list and slide parts differ")
            for part in ordered_slides:
                if part in xml_parts:
                    if xml_parts[part].tag != tag("p", "sld"):
                        errors.append(f"{part}: incorrect slide root")
                    slides.append(audit_slide(xml_parts[part], part, errors))
    except (OSError, ValueError, zipfile.BadZipFile, RuntimeError) as exc:
        errors.append(str(exc))
    return {"passed": not errors, "file": str(path.resolve()), "slide_count": len(slides),
            "dimensions": dimensions, "relationship_count": relationship_count,
            "counts": {key: sum(s["counts"][key] for s in slides) for key in COUNTS},
            "slides": slides, "errors": errors, "warnings": warnings,
            "limitations": ["Structural XML audit only; visual fidelity, text fit, scientific correctness and installed fonts require separate inspection."]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pptx", help="PPTX file to inspect")
    parser.add_argument("--out", help="JSON audit report")
    args = parser.parse_args(argv)
    if args.out and Path(args.out).resolve() == Path(args.pptx).resolve():
        print("ERROR: --out cannot overwrite input PPTX", file=sys.stderr)
        return 2
    report = audit_pptx(args.pptx)
    if args.out:
        try:
            output = Path(args.out)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        except OSError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 2
    else:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report["passed"]:
        for error in report["errors"]:
            print("ERROR: " + error, file=sys.stderr)
        return 2
    print(f"OK: {report['slide_count']} slides; native objects={report['counts']['element_count']}; raster=0", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
