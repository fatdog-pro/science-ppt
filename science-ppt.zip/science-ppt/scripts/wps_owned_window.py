"""WPS-native host launch and exact owned-document binding; no generic UI clicks."""
import os
from pathlib import Path
import subprocess
import time

def frames(gui,process):
    found={}
    def collect(h,u):
        title=gui.GetWindowText(h)
        if gui.IsWindowVisible(h) and not gui.GetWindow(h,4) and gui.GetAncestor(h,2)==h and (title=='WPS Office' or title.endswith(' - WPS Office')):
            found[h]={'hwnd':h,'title':title,'pid':process.GetWindowThreadProcessId(h)[1]}
    gui.EnumWindows(collect,None)
    return found

def ready(check,pythoncom,seconds=20):
    deadline=time.monotonic()+seconds
    while time.monotonic()<deadline:
        result=check()
        if result:return result
        pythoncom.PumpWaitingMessages();time.sleep(.05)
    raise RuntimeError('WPS host/COM readiness timeout; independent window not verified')

def bind_owned(path,pythoncom,client):
    rot=pythoncom.GetRunningObjectTable();enum=rot.EnumRunning();ctx=pythoncom.CreateBindCtx(0)
    while True:
        items=enum.Next(1)
        if not items:return None
        moniker=items[0]
        try:
            if os.path.normcase(moniker.GetDisplayName(ctx,None))!=os.path.normcase(str(path)):continue
            obj=client.Dispatch(rot.GetObject(moniker).QueryInterface(pythoncom.IID_IDispatch))
            if os.path.normcase(str(obj.FullName))==os.path.normcase(str(path)):return obj
        except pythoncom.com_error:continue

def observe_owned_frame(h,path,gui):
    if not gui.IsWindow(h) or path.name not in gui.GetWindowText(h):raise RuntimeError('Owned task frame does not display expected file')
    active=gui.GetForegroundWindow()
    placement=gui.GetWindowPlacement(h)
    return dict(visible=bool(gui.IsWindowVisible(h)),minimized=bool(gui.IsIconic(h)),
                foreground=bool(active and gui.GetAncestor(active,2)==h),
                show_command=placement[1],normal_position=list(placement[4]),
                window_rect=list(gui.GetWindowRect(h)))

def open_new_frame(host,path,pythoncom,client,gui,process):
    host=Path(host)
    if not host.is_file() or host.name.lower()!='wpp.exe':raise RuntimeError('WPS presentation executable not found')
    before=frames(gui,process)
    subprocess.Popen([str(host),'/n',str(path)],shell=False)
    new=ready(lambda:next((v for h,v in frames(gui,process).items() if h not in before and path.name in v['title']),None),pythoncom)
    h=new['hwnd']
    target=ready(lambda:bind_owned(path,pythoncom,client),pythoncom)
    if int(target.Slides.Count)!=1 or int(target.Slides.Item(1).Shapes.Count):raise RuntimeError('New target is not our empty PPT')
    state=observe_owned_frame(h,path,gui)
    return target,dict(physical_new_window_verified=True,new_window_verified_before_drawing=True,
                       new_window_hwnd=h,new_window_pid=new['pid'],existing_frame_hwnds=list(before),
                       new_window_title=gui.GetWindowText(h),initial_window_observation=state,
                       focus_policy='respect_user_focus',window_size_policy='respect_user_geometry')
