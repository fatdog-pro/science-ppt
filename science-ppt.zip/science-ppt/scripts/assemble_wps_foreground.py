"""Assemble native objects in a verified new foreground WPS application frame."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import stat
from wps_owned_window import open_new_frame, observe_owned_frame

def checked(raw, existing=False):
    p=Path(raw)
    if not p.is_absolute() or '..' in p.parts: raise ValueError('Use an absolute path without ..')
    for item in (p,*p.parents):
        try: info=item.lstat()
        except FileNotFoundError: continue
        if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400: raise ValueError('Reparse paths are not allowed')
    if existing and not p.is_file(): raise ValueError('Source PPTX does not exist')
    return p

def log(**data): print(json.dumps(data,ensure_ascii=False),file=sys.stderr,flush=True)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def assemble(source_path,output,preview_dir,report_path):
    source_path=checked(source_path,True); output=checked(output); preview_dir=checked(preview_dir); report_path=checked(report_path)
    if source_path.suffix.lower()!='.pptx' or output.suffix.lower()!='.pptx': raise ValueError('PPTX required')
    for p in (output,preview_dir,report_path):
        if p.exists(): raise ValueError('Refusing existing output: '+str(p))
        if not p.parent.is_dir(): raise ValueError('Output parent must exist')
    original_hash=digest(source_path)
    report=dict(status='pending',source=str(source_path),output=str(output),method='WPS native foreground object assembly',
        no_deliberate_delays=True,new_document=True,new_window_requested=True,source_sha256=original_hash,
        visual_inspection='pending',physical_new_window_verified=False,pages=[],left_open_for_user=False)
    report.update(focus_policy='respect_user_focus',window_size_policy='respect_user_geometry',
                  foreground_activation='not_requested',construction_mode='sequential_native_objects',
                  source_reference_hidden=True,visible_drawing_verified=False)
    try:
        import pythoncom
        import win32com.client
        import win32clipboard
        import win32gui
        import win32process
    except ImportError as e:
        report.update(status='unavailable',error=str(e))
        report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        return report
    pythoncom.CoInitialize()
    app=source=target=window=original=pasted=reference_slide=slide=None
    owns_source=False
    try:
        try: app=win32com.client.GetActiveObject('KWPP.Application')
        except pythoncom.com_error: app=win32com.client.Dispatch('KWPP.Application')
        app.Visible=-1
        source=app.Presentations.Open(str(source_path),-1,0,0); owns_source=True
        total=int(source.Slides.Count)
        if not 1<=total<=100: raise ValueError('Source must contain 1-100 slides')
        preview_dir.mkdir()
        target=app.Presentations.Add(0)
        if int(target.Slides.Count)!=0: raise RuntimeError('New presentation is not empty')
        target.PageSetup.SlideWidth=source.PageSetup.SlideWidth
        target.PageSetup.SlideHeight=source.PageSetup.SlideHeight
        slide=target.Slides.Add(1,12)
        target.SaveAs(str(output),24)
        report['stage']='create_independent_application_frame'
        host=checked(str(Path(str(app.Path))/'wpp.exe'),True)
        target.Close(); target=None
        source.Close(); source=None; owns_source=False
        target,evidence=open_new_frame(host,output,pythoncom,win32com.client,win32gui,win32process)
        report.update(evidence)
        app=target.Application
        source=app.Presentations.Open(str(source_path),-1,0,0);owns_source=True
        window=target.Windows.Item(1)
        slide=target.Slides.Item(1)
        log(status='new_window_ready',window_hwnd=report['new_window_hwnd'],output=str(output),slides=total)
        for page_number in range(1,total+1):
            reference_slide=source.Slides.Item(page_number)
            report['stage']='assemble_slide_'+str(page_number)
            reference_slide.Export(str(preview_dir/f'original-slide-{page_number:03d}.png'),'PNG',1600,900)
            if page_number>1: slide=target.Slides.Add(page_number,12)
            initial_count=int(slide.Shapes.Count)
            if initial_count:raise RuntimeError('Visible drawing target page is not empty')
            slide.FollowMasterBackground=0; slide.Background.Fill.Solid()
            slide.Background.Fill.ForeColor.RGB=reference_slide.Background.Fill.ForeColor.RGB
            window.View.GotoSlide(page_number)
            count=int(reference_slide.Shapes.Count)
            log(status='drawing_slide',slide=page_number,total_slides=total,top_level_objects=count)
            original_names=[]
            for index in range(1,count+1):
                original=reference_slide.Shapes.Item(index)
                for attempt in range(5):
                    previous=win32clipboard.GetClipboardSequenceNumber(); original.Copy()
                    deadline=time.monotonic()+1
                    while win32clipboard.GetClipboardSequenceNumber()==previous and time.monotonic()<deadline:
                        pythoncom.PumpWaitingMessages(); time.sleep(.01)
                    if win32clipboard.GetClipboardSequenceNumber()==previous: continue
                    try: slide.Shapes.Paste()
                    except pythoncom.com_error: pass
                    actual=int(slide.Shapes.Count)
                    if actual>index: raise RuntimeError('Unexpected duplicate native object')
                    if actual==index: break
                    pythoncom.PumpWaitingMessages(); time.sleep(.03)
                if int(slide.Shapes.Count)!=index: raise RuntimeError(f'Paste failed on slide {page_number}, object {index}')
                pasted=slide.Shapes.Item(index)
                for key in ('Left','Top','Width','Height'): setattr(pasted,key,getattr(original,key))
                pasted.Name=original.Name; original_names.append(str(original.Name)); pythoncom.PumpWaitingMessages()
                log(status='native_object_added',slide=page_number,object_index=index,total_objects=count)
            actual_names=[str(slide.Shapes.Item(i).Name) for i in range(1,count+1)]
            if actual_names!=original_names: raise RuntimeError('Native object order changed')
            target.Save()
            image_path=preview_dir/f'slide-{page_number:03d}.png'
            slide.Export(str(image_path),'PNG',1600,900)
            if total==1:
                reference_slide.Export(str(preview_dir/'original-preview.png'),'PNG',1600,900)
                slide.Export(str(preview_dir/'final-preview.png'),'PNG',1600,900)
            report['pages'].append(dict(slide=page_number,top_level_objects=count,object_order_preserved=True,preview=str(image_path),
                initial_top_level_objects=initial_count,objects_added=count,incremental_objects_verified=True,
                window_observation=observe_owned_frame(report['new_window_hwnd'],output,win32gui)))
            log(status='slide_complete',slide=page_number,total_slides=total)
        target.Save()
        original=pasted=reference_slide=slide=None
        source.Close();source=None;owns_source=False
        report['window_observation']=observe_owned_frame(report['new_window_hwnd'],output,win32gui)
        report['foreground_verified']=report['window_observation']['foreground']
        report.update(status='complete',slide_count=int(target.Slides.Count),source_unchanged=digest(source_path)==original_hash,
            original_formatting_preserved=True,left_open_for_user=True,
            visible_drawing_verified=bool(report['physical_new_window_verified'] and len(report['pages'])==total and
                all(p['initial_top_level_objects']==0 and p['incremental_objects_verified'] and p['object_order_preserved'] for p in report['pages'])),
            native_top_level_objects=sum(p['top_level_objects'] for p in report['pages']))
        if not report['source_unchanged']: raise RuntimeError('Source changed')
    except Exception as e:
        report.update(status='error',error=str(e),source_unchanged=digest(source_path)==original_hash)
        if target is not None:
            try: target.Save(); report['partial_output']=str(output); report['left_open_for_user']=True
            except Exception: pass
    finally:
        original=pasted=reference_slide=slide=None
        if owns_source and source is not None:
            try: source.Close()
            except Exception: pass
        source=target=window=app=None; pythoncom.CoUninitialize()
        report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--out',required=True)
    p.add_argument('--preview-dir',required=True);p.add_argument('--report',required=True)
    a=p.parse_args()
    try: r=assemble(a.source,a.out,a.preview_dir,a.report)
    except Exception as e: r=dict(status='error',error=str(e))
    print(json.dumps(r,ensure_ascii=False),flush=True)
    return 0 if r['status']=='complete' else 1
if __name__=='__main__': raise SystemExit(main())
