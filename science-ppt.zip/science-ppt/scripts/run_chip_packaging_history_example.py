"""Reproduce the bundled 10-page chip packaging history in a new, visible WPS window."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

from run_multimodal_route_example import checked_path, read_json, run_step, write_json


def run(out_dir, wps_python=None, export_only=False):
    out_dir = checked_path(out_dir)
    if out_dir.exists():
        raise ValueError("Use a new output directory; existing outputs are never overwritten.")
    skill_root = Path(__file__).resolve().parent.parent
    scripts = skill_root / "scripts"
    example = skill_root / "assets" / "examples" / "chip-packaging-history"
    resources = {
        name: checked_path(str(example / name), True)
        for name in ("scene.json", "brief.json", "sources.md", "manifest.json")
    }
    for name in ("build_pptx.py", "audit_pptx.py", "assemble_wps_foreground.py"):
        checked_path(str(scripts / name), True)
    source_hash = hashlib.sha256(resources["scene.json"].read_bytes()).hexdigest()
    manifest = read_json(resources["manifest.json"])
    if source_hash != manifest["scene_sha256"]:
        raise ValueError("The fixed bundled scene does not match its manifest.")
    scene = read_json(resources["scene.json"])
    if len(scene.get("slides", [])) != manifest["page_count"]:
        raise ValueError("The bundled example must contain exactly 10 pages.")
    top_level_count = sum(len(page["elements"]) for page in scene["slides"])
    if top_level_count != manifest["top_level_element_count"]:
        raise ValueError("The bundled scene's top-level object count changed.")
    out_dir.mkdir(parents=True)
    for name, source in resources.items():
        shutil.copyfile(source, out_dir / name)
    result = {
        "status": "pending",
        "example": "chip-packaging-history",
        "output_directory": str(out_dir),
        "job_dir": str(out_dir),
        "scene_sha256": source_hash,
        "source_scene": str(resources["scene.json"]),
        "scene_unchanged": True,
        "export_pptx": str(out_dir / "figure-editable.pptx"),
        "foreground_pptx": str(out_dir / "chip-packaging-history-foreground.pptx"),
        "pptx_path": str(out_dir / "figure-editable.pptx"),
        "structural_validation": "pending",
        "foreground_status": "pending",
        "visual_inspection": "pending",
        "new_window_required": True,
        "no_deliberate_delays": True,
        "top_level_element_count": top_level_count,
        "qa_report": str(out_dir / "qa.json"),
        "qa_path": str(out_dir / "qa.json"),
        "build_report_path": str(out_dir / "build-report.json"),
        "audit_report_path": str(out_dir / "audit-report.json"),
    }
    try:
        build = run_step([
            sys.executable, "-E", "-S", "-X", "utf8", str(scripts / "build_pptx.py"),
            str(out_dir / "scene.json"), "--out", result["export_pptx"],
            "--report", result["build_report_path"],
        ], out_dir / "build.log", 60)
        if build.returncode:
            raise RuntimeError("Native PPTX build failed; inspect build.log.")
        audit = run_step([
            sys.executable, "-E", "-S", "-X", "utf8", str(scripts / "audit_pptx.py"),
            result["export_pptx"], "--out", result["audit_report_path"],
        ], out_dir / "audit.log", 60)
        audit_report = read_json(out_dir / "audit-report.json")
        if audit.returncode or not audit_report.get("passed"):
            raise RuntimeError("Native PPTX structural audit failed; inspect audit-report.json.")
        if audit_report["slide_count"] != manifest["page_count"] or audit_report["counts"] != manifest["native_counts"]:
            raise RuntimeError("Export changed the fixed example's native counts.")
        result.update(structural_validation="passed", slide_count=audit_report["slide_count"], native_counts=audit_report["counts"])
        if export_only:
            result.update(status="complete", application_validation="pending; export-only requested")
        else:
            report_path = out_dir / "foreground-report.json"
            result.update(foreground_report=str(report_path), foreground_report_path=str(report_path))
            try:
                interpreter = checked_path(wps_python or sys.executable, True)
                foreground = run_step([
                    str(interpreter), "-E", "-X", "utf8", str(scripts / "assemble_wps_foreground.py"),
                    "--source", result["export_pptx"], "--out", result["foreground_pptx"],
                    "--report", str(report_path), "--preview-dir", str(out_dir / "wps-preview"),
                ], out_dir / "foreground.log", 600)
                foreground_report = read_json(report_path) if report_path.is_file() else {}
                state = foreground_report.get("status", "error")
                returncode = foreground.returncode
            except (ValueError, FileNotFoundError, PermissionError) as exc:
                foreground_report = {"status": "unavailable", "error": "WPS Python interpreter is unavailable: " + str(exc)}
                write_json(report_path, foreground_report)
                state, returncode = "unavailable", 1
            result["foreground_status"] = state
            result["physical_new_window_verified"] = foreground_report.get("physical_new_window_verified", False)
            for field in ("focus_policy", "window_size_policy", "initial_window_observation", "window_observation", "foreground_verified"):
                if field in foreground_report:
                    result[field] = foreground_report[field]
            if returncode or state != "complete":
                result.update(status="pending" if state in {"pending", "unavailable"} else "error", application_validation="pending", error=foreground_report.get("error", "WPS assembly is unfinished; inspect foreground.log."))
            elif not result["physical_new_window_verified"]:
                result.update(status="pending", foreground_status="pending", application_validation="pending", error="The independent new WPS top-level window has not been verified.")
            else:
                final_audit_path = out_dir / "foreground-audit-report.json"
                final_audit = run_step([
                    sys.executable, "-E", "-S", "-X", "utf8", str(scripts / "audit_pptx.py"),
                    result["foreground_pptx"], "--out", str(final_audit_path),
                ], out_dir / "foreground-audit.log", 60)
                final_report = read_json(final_audit_path)
                if final_audit.returncode or not final_report.get("passed"):
                    raise RuntimeError("WPS output structural audit failed; inspect foreground-audit-report.json.")
                if final_report["counts"] != manifest["native_counts"] or final_report["slide_count"] != manifest["page_count"]:
                    raise RuntimeError("WPS assembly changed native object counts.")
                result.update(
                    status="complete",
                    application_validation="passed; WPS assembled, saved and rendered all 10 pages",
                    left_open_for_user=foreground_report.get("left_open_for_user", False),
                    source_pptx_unchanged=foreground_report.get("source_unchanged", False),
                    pptx_path=result["foreground_pptx"],
                    foreground_audit_report_path=str(final_audit_path),
                    preview_paths=[str(out_dir / "wps-preview" / ("slide-%03d.png" % n)) for n in range(1, 11)],
                    reference_preview_paths=[str(out_dir / "wps-preview" / ("original-slide-%03d.png" % n)) for n in range(1, 11)],
                )
                for field in ("new_window_verified", "physical_new_window", "new_window_evidence", "window_handle"):
                    if field in foreground_report:
                        result[field] = foreground_report[field]
    except Exception as exc:
        result.update(status="error", error=str(exc))
    result["scene_unchanged"] = hashlib.sha256(resources["scene.json"].read_bytes()).hexdigest() == source_hash
    if not result["scene_unchanged"]:
        result.update(status="error", error="The bundled scene changed during reproduction.")
    write_json(out_dir / "qa.json", result)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", required=True, help="New absolute directory for this reproduction")
    parser.add_argument("--wps-python", help="Absolute Python executable with pywin32; defaults to this interpreter")
    parser.add_argument("--export-only", action="store_true", help="Build and audit only; WPS and visual checks remain pending")
    args = parser.parse_args(argv)
    try:
        result = run(args.out_dir, args.wps_python, args.export_only)
    except Exception as exc:
        result = {"status": "error", "error": str(exc)}
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0 if result["status"] in {"complete", "pending"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
