#!/usr/bin/env python3
"""Local newline-delimited STDIO MCP bridge; Python 3.10+, standard library only.

This server exports a scene designed directly from a text brief by the agent.
No image generation, API key, arbitrary shell, image fetch, or config mutation.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
from typing import Any

VERSION = "3.3.1"
PROTOCOLS = ("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05")
MAX_LINE = 8 * 1024 * 1024
MAX_SCENE_BYTES = 4 * 1024 * 1024
JOB_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,79}\Z")
RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}


class RpcError(Exception):
    def __init__(self, code: int, message: str):
        super().__init__(message)
        self.code = code


class ExportError(Exception):
    pass


def reject_constant(value: str) -> None:
    raise ValueError(f"Non-finite JSON value: {value}")


def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON member: {key}")
        result[key] = value
    return result


def json_loads(value: str) -> Any:
    return json.loads(value, object_pairs_hook=unique_object, parse_constant=reject_constant)


def no_links(path: Path) -> None:
    """Reject existing symlinks and Windows reparse points in every ancestor."""
    for part in reversed((path, *path.parents)):
        try:
            info = part.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ExportError(f"Symlink/reparse path is not allowed: {part}")


def prepare_root(raw: str) -> Path:
    path = Path(raw).expanduser()
    if not path.is_absolute():
        raise ExportError("--output-root must be an absolute path")
    if ".." in path.parts:
        raise ExportError("--output-root must not contain '..'")
    no_links(path)
    path.mkdir(parents=True, exist_ok=True)
    no_links(path)
    if not path.is_dir():
        raise ExportError("--output-root must be a directory")
    return path.resolve(strict=True)


def inside(root: Path, path: Path) -> None:
    no_links(root)
    no_links(path)
    try:
        path.resolve(strict=False).relative_to(root)
    except ValueError as exc:
        raise ExportError("Output path escaped configured root") from exc


def write_new(root: Path, path: Path, value: str) -> None:
    inside(root, path)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(value)
    inside(root, path)


def ensure_object(value: Any, allowed: set[str], required: set[str] | None = None) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise RpcError(-32602, "Parameters must be a JSON object")
    extras = set(value) - allowed
    missing = (required or set()) - set(value)
    if extras:
        raise RpcError(-32602, "Unknown parameter(s): " + ", ".join(sorted(extras)))
    if missing:
        raise RpcError(-32602, "Missing parameter(s): " + ", ".join(sorted(missing)))
    if "_meta" in value and not isinstance(value["_meta"], dict):
        raise RpcError(-32602, "_meta must be an object")
    return value


def tool_result(value: dict[str, Any], error: bool = False) -> dict[str, Any]:
    return {
        "content": [{"type": "text", "text": json.dumps(value, ensure_ascii=False, allow_nan=False)}],
        "structuredContent": value,
        "isError": error,
    }


OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "status": {"type": "string", "enum": ["ready", "unavailable", "complete", "pending", "error"]},
        "job_dir": {"type": "string"},
        "scene_path": {"type": "string"},
        "pptx_path": {"type": "string"},
        "build_report_path": {"type": "string"},
        "audit_report_path": {"type": "string"},
    },
    "required": ["status"],
    "additionalProperties": True,
}

TOOLS = [
    {
        "name": "readiness",
        "description": "Report the real local Python, output root, exporter/auditor availability for text-to-native-vector PPTX. No image-generation tool is required.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        "outputSchema": OUTPUT_SCHEMA,
        "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
    },
    {
        "name": "export_scene",
        "description": "Build any single-page or multi-page scientific presentation from the supplied native scene. DEFAULT: export and audit an internal source, create a verified NEW independent WPS window with an empty page, visibly add native objects one at a time in page order, save science-visible.pptx and current previews, and leave it open. Respect user focus and window size; never force activation or maximize. Source export or rendering a finished deck alone cannot complete the default request. Set export_only=true ONLY when the user explicitly requests no WPS execution. New job names required; scene syntax is documented in references/scene-schema.md.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "job_name": {"type": "string", "pattern": "^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$", "description": "New ASCII job folder name; add a timestamp to avoid collisions."},
                "scene": {"type": "object", "description": "Complete scene JSON: one shared canvas and slides for ALL requested pages in final order, with globally unique IDs. One call produces one PPTX. Do not provide image file paths or executable code."},
                "export_only": {"type": "boolean", "default": False, "description": "Skip visible WPS drawing only for an explicit user request to export without application execution."},
            },
            "required": ["job_name", "scene"],
            "additionalProperties": False,
        },
        "outputSchema": OUTPUT_SCHEMA,
        "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
    },
]

TOOLS.append({
    "name": "run_multimodal_route_example",
    "description": "Repeat the bundled one-slide multimodal sensing and intelligent diagnosis route: export and audit the fixed original scene, create and verify a distinct WPS top-level window via the native WPS launcher and exact owned-file COM binding, then visibly assemble the editable native objects in their original order and formatting, save previews and leave the result open. No deliberate pauses or scene redesign. Creates a NEW job; never overwrites existing outputs. Uses WPS and the clipboard by default; set export_only only when application execution is not requested. Unverified window execution remains pending.",
    "inputSchema": {
        "type": "object",
        "properties": {
            "job_name": {"type": "string", "pattern": "^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$"},
            "export_only": {"type": "boolean", "default": False},
        },
        "required": ["job_name"], "additionalProperties": False,
    },
    "outputSchema": OUTPUT_SCHEMA,
    "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
})

TOOLS.append({
    "name": "run_chip_packaging_history_example",
    "description": "Repeat the bundled ten-slide chip packaging history: verify the fixed scene, export and audit all ten pages, create and verify a distinct WPS top-level window via the native WPS launcher and exact owned-file COM binding, then assemble all native objects visibly in their fixed order and formatting, save current previews and leave the finished deck open. No deliberate pauses or scene redesign. Creates a NEW job; never overwrites existing outputs. Uses WPS and the clipboard by default; set export_only only when application execution is not requested. Unverified window execution remains pending.",
    "inputSchema": {
        "type": "object",
        "properties": {
            "job_name": {"type": "string", "pattern": "^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$"},
            "export_only": {"type": "boolean", "default": False},
        },
        "required": ["job_name"], "additionalProperties": False,
    },
    "outputSchema": OUTPUT_SCHEMA,
    "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
})

for tool_name, description in (
    ("wps_readiness", "Check optional WPS COM registration and pywin32 through the configured local interpreter; does not launch WPS."),
    ("wps_render", "Render all pages of an existing export_scene job in WPS, using an owned copy and a NEW preview folder. Returns PNG paths; visual review is separate."),
    ("wps_verify_edit", "Verify a native text edit in an owned WPS test copy, save and reopen it. The original export is preserved; the modified copy is only for testing."),
):
    properties = {} if tool_name == "wps_readiness" else {
        "job_name": {"type": "string", "pattern": "^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$"}
    }
    TOOLS.append({
        "name": tool_name,
        "description": description,
        "inputSchema": {"type": "object", "properties": properties,
                        "required": [] if not properties else ["job_name"], "additionalProperties": False},
        "outputSchema": OUTPUT_SCHEMA,
        "annotations": {"readOnlyHint": tool_name == "wps_readiness", "destructiveHint": False,
                        "idempotentHint": tool_name == "wps_readiness", "openWorldHint": False},
    })


class Bridge:
    def __init__(self, root: Path, wps_python: Path | None = None):
        self.root = root
        self.script_dir = Path(__file__).resolve().parent
        self.builder = self.script_dir / "build_pptx.py"
        self.auditor = self.script_dir / "audit_pptx.py"
        self.wps_script = self.script_dir / "wps_ppt_bridge.py"
        self.example_script = self.script_dir / "run_multimodal_route_example.py"
        self.science_script = self.script_dir / "run_science_ppt.py"
        self.example_scripts = {
            "multimodal-sensing-diagnosis": self.example_script,
            "chip-packaging-history": self.script_dir / "run_chip_packaging_history_example.py",
        }
        self.wps_python = wps_python or Path(sys.executable)
        self.initialized = False
        self.protocol_version = PROTOCOLS[0]

    def result_for_protocol(self, result: dict[str, Any]) -> dict[str, Any]:
        if self.protocol_version in {"2024-11-05", "2025-03-26"}:
            # Structured results arrived in 2025-06-18; legacy clients receive
            # exactly the same data through the TextContent JSON fallback.
            return {key: value for key, value in result.items() if key != "structuredContent"}
        return result

    def exporter_available(self) -> bool:
        try:
            for script in (self.builder, self.auditor):
                no_links(script)
                if not script.is_file():
                    return False
            return True
        except ExportError:
            return False

    def readiness(self) -> dict[str, Any]:
        available = self.exporter_available()
        try:
            no_links(self.root)
            root_ok = self.root.is_dir()
        except ExportError:
            root_ok = False
        return {
            "status": "ready" if available and root_ok else "unavailable",
            "python_version": sys.version.split()[0],
            "python_path": str(Path(sys.executable).resolve()),
            "output_root": str(self.root),
            "output_root_valid": root_ok,
            "exporter_present": self.builder.is_file(),
            "auditor_present": self.auditor.is_file(),
            "exporter_available": available,
            "native_image_generation": False,
            "image_required": False,
            "workflow": "text-brief-to-native-scene-to-visible-wps-construction",
            "visible_runner_present": self.science_script.is_file(),
            "default_visible_execution_required": True,
            "bundled_example": "multimodal-sensing-diagnosis",
            "example_runner_present": self.example_script.is_file(),
            "bundled_examples": [
                {"name": name, "runner_present": script.is_file()}
                for name, script in self.example_scripts.items()
            ],
            "message": "Design a native scene from the user's text brief, then call export_scene. All ordinary topics default to a new WPS window and sequential native-object drawing; only an explicit export_only request skips this. Source export alone does not finish a visible drawing request.",
        }

    def run_script(self, script: Path, args: list[str], job: Path, log_name: str) -> None:
        inside(self.root, job)
        no_links(script)
        try:
            process = subprocess.run(
                # Ignore environment/site packages, but retain this script's
                # directory so build_pptx can import its bundled audit_pptx.
                [sys.executable, "-B", "-E", "-S", "-X", "utf8", str(script), *args],
                cwd=str(job), capture_output=True, text=True, encoding="utf-8", errors="replace",
                timeout=60, shell=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except subprocess.TimeoutExpired as exc:
            raise ExportError(f"{script.name} exceeded the 60 second timeout; job retained") from exc
        write_new(self.root, job / log_name, process.stdout + "\n--- stderr ---\n" + process.stderr)
        if process.returncode != 0:
            reason = process.stderr.strip() or process.stdout.strip() or "No diagnostic output"
            raise ExportError(f"{script.name} failed (exit {process.returncode}): {reason[-3000:]}")

    def export_scene(self, args: dict[str, Any]) -> dict[str, Any]:
        ensure_object(args, {"job_name", "scene", "export_only"}, {"job_name", "scene"})
        if "export_only" in args and not isinstance(args["export_only"], bool):
            raise RpcError(-32602, "export_only must be boolean")
        name = args["job_name"]
        if not isinstance(name, str) or not JOB_PATTERN.fullmatch(name) or name.upper() in RESERVED:
            raise RpcError(-32602, "job_name must be 1-80 ASCII letters/digits/underscores/hyphens, start with a letter/digit, and not be a Windows reserved name")
        if not isinstance(args["scene"], dict):
            raise RpcError(-32602, "scene must be a JSON object")
        try:
            serialized = json.dumps(args["scene"], ensure_ascii=False, allow_nan=False, indent=2) + "\n"
        except (TypeError, ValueError, RecursionError) as exc:
            raise RpcError(-32602, "scene must contain finite, serializable JSON values") from exc
        if len(serialized.encode("utf-8")) > MAX_SCENE_BYTES:
            raise RpcError(-32602, "scene exceeds 4 MiB")
        if not self.exporter_available():
            return tool_result({"status": "error", "error": "Bundled build_pptx.py/audit_pptx.py is missing or is a symlink/reparse path"}, True)
        job = self.root / name
        created = False
        try:
            inside(self.root, job)
            job.mkdir(exist_ok=False)
            created = True
            inside(self.root, job)
            scene = job / "scene.json"
            pptx = job / "figure-editable.pptx"
            build_report = job / "build-report.json"
            audit_report = job / "audit-report.json"
            write_new(self.root, scene, serialized)
            self.run_script(self.builder, [str(scene), "--out", str(pptx), "--report", str(build_report)], job, "build.log")
            for output in (pptx, build_report):
                inside(self.root, output)
                if not output.is_file() or output.stat().st_size == 0:
                    raise ExportError(f"Exporter did not produce {output.name}")
            self.run_script(self.auditor, [str(pptx), "--out", str(audit_report)], job, "audit.log")
            inside(self.root, audit_report)
            if not audit_report.is_file() or audit_report.stat().st_size == 0:
                raise ExportError("Auditor did not produce audit-report.json")
            report = json_loads(audit_report.read_text(encoding="utf-8-sig"))
            if not isinstance(report, dict):
                raise ExportError("Audit report is not a JSON object")
            if report.get("passed") is not True:
                raise ExportError("PPTX structural audit failed: " + json.dumps(report.get("errors", []), ensure_ascii=False))
            if not args.get("export_only", False):
                return self.finish_visible_scene(job)
            data = {
                "status": "complete",
                "source_export": "complete", "visual_execution": "skipped_by_request",
                "visible_process_complete": False, "export_only": True,
                "job_dir": str(job), "scene_path": str(scene), "pptx_path": str(pptx),
                "build_report_path": str(build_report), "audit_report_path": str(audit_report),
                "qa_path": str(job / "qa.json"),
                "audit": report,
                "message": "Explicit export-only request completed. WPS drawing was skipped; this result is not evidence of visible construction.",
            }
            write_new(self.root, job / "qa.json", json.dumps(data, ensure_ascii=False, indent=2)+"\n")
            return tool_result(data)
        except FileExistsError:
            return tool_result({"status": "error", "error": "Job directory already exists; choose a new job_name. Existing files were not overwritten."}, True)
        except (ExportError, OSError, ValueError) as exc:
            data: dict[str, Any] = {"status": "error", "error": str(exc)}
            if created:
                data["job_dir"] = str(job)
                data["message"] = "Failed job and diagnostics are retained. Correct the scene and choose a new job_name."
            return tool_result(data, True)

    def finish_visible_scene(self, job: Path) -> dict[str, Any]:
        inside(self.root, job)
        no_links(self.science_script)
        data = {"status": "pending", "job_dir": str(job), "source_export": "complete",
                "source_pptx_path": str(job / "figure-editable.pptx"), "visual_execution": "pending",
                "visible_process_complete": False, "qa_path": str(job / "qa.json")}
        try:
            if not self.science_script.is_file():
                raise ExportError("Generic visible drawing runner is missing; source export cannot complete this request")
            command = [sys.executable, "-B", "-E", "-S", "-X", "utf8", str(self.science_script),
                       "--out-dir", str(job), "--resume-export", "--wps-python", str(self.wps_python)]
            process = subprocess.run(command, cwd=str(job), capture_output=True, text=True,
                                     encoding="utf-8", errors="replace", timeout=1200, shell=False,
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            write_new(self.root, job / "visible-mcp.log", process.stdout+"\n--- stderr ---\n"+process.stderr)
            result = json_loads(process.stdout)
            if not isinstance(result, dict) or result.get("status") not in {"complete", "pending", "error"}:
                raise ExportError("Generic visible runner returned an invalid result")
            if result["status"]=="complete":
                scene = json_loads((job / "scene.json").read_text(encoding="utf-8"))
                expected = [len(page["elements"]) for page in scene["slides"]]
                pages = result.get("native_progress_evidence")
                if (result.get("visual_execution")!="complete" or result.get("visible_process_complete") is not True
                        or result.get("physical_new_window_verified") is not True
                        or result.get("visible_drawing_verified") is not True
                        or result.get("construction_mode")!="sequential_native_objects"
                        or result.get("source_reference_hidden") is not True
                        or not isinstance(pages,list) or len(pages)!=len(expected)
                        or any(not isinstance(p,dict) or p.get("slide")!=n or p.get("initial_top_level_objects")!=0
                            or p.get("objects_added")!=count or p.get("top_level_objects")!=count
                            or p.get("incremental_objects_verified") is not True or p.get("object_order_preserved") is not True
                            for n,(p,count) in enumerate(zip(pages or [],expected),1))):
                    raise ExportError("Source-only output cannot count as visible drawing completion; new-window and per-object evidence are required")
                final = job / "science-visible.pptx"
                inside(self.root, final)
                if not final.is_file() or result.get("pptx_path")!=str(final):
                    raise ExportError("Verified visibly drawn final PPTX is missing")
            return tool_result(result, result["status"]!="complete" or process.returncode!=0)
        except subprocess.TimeoutExpired:
            data["error"] = "Visible drawing exceeded 1200 seconds; partial files and the WPS window are retained. The visible process is unfinished."
        except (ExportError, OSError, ValueError, RecursionError) as exc:
            data["error"] = str(exc)
        if not (job / "qa.json").exists():
            write_new(self.root, job / "qa.json", json.dumps(data,ensure_ascii=False,indent=2)+"\n")
        return tool_result(data, True)

    def dispatch(self, method: str, params: Any) -> Any:
        if method == "initialize":
            ensure_object(params, {"protocolVersion", "capabilities", "clientInfo", "_meta"}, {"protocolVersion", "capabilities", "clientInfo"})
            if not isinstance(params["protocolVersion"], str) or not isinstance(params["capabilities"], dict) or not isinstance(params["clientInfo"], dict):
                raise RpcError(-32602, "Invalid initialize parameters")
            if not all(isinstance(params["clientInfo"].get(key), str) for key in ("name", "version")):
                raise RpcError(-32602, "clientInfo must contain string name and version")
            if self.initialized:
                raise RpcError(-32600, "Server has already been initialized")
            self.initialized = True
            protocol = params["protocolVersion"] if params["protocolVersion"] in PROTOCOLS else PROTOCOLS[0]
            self.protocol_version = protocol
            return {"protocolVersion": protocol, "capabilities": {"tools": {"listChanged": False}}, "serverInfo": {"name": "science-ppt", "version": VERSION}, "instructions": "For EVERY ordinary topic, design a native scene and call export_scene once for ALL requested pages. By default export_scene performs source export/audit AND creates a verified new independent WPS window with an empty page, sequentially builds the native objects visibly, saves science-visible.pptx and current previews, and leaves it open. This requirement is not limited to bundled examples. Never stop after offline build_pptx or use wps_render/opening a finished file as evidence of drawing. Do not silently switch to export_only; that exception requires an explicit user request to omit WPS. If visible execution is pending/error, preserve the source and honestly report the unfinished process; do not claim completion or deliver that source as the default final. For the two fixed demos use their run_example tools. Let normal WPS launch show the task window; never force focus, restore, maximize or add demonstration delays. Respect user focus and geometry; switching applications does not fail construction. Inspect all current previews separately; structural audit alone does not prove visual quality."}
        if method == "ping":
            ensure_object(params, {"_meta"})
            return {}
        if method == "notifications/initialized":
            ensure_object(params, {"_meta"})
            return None
        if method == "notifications/cancelled":
            ensure_object(params, {"requestId", "reason", "_meta"}, {"requestId"})
            return None
        if not self.initialized:
            raise RpcError(-32002, "Initialize the MCP session before calling tools")
        if method == "tools/list":
            ensure_object(params, {"_meta", "cursor"})
            if "cursor" in params:
                raise RpcError(-32602, "No pagination cursor is valid for this fixed tool list")
            omitted = set()
            if self.protocol_version in {"2024-11-05", "2025-03-26"}:
                omitted.add("outputSchema")
            if self.protocol_version == "2024-11-05":
                omitted.add("annotations")
            return {"tools": [{key: value for key, value in tool.items() if key not in omitted} for tool in TOOLS]}
        if method == "tools/call":
            ensure_object(params, {"name", "arguments", "_meta"}, {"name"})
            name = params["name"]
            args = params.get("arguments", {})
            if not isinstance(name, str) or not isinstance(args, dict):
                raise RpcError(-32602, "Tool name must be a string and arguments an object")
            if name == "readiness":
                ensure_object(args, set())
                return self.result_for_protocol(tool_result(self.readiness()))
            if name == "export_scene":
                return self.result_for_protocol(self.export_scene(args))
            if name == "run_multimodal_route_example":
                return self.result_for_protocol(self.run_example(args, example="multimodal-sensing-diagnosis"))
            if name == "run_chip_packaging_history_example":
                return self.result_for_protocol(self.run_example(args, example="chip-packaging-history"))
            if name in {"wps_readiness", "wps_render", "wps_verify_edit"}:
                return self.result_for_protocol(self.wps_tool(name, args))
            raise RpcError(-32602, "Unknown tool: " + name)
        raise RpcError(-32601, "Unknown method: " + method)

    def run_example(self, args: dict[str, Any], example: str = "multimodal-sensing-diagnosis") -> dict[str, Any]:
        ensure_object(args, {"job_name", "export_only"}, {"job_name"})
        name = args["job_name"]
        if not isinstance(name, str) or not JOB_PATTERN.fullmatch(name) or name.upper() in RESERVED:
            raise RpcError(-32602, "Invalid new example job_name")
        if "export_only" in args and not isinstance(args["export_only"], bool):
            raise RpcError(-32602, "export_only must be boolean")
        if example not in self.example_scripts:
            raise RpcError(-32602, "Unknown bundled example")
        script = self.example_scripts[example]
        timeout = 900 if example == "chip-packaging-history" else 300
        job = self.root / name
        try:
            inside(self.root, job)
            if job.exists():
                raise ExportError("Job directory already exists; choose a new job_name")
            no_links(script)
            if not script.is_file():
                raise ExportError("Bundled example runner is missing")
            command = [sys.executable, "-B", "-E", "-S", "-X", "utf8", str(script),
                       "--out-dir", str(job), "--wps-python", str(self.wps_python)]
            if args.get("export_only", False):
                command.append("--export-only")
            process = subprocess.run(command, cwd=str(self.root), capture_output=True, text=True,
                                     encoding="utf-8", errors="replace", timeout=timeout, shell=False,
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            try:
                data = json_loads(process.stdout)
            except (ValueError, RecursionError) as exc:
                raise ExportError("Example runner returned no valid JSON: " + process.stderr[-2000:]) from exc
            if not isinstance(data, dict) or data.get("status") not in {"complete", "pending", "error"}:
                raise ExportError("Example runner returned an invalid result")
            inside(self.root, job)
            if job.is_dir():
                write_new(self.root, job / "example-mcp.log", process.stdout + "\n--- stderr ---\n" + process.stderr)
            return tool_result(data, process.returncode != 0 or data["status"] == "error")
        except RpcError:
            raise
        except subprocess.TimeoutExpired:
            return tool_result({"status": "error", "job_dir": str(job),
                                "error": f"Example runner exceeded {timeout} seconds; partial outputs and the WPS session are retained. Inspect the current presentation before retrying in a new job."}, True)
        except (ExportError, OSError, ValueError) as exc:
            return tool_result({"status": "error", "job_dir": str(job), "error": str(exc)}, True)

    def wps_tool(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        ensure_object(args, set() if name == "wps_readiness" else {"job_name"},
                      set() if name == "wps_readiness" else {"job_name"})
        command = [str(self.wps_python), "-B", "-E", "-X", "utf8", str(self.wps_script)]
        try:
            for script in (self.wps_python, self.wps_script):
                no_links(script)
                if not script.is_file():
                    raise ExportError(f"Missing WPS interpreter or helper: {script}")
            if name == "wps_readiness":
                command.append("readiness")
            else:
                job_name = args["job_name"]
                if not isinstance(job_name, str) or not JOB_PATTERN.fullmatch(job_name) or job_name.upper() in RESERVED:
                    raise RpcError(-32602, "Invalid existing export_scene job_name")
                job = self.root / job_name
                inside(self.root, job)
                pptx = None
                for candidate in (job / "science-visible.pptx", job / "figure-editable.pptx"):
                    inside(self.root, candidate)
                    if candidate.is_file():
                        pptx = candidate
                        break
                if pptx is None:
                    raise ExportError("Existing export_scene job PPTX not found")
                if name == "wps_render":
                    target = job / ("wps-render-preview" if (job / "wps-preview").exists() else "wps-preview")
                    command.extend(["render", "--pptx", str(pptx), "--out-dir", str(target)])
                else:
                    target = job / "wps-edit-test.pptx"
                    command.extend(["verify-edit", "--pptx", str(pptx), "--out", str(target)])
                inside(self.root, target)
                if target.exists():
                    raise ExportError("WPS verification output already exists; use a new exported job")
            process = subprocess.run(command, cwd=str(self.root), capture_output=True, text=True,
                                     encoding="utf-8", errors="replace", timeout=120, shell=False,
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            try:
                data = json_loads(process.stdout)
            except (ValueError, RecursionError) as exc:
                raise ExportError("WPS helper returned no valid JSON: " + process.stderr[-2000:]) from exc
            if not isinstance(data, dict):
                raise ExportError("WPS helper returned a non-object result")
            if name == "wps_readiness":
                return tool_result({"status": "ready" if data.get("ready") is True else "unavailable",
                                    "verification": data})
            if process.returncode != 0:
                return tool_result({"status": "error", "detail": data,
                                    "error": process.stderr[-2000:] or data.get("error", "WPS helper failed")}, True)
            if data.get("ok") is not True:
                raise ExportError("WPS helper did not report successful verification")
            return tool_result({"status": "complete", "verification": data})
        except RpcError:
            raise
        except subprocess.TimeoutExpired:
            return tool_result({"status": "error", "error": "WPS helper exceeded 120 seconds; inspect the owned copy and application. User WPS processes were not terminated."}, True)
        except (ExportError, OSError, ValueError) as exc:
            return tool_result({"status": "error", "error": str(exc)}, True)


def respond(message: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(message, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def serve(bridge: Bridge) -> None:
    while True:
        raw = sys.stdin.buffer.readline(MAX_LINE + 1)
        if not raw:
            return
        if len(raw) > MAX_LINE:
            while raw and not raw.endswith(b"\n"):
                raw = sys.stdin.buffer.readline(MAX_LINE + 1)
            respond({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Message exceeds 8 MiB"}})
            continue
        if not raw.strip():
            continue
        req_id: Any = None
        notification = False
        try:
            try:
                request = json_loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, ValueError, RecursionError) as exc:
                raise RpcError(-32700, "Invalid JSON: " + str(exc)[:500]) from exc
            if not isinstance(request, dict):
                raise RpcError(-32600, "Request must be a JSON object; batches are not supported")
            if request.get("jsonrpc") != "2.0" or not isinstance(request.get("method"), str) or set(request) - {"jsonrpc", "id", "method", "params"}:
                raise RpcError(-32600, "Invalid JSON-RPC 2.0 request")
            notification = "id" not in request
            req_id = request.get("id")
            if notification and not request["method"].startswith("notifications/"):
                raise RpcError(-32600, "MCP request methods require a request id")
            if not notification and (isinstance(req_id, bool) or not isinstance(req_id, (str, int))):
                req_id = None
                raise RpcError(-32600, "Request id must be a string or integer")
            result = bridge.dispatch(request["method"], request.get("params", {}))
            if not notification:
                respond({"jsonrpc": "2.0", "id": req_id, "result": result})
        except RpcError as exc:
            if not notification:
                respond({"jsonrpc": "2.0", "id": req_id, "error": {"code": exc.code, "message": str(exc)}})
            else:
                print(f"Ignored invalid notification: {exc}", file=sys.stderr, flush=True)
        except Exception as exc:
            print(f"MCP internal error: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
            if not notification:
                respond({"jsonrpc": "2.0", "id": req_id, "error": {"code": -32603, "message": "Internal server error; inspect stderr"}})


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", required=True, help="Absolute, symlink-free root for new job directories")
    parser.add_argument("--wps-python", help="Optional absolute Python interpreter with pywin32 for WPS auxiliary tools")
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        parser.error("Python 3.10+ is required")
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    try:
        root = prepare_root(args.output_root)
    except (ExportError, OSError) as exc:
        print(f"MCP setup failed: {exc}", file=sys.stderr)
        return 2
    wps_python = Path(args.wps_python).expanduser() if args.wps_python else None
    if wps_python is not None and not wps_python.is_absolute():
        parser.error("--wps-python must be an absolute interpreter path")
    serve(Bridge(root, wps_python=wps_python))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
