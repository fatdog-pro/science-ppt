#!/usr/bin/env python3
"""Build editable, vector-only PowerPoint slides from a reviewed scene JSON.

Uses Python 3.10+ standard library only. This is a drawing exporter, not OCR or an
image tracer. All text, shapes, lines and Bezier paths become native OOXML
objects; raster images, SVG pictures and hidden image backgrounds are forbidden.
Run: python build_pptx.py scene.json --out figure.pptx --report report.json
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile
import zipfile
import xml.etree.ElementTree as ET

EMU_PER_INCH = 914400
NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
    "ct": "http://schemas.openxmlformats.org/package/2006/content-types",
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
    "xsi": "http://www.w3.org/2001/XMLSchema-instance",
    "ep": "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
    "vt": "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes",
}
for _prefix, _uri in NS.items():
    ET.register_namespace(_prefix, _uri)

PRESETS = {"rect", "roundRect", "ellipse", "triangle", "diamond", "chevron",
           "rightArrow", "upArrow", "hexagon", "arc"}
ARROWS = {"none", "triangle", "stealth", "diamond", "oval", "arrow"}
DASHES = {"solid", "dash", "dot", "dashDot", "longDash"}
COMMON = {"id", "type", "name", "x", "y", "w", "h", "rotation", "fill",
          "fill_opacity", "stroke", "description"}
TEXT_FIELDS = {"text", "font", "align", "valign", "margin", "line_spacing"}
LIMIT = 10000


class SceneError(ValueError):
    """An actionable input validation error."""


def require(condition, message):
    if not condition:
        raise SceneError(message)


def finite(value, where, minimum=None, maximum=None):
    require(isinstance(value, (int, float)) and not isinstance(value, bool),
            f"{where}: expected a number")
    try:
        numeric = float(value)
    except OverflowError as exc:
        raise SceneError(f"{where}: number is outside the supported range") from exc
    require(math.isfinite(numeric), f"{where}: NaN/Infinity are forbidden")
    if minimum is not None:
        require(value >= minimum, f"{where}: must be >= {minimum}")
    if maximum is not None:
        require(value <= maximum, f"{where}: must be <= {maximum}")
    return numeric


def unknown_fields(obj, allowed, where):
    extra = set(obj) - allowed
    require(not extra, f"{where}: unsupported fields {sorted(extra)}")


def color(value, where, allow_none=True):
    if value is None and allow_none:
        return None
    require(isinstance(value, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", value),
            f"{where}: use '#RRGGBB'" + (" or null" if allow_none else ""))
    return value.upper()


def xml_text(value, where, nonempty=False):
    require(isinstance(value, str), f"{where}: expected a string")
    require(all(ch in "\t\n\r" or 0x20 <= ord(ch) <= 0xD7FF or
                0xE000 <= ord(ch) <= 0xFFFD or 0x10000 <= ord(ch) <= 0x10FFFF
                for ch in value), f"{where}: contains an invalid XML character")
    if nonempty:
        require(bool(value.strip()), f"{where}: cannot be empty")
    return value


def has_cjk(value):
    return any(0x3400 <= ord(c) <= 0x9FFF or 0x20000 <= ord(c) <= 0x323AF
               for c in value)


def box_points(x, y, w, h, rotation=0):
    corners = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
    if rotation:
        angle = math.radians(rotation)
        cx, cy = x + w / 2, y + h / 2
        co, si = math.cos(angle), math.sin(angle)
        corners = [(cx + (px-cx)*co - (py-cy)*si,
                    cy + (px-cx)*si + (py-cy)*co) for px, py in corners]
    return corners


class Scene:
    def __init__(self, raw):
        require(isinstance(raw, dict), "scene: expected an object")
        unknown_fields(raw, {"version", "title", "canvas", "slides", "metadata"}, "scene")
        require(type(raw.get("version", 1)) is int and raw.get("version", 1) == 1,
                "scene.version: only integer version 1 is supported")
        self.raw = copy.deepcopy(raw)
        self.title = xml_text(raw.get("title", "Editable scientific figure"), "scene.title")
        canvas = raw.get("canvas", {})
        require(isinstance(canvas, dict), "canvas: expected an object")
        unknown_fields(canvas, {"width", "height", "slide_width_in", "slide_height_in"}, "canvas")
        self.width = finite(canvas.get("width", 1600), "canvas.width", 1, 100000)
        self.height = finite(canvas.get("height", 900), "canvas.height", 1, 100000)
        self.slide_width = finite(canvas.get("slide_width_in", 40/3), "canvas.slide_width_in", 1, 56)
        self.slide_height = finite(canvas.get("slide_height_in", 7.5), "canvas.slide_height_in", 1, 56)
        require(abs(self.width/self.height - self.slide_width/self.slide_height) < 0.0001,
                "canvas: pixel and slide aspect ratios must match")
        self.sx = self.slide_width * EMU_PER_INCH / self.width
        self.sy = self.slide_height * EMU_PER_INCH / self.height
        self.pt_per_px = self.slide_height * 72 / self.height
        self.slides = self.raw.get("slides")
        require(isinstance(self.slides, list) and 1 <= len(self.slides) <= 100,
                "slides: expected 1..100 slides")
        self.seen_ids = set()
        self.element_counter = 0
        self.warnings = []
        self.stats = []
        self.ids_by_slide = []
        for index, slide in enumerate(self.slides):
            self.validate_slide(slide, index)

    def identifier(self, obj, where):
        value = obj.get("id")
        require(isinstance(value, str) and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]{0,127}", value),
                f"{where}.id: use a unique ASCII identifier beginning with a letter or '_'")
        require(value not in self.seen_ids, f"{where}.id: duplicate '{value}'")
        self.seen_ids.add(value)
        return value

    def validate_slide(self, slide, index):
        where = f"slides[{index}]"
        require(isinstance(slide, dict), f"{where}: expected an object")
        require("notes" not in slide,
                f"{where}.notes: speaker notes are not supported; preserve provenance in root metadata or a QA sidecar JSON")
        unknown_fields(slide, {"id", "title", "background", "elements"}, where)
        if "id" not in slide:
            slide["id"] = f"slide_{index+1}"
        self.identifier(slide, where)
        slide["title"] = xml_text(slide.get("title", self.title), where + ".title")
        slide["background"] = color(slide.get("background", "#FFFFFF"), where + ".background", False)
        elems = slide.get("elements")
        require(isinstance(elems, list) and elems, f"{where}.elements: empty slide is forbidden")
        stats = {"slide_id": slide["id"], "text_count": 0, "shape_count": 0,
                 "path_count": 0, "connector_count": 0, "group_count": 0,
                 "raster_count": 0, "element_count": 0, "texts": [], "fonts": []}
        id_map = {}
        for i, element in enumerate(elems):
            self.validate_element(element, f"{where}.elements[{i}]", (0, 0),
                                  (self.width, self.height), stats, id_map, 0)
        require(stats["text_count"] + stats["shape_count"] + stats["path_count"] +
                stats["connector_count"] > 0, f"{where}: empty slide is forbidden")
        for element in self.walk(elems):
            if element["type"] == "line" and element.get("connect"):
                for endpoint, ref in element["connect"].items():
                    require(ref["id"] in id_map, f"{element['id']}.connect.{endpoint}: unknown id")
                    require(id_map[ref["id"]]["type"] in {"shape", "text", "path"},
                            f"{element['id']}.connect.{endpoint}: connect to a shape, text or path")
        self.stats.append(stats)
        self.ids_by_slide.append(id_map)

    @staticmethod
    def walk(elements):
        for elem in elements:
            yield elem
            if elem["type"] == "group":
                yield from Scene.walk(elem["children"])

    def bounds(self, points, where, origin, frame, pad=0):
        ox, oy = origin
        fw, fh = frame
        tolerance = 1e-7
        for x, y in points:
            require(pad-tolerance <= x <= fw-pad+tolerance and
                    pad-tolerance <= y <= fh-pad+tolerance,
                    f"{where}: geometry/stroke exceeds its parent bounds ({fw:g} x {fh:g})")
            require(pad-tolerance <= x+ox <= self.width-pad+tolerance and
                    pad-tolerance <= y+oy <= self.height-pad+tolerance,
                    f"{where}: geometry/stroke exceeds slide bounds")

    def validate_stroke(self, elem, where):
        stroke = elem.get("stroke")
        if stroke is None:
            elem["stroke"] = None
            return 0
        require(isinstance(stroke, dict), f"{where}.stroke: expected an object or null")
        unknown_fields(stroke, {"color", "width", "opacity", "dash", "head", "tail"}, where + ".stroke")
        stroke["color"] = color(stroke.get("color", "#243447"), where + ".stroke.color", False)
        stroke["width"] = finite(stroke.get("width", 2), where + ".stroke.width", 0.01, 100)
        stroke["opacity"] = finite(stroke.get("opacity", 1), where + ".stroke.opacity", 0, 1)
        stroke["dash"] = stroke.get("dash", "solid")
        require(isinstance(stroke["dash"], str) and stroke["dash"] in DASHES,
                f"{where}.stroke.dash: unsupported dash")
        for attr in ("head", "tail"):
            stroke[attr] = stroke.get(attr, "none")
            require(isinstance(stroke[attr], str) and stroke[attr] in ARROWS,
                    f"{where}.stroke.{attr}: unsupported arrow")
            require(elem["type"] in {"line", "path"} or stroke[attr] == "none",
                    f"{where}: arrows are supported only on lines or paths")
        return stroke["width"] / 2

    def validate_text(self, elem, where, stats):
        elem["text"] = xml_text(elem.get("text"), where + ".text", True)
        font = elem.get("font", {})
        require(isinstance(font, dict), f"{where}.font: expected an object")
        unknown_fields(font, {"family", "east_asian", "size", "bold", "italic", "color"}, where + ".font")
        font["family"] = xml_text(font.get("family", "Arial"), where + ".font.family", True)
        font["east_asian"] = xml_text(font.get("east_asian", "Microsoft YaHei"), where + ".font.east_asian", True)
        font["size"] = finite(font.get("size", 24), where + ".font.size", 1, 400)
        require(1 <= font["size"] * self.pt_per_px <= 400,
                f"{where}.font.size: rendered point size must be 1..400")
        for attr in ("bold", "italic"):
            font[attr] = font.get(attr, False)
            require(isinstance(font[attr], bool), f"{where}.font.{attr}: expected a boolean")
        font["color"] = color(font.get("color", "#243447"), where + ".font.color", False)
        elem["font"] = font
        elem["align"] = elem.get("align", "left")
        require(isinstance(elem["align"], str) and elem["align"] in {"left", "center", "right"},
                f"{where}.align: unsupported value")
        elem["valign"] = elem.get("valign", "middle")
        require(isinstance(elem["valign"], str) and elem["valign"] in {"top", "middle", "bottom"},
                f"{where}.valign: unsupported value")
        elem["margin"] = finite(elem.get("margin", 0), where + ".margin", 0)
        require(elem["margin"] * 2 < min(elem["w"], elem["h"]), f"{where}.margin: consumes text box")
        elem["line_spacing"] = finite(elem.get("line_spacing", 1.1), where + ".line_spacing", 0.5, 3)
        stats["text_count"] += 1
        stats["texts"].append({"id": elem["id"], "text": elem["text"], "has_cjk": has_cjk(elem["text"])})
        for name in (font["family"], font["east_asian"]):
            if name not in stats["fonts"]:
                stats["fonts"].append(name)
        available_height = elem["h"] - elem["margin"]*2
        lines = len(elem["text"].splitlines()) or 1
        if lines * font["size"] * elem["line_spacing"] > available_height:
            self.warnings.append(f"{elem['id']}: declared text lines may exceed box height; inspect rendered slide")

    def validate_element(self, elem, where, origin, frame, stats, id_map, depth):
        require(depth <= 12, f"{where}: groups may nest at most 12 levels")
        require(isinstance(elem, dict), f"{where}: expected an object")
        typ = elem.get("type")
        require(isinstance(typ, str) and typ in {"text", "shape", "path", "line", "group"},
                f"{where}.type: unsupported; images/raster/SVG pictures are forbidden")
        allowed = COMMON | (TEXT_FIELDS if typ in {"text", "shape"} else set())
        allowed |= {"shape"} if typ == "shape" else set()
        allowed |= {"commands"} if typ == "path" else set()
        allowed |= {"x1", "y1", "x2", "y2", "connect"} if typ == "line" else set()
        allowed |= {"children"} if typ == "group" else set()
        if typ == "line":
            allowed -= {"x", "y", "w", "h", "rotation", "fill", "fill_opacity"}
        if typ == "group":
            allowed -= {"fill", "fill_opacity", "stroke"}
        unknown_fields(elem, allowed, where)
        elem_id = self.identifier(elem, where)
        id_map[elem_id] = elem
        self.element_counter += 1
        require(self.element_counter <= LIMIT, f"scene: at most {LIMIT} elements")
        stats["element_count"] += 1
        elem["name"] = xml_text(elem.get("name", elem_id), where + ".name", True)
        if "description" in elem:
            xml_text(elem["description"], where + ".description")
        pad = self.validate_stroke(elem, where) if typ != "group" else 0
        if typ == "line":
            for key in ("x1", "y1", "x2", "y2"):
                elem[key] = finite(elem.get(key), where + "." + key)
            require(elem["x1"] != elem["x2"] or elem["y1"] != elem["y2"],
                    f"{where}: zero-length line is forbidden")
            require(elem["stroke"] is not None, f"{where}: line requires a stroke")
            self.bounds([(elem["x1"], elem["y1"]), (elem["x2"], elem["y2"])], where, origin, frame, pad)
            if "connect" in elem:
                conn = elem["connect"]
                require(isinstance(conn, dict) and conn, f"{where}.connect: expected nonempty object")
                unknown_fields(conn, {"start", "end"}, where + ".connect")
                for endpoint, ref in conn.items():
                    require(isinstance(ref, dict), f"{where}.connect.{endpoint}: expected object")
                    unknown_fields(ref, {"id", "site"}, where + ".connect." + endpoint)
                    require(isinstance(ref.get("id"), str), f"{where}.connect.{endpoint}.id: expected string")
                    site = ref.get("site", 0)
                    require(isinstance(site, int) and not isinstance(site, bool) and 0 <= site <= 3,
                            f"{where}.connect.{endpoint}.site: expected 0..3")
                    ref["site"] = site
            stats["connector_count"] += 1
            return
        for key in ("x", "y", "w", "h"):
            elem[key] = finite(elem.get(key), where + "." + key, 0.01 if key in {"w", "h"} else None)
        elem["rotation"] = finite(elem.get("rotation", 0), where + ".rotation", -360, 360)
        require(typ != "group" or elem["rotation"] == 0,
                f"{where}: group rotation is not supported; rotate its children")
        self.bounds(box_points(elem["x"], elem["y"], elem["w"], elem["h"], elem["rotation"]),
                    where, origin, frame, pad)
        if typ == "group":
            children = elem.get("children")
            require(isinstance(children, list) and children, f"{where}.children: expected nonempty list")
            stats["group_count"] += 1
            for i, child in enumerate(children):
                self.validate_element(child, f"{where}.children[{i}]",
                                      (origin[0]+elem["x"], origin[1]+elem["y"]),
                                      (elem["w"], elem["h"]), stats, id_map, depth+1)
            return
        elem["fill"] = color(elem.get("fill", None), where + ".fill")
        elem["fill_opacity"] = finite(elem.get("fill_opacity", 1), where + ".fill_opacity", 0, 1)
        if typ == "shape":
            require(isinstance(elem.get("shape"), str) and elem.get("shape") in PRESETS,
                    f"{where}.shape: unsupported preset")
            stats["shape_count"] += 1
        if typ == "path":
            commands = elem.get("commands")
            require(isinstance(commands, list) and 2 <= len(commands) <= 5000,
                    f"{where}.commands: expected 2..5000 commands")
            require(isinstance(commands[0], list) and commands[0] and commands[0][0] == "M",
                    f"{where}.commands: path must begin with M")
            active = False
            drawing_commands = 0
            for i, cmd in enumerate(commands):
                require(isinstance(cmd, list) and cmd, f"{where}.commands[{i}]: expected a command list")
                opcode = cmd[0]
                require(isinstance(opcode, str) and opcode in {"M", "L", "C", "Q", "Z"},
                        f"{where}.commands[{i}]: unsupported opcode")
                nargs = {"M": 2, "L": 2, "C": 6, "Q": 4, "Z": 0}[opcode]
                require(len(cmd) == nargs+1, f"{where}.commands[{i}]: {opcode} requires {nargs} numbers")
                if opcode != "M":
                    require(active, f"{where}.commands[{i}]: a new subpath must begin with M after Z")
                    drawing_commands += opcode != "Z"
                for j in range(1, len(cmd), 2):
                    cmd[j] = finite(cmd[j], f"{where}.commands[{i}][{j}]", 0, elem["w"])
                    cmd[j+1] = finite(cmd[j+1], f"{where}.commands[{i}][{j+1}]", 0, elem["h"])
                if opcode == "M":
                    active = True
                elif opcode == "Z":
                    active = False
            require(drawing_commands > 0, f"{where}: path has no drawn segments")
            require(elem["fill"] is not None or elem["stroke"] is not None,
                    f"{where}: path requires fill or stroke")
            stats["path_count"] += 1
        if typ == "text" or "text" in elem:
            self.validate_text(elem, where, stats)
        else:
            require(not (TEXT_FIELDS & set(elem)), f"{where}: text style fields require text")


def node(parent, prefix, tag, attrs=None, text=None):
    elem = ET.SubElement(parent, f"{{{NS[prefix]}}}{tag}", {str(k): str(v) for k, v in (attrs or {}).items()})
    if text is not None:
        elem.text = str(text)
    return elem


def root(prefix, tag, attrs=None):
    return ET.Element(f"{{{NS[prefix]}}}{tag}", {str(k): str(v) for k, v in (attrs or {}).items()})


def xml_bytes(elem):
    return ET.tostring(elem, encoding="utf-8", xml_declaration=True)


def relation(parent, rid, kind, target):
    node(parent, "rel", "Relationship", {"Id": rid, "Type": NS["r"] + "/" + kind, "Target": target})


def rels():
    return root("rel", "Relationships")


def solid_fill(parent, hex_color, opacity=1):
    if hex_color is None:
        node(parent, "a", "noFill")
    else:
        fill = node(parent, "a", "solidFill")
        rgb = node(fill, "a", "srgbClr", {"val": hex_color.lstrip("#")})
        if opacity != 1:
            node(rgb, "a", "alpha", {"val": round(opacity*100000)})


class Exporter:
    def __init__(self, scene):
        self.scene = scene
        self.ids = {}

    def ex(self, value):
        return round(value * self.scene.sx)

    def ey(self, value):
        return round(value * self.scene.sy)

    def transform(self, parent, elem, group=False):
        attrs = {}
        if elem.get("rotation"):
            attrs["rot"] = round(elem["rotation"] * 60000)
        tx = node(parent, "a", "xfrm", attrs)
        node(tx, "a", "off", {"x": self.ex(elem["x"]), "y": self.ey(elem["y"])})
        node(tx, "a", "ext", {"cx": self.ex(elem["w"]), "cy": self.ey(elem["h"])})
        if group:
            node(tx, "a", "chOff", {"x": 0, "y": 0})
            node(tx, "a", "chExt", {"cx": self.ex(elem["w"]), "cy": self.ey(elem["h"])})

    def nonvisual(self, parent, elem, kind):
        nv = node(parent, "p", "nv" + kind + "Pr")
        attrs = {"id": self.ids[elem["id"]], "name": elem["name"]}
        if elem.get("description"):
            attrs["descr"] = elem["description"]
        node(nv, "p", "cNvPr", attrs)
        attrs2 = {"txBox": "1"} if kind == "Sp" and elem["type"] == "text" else {}
        props = node(nv, "p", "cNv" + kind + "Pr", attrs2)
        if kind == "CxnSp":
            for endpoint, ref in elem.get("connect", {}).items():
                node(props, "a", "stCxn" if endpoint == "start" else "endCxn",
                     {"id": self.ids[ref["id"]], "idx": ref["site"]})
        node(nv, "p", "nvPr")

    def line_style(self, parent, stroke):
        ln = node(parent, "a", "ln", {"w": self.ex(stroke["width"])} if stroke else {})
        if not stroke:
            node(ln, "a", "noFill")
            return
        solid_fill(ln, stroke["color"], stroke["opacity"])
        node(ln, "a", "prstDash", {"val": "lgDash" if stroke["dash"] == "longDash" else stroke["dash"]})
        node(ln, "a", "round")
        # DrawingML headEnd is the start point; tailEnd is the final point.
        node(ln, "a", "headEnd", {"type": stroke["head"], "w": "med", "len": "med"})
        node(ln, "a", "tailEnd", {"type": stroke["tail"], "w": "med", "len": "med"})

    def text_body(self, parent, elem):
        body = node(parent, "p", "txBody")
        margin = elem["margin"]
        bp = node(body, "a", "bodyPr", {
            "wrap": "square", "lIns": self.ex(margin), "rIns": self.ex(margin),
            "tIns": self.ey(margin), "bIns": self.ey(margin),
            "anchor": {"top": "t", "middle": "ctr", "bottom": "b"}[elem["valign"]],
            "anchorCtr": "0",
        })
        node(bp, "a", "noAutofit")
        node(body, "a", "lstStyle")
        font = elem["font"]
        size = round(font["size"] * self.scene.pt_per_px * 100)
        for text in elem["text"].replace("\r\n", "\n").replace("\r", "\n").split("\n"):
            p = node(body, "a", "p")
            pp = node(p, "a", "pPr", {"algn": {"left": "l", "center": "ctr", "right": "r"}[elem["align"]]})
            ls = node(pp, "a", "lnSpc")
            node(ls, "a", "spcPct", {"val": round(elem["line_spacing"]*100000)})
            node(pp, "a", "buNone")
            run = node(p, "a", "r")
            rp = node(run, "a", "rPr", {"lang": "zh-CN" if has_cjk(text) else "en-US",
                      "sz": size, "b": int(font["bold"]), "i": int(font["italic"]), "dirty": "0"})
            solid_fill(rp, font["color"])
            node(rp, "a", "latin", {"typeface": font["family"]})
            node(rp, "a", "ea", {"typeface": font["east_asian"]})
            node(rp, "a", "cs", {"typeface": font["family"]})
            node(run, "a", "t", {"{http://www.w3.org/XML/1998/namespace}space": "preserve"}, text)
            node(p, "a", "endParaRPr", {"lang": "zh-CN", "sz": size})

    def custom_geometry(self, parent, elem):
        geom = node(parent, "a", "custGeom")
        for tag in ("avLst", "gdLst", "ahLst"):
            node(geom, "a", tag)
        connections = node(geom, "a", "cxnLst")
        for angle, x, y in [(0, "r", "vc"), (5400000, "hc", "b"),
                            (10800000, "l", "vc"), (16200000, "hc", "t")]:
            cxn = node(connections, "a", "cxn", {"ang": angle})
            node(cxn, "a", "pos", {"x": x, "y": y})
        node(geom, "a", "rect", {"l": "l", "t": "t", "r": "r", "b": "b"})
        plist = node(geom, "a", "pathLst")
        path = node(plist, "a", "path", {"w": self.ex(elem["w"]), "h": self.ey(elem["h"]),
                     "fill": "norm" if elem["fill"] else "none",
                     "stroke": "1" if elem["stroke"] else "0", "extrusionOk": "0"})
        for cmd in elem["commands"]:
            opcode = cmd[0]
            names = {"M": "moveTo", "L": "lnTo", "C": "cubicBezTo", "Q": "quadBezTo", "Z": "close"}
            step = node(path, "a", names[opcode])
            for j in range(1, len(cmd), 2):
                node(step, "a", "pt", {"x": self.ex(cmd[j]), "y": self.ey(cmd[j+1])})

    def draw(self, parent, elem):
        typ = elem["type"]
        if typ == "group":
            group = node(parent, "p", "grpSp")
            self.nonvisual(group, elem, "GrpSp")
            gp = node(group, "p", "grpSpPr")
            self.transform(gp, elem, True)
            for child in elem["children"]:
                self.draw(group, child)
            return
        if typ == "line":
            sp = node(parent, "p", "cxnSp")
            self.nonvisual(sp, elem, "CxnSp")
            props = node(sp, "p", "spPr")
            x1, y1, x2, y2 = [elem[k] for k in ("x1", "y1", "x2", "y2")]
            attrs = {}
            if x2 < x1:
                attrs["flipH"] = "1"
            if y2 < y1:
                attrs["flipV"] = "1"
            tx = node(props, "a", "xfrm", attrs)
            node(tx, "a", "off", {"x": self.ex(min(x1,x2)), "y": self.ey(min(y1,y2))})
            node(tx, "a", "ext", {"cx": self.ex(abs(x2-x1)), "cy": self.ey(abs(y2-y1))})
            pg = node(props, "a", "prstGeom", {"prst": "line"})
            node(pg, "a", "avLst")
            self.line_style(props, elem["stroke"])
            return
        sp = node(parent, "p", "sp")
        self.nonvisual(sp, elem, "Sp")
        props = node(sp, "p", "spPr")
        self.transform(props, elem)
        if typ == "path":
            self.custom_geometry(props, elem)
        else:
            geom = node(props, "a", "prstGeom", {"prst": elem.get("shape", "rect")})
            node(geom, "a", "avLst")
        solid_fill(props, elem["fill"], elem["fill_opacity"])
        self.line_style(props, elem["stroke"])
        if "text" in elem:
            self.text_body(sp, elem)

    @staticmethod
    def empty_tree(parent):
        tree = node(parent, "p", "spTree")
        nv = node(tree, "p", "nvGrpSpPr")
        node(nv, "p", "cNvPr", {"id": 1, "name": ""})
        node(nv, "p", "cNvGrpSpPr")
        node(nv, "p", "nvPr")
        gp = node(tree, "p", "grpSpPr")
        tx = node(gp, "a", "xfrm")
        for name, attrs in [("off", {"x": 0, "y": 0}), ("ext", {"cx": 0, "cy": 0}),
                            ("chOff", {"x": 0, "y": 0}), ("chExt", {"cx": 0, "cy": 0})]:
            node(tx, "a", name, attrs)
        return tree

    def slide_xml(self, slide):
        self.ids = {elem["id"]: i+2 for i, elem in enumerate(Scene.walk(slide["elements"]))}
        xml = root("p", "sld")
        cs = node(xml, "p", "cSld", {"name": slide["title"]})
        bg = node(cs, "p", "bg")
        bgp = node(bg, "p", "bgPr")
        solid_fill(bgp, slide["background"])
        node(bgp, "a", "effectLst")
        tree = self.empty_tree(cs)
        for elem in slide["elements"]:
            self.draw(tree, elem)
        cm = node(xml, "p", "clrMapOvr")
        node(cm, "a", "masterClrMapping")
        return xml

    def package(self):
        parts = {}
        presentation = root("p", "presentation")
        masters = node(presentation, "p", "sldMasterIdLst")
        node(masters, "p", "sldMasterId", {"id": 2147483648, f"{{{NS['r']}}}id": "rId1"})
        slides = node(presentation, "p", "sldIdLst")
        presrels = rels()
        relation(presrels, "rId1", "slideMaster", "slideMasters/slideMaster1.xml")
        for i, slide in enumerate(self.scene.slides, 1):
            node(slides, "p", "sldId", {"id": 255+i, f"{{{NS['r']}}}id": f"rId{i+1}"})
            relation(presrels, f"rId{i+1}", "slide", f"slides/slide{i}.xml")
            parts[f"ppt/slides/slide{i}.xml"] = self.slide_xml(slide)
            sr = rels()
            relation(sr, "rId1", "slideLayout", "../slideLayouts/slideLayout1.xml")
            parts[f"ppt/slides/_rels/slide{i}.xml.rels"] = sr
        node(presentation, "p", "sldSz", {"cx": round(self.scene.slide_width*EMU_PER_INCH),
                                           "cy": round(self.scene.slide_height*EMU_PER_INCH), "type": "custom"})
        node(presentation, "p", "notesSz", {"cx": 6858000, "cy": 9144000})
        parts["ppt/presentation.xml"] = presentation
        parts["ppt/_rels/presentation.xml.rels"] = presrels
        master = root("p", "sldMaster")
        self.empty_tree(node(master, "p", "cSld", {"name": "Vector scientific figure master"}))
        node(master, "p", "clrMap", {"bg1": "lt1", "tx1": "dk1", "bg2": "lt2", "tx2": "dk2",
             "accent1": "accent1", "accent2": "accent2", "accent3": "accent3", "accent4": "accent4",
             "accent5": "accent5", "accent6": "accent6", "hlink": "hlink", "folHlink": "folHlink"})
        layouts = node(master, "p", "sldLayoutIdLst")
        node(layouts, "p", "sldLayoutId", {"id": 2147483649, f"{{{NS['r']}}}id": "rId1"})
        styles = node(master, "p", "txStyles")
        for tag in ("titleStyle", "bodyStyle", "otherStyle"):
            st = node(styles, "p", tag)
            pp = node(st, "a", "lvl1pPr", {"algn": "l"})
            rp = node(pp, "a", "defRPr", {"sz": "1800"})
            solid_fill(rp, "#243447")
            node(rp, "a", "latin", {"typeface": "Arial"})
            node(rp, "a", "ea", {"typeface": "Microsoft YaHei"})
        parts["ppt/slideMasters/slideMaster1.xml"] = master
        mr = rels()
        relation(mr, "rId1", "slideLayout", "../slideLayouts/slideLayout1.xml")
        relation(mr, "rId2", "theme", "../theme/theme1.xml")
        parts["ppt/slideMasters/_rels/slideMaster1.xml.rels"] = mr
        layout = root("p", "sldLayout", {"type": "blank", "preserve": "1"})
        self.empty_tree(node(layout, "p", "cSld", {"name": "Blank"}))
        node(node(layout, "p", "clrMapOvr"), "a", "masterClrMapping")
        parts["ppt/slideLayouts/slideLayout1.xml"] = layout
        lr = rels()
        relation(lr, "rId1", "slideMaster", "../slideMasters/slideMaster1.xml")
        parts["ppt/slideLayouts/_rels/slideLayout1.xml.rels"] = lr
        parts["ppt/theme/theme1.xml"] = self.theme()
        top = rels()
        relation(top, "rId1", "officeDocument", "ppt/presentation.xml")
        node(top, "rel", "Relationship", {"Id": "rId2", "Type": NS["rel"] + "/metadata/core-properties", "Target": "docProps/core.xml"})
        relation(top, "rId3", "extended-properties", "docProps/app.xml")
        parts["_rels/.rels"] = top
        core = root("cp", "coreProperties")
        node(core, "dc", "title", text=self.scene.title)
        node(core, "dc", "creator", text="Doubao science PPT skill")
        node(core, "cp", "lastModifiedBy", text="Doubao science PPT skill")
        now = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        for tag in ("created", "modified"):
            node(core, "dcterms", tag, {f"{{{NS['xsi']}}}type": "dcterms:W3CDTF"}, now)
        parts["docProps/core.xml"] = core
        app = root("ep", "Properties")
        node(app, "ep", "Application", text="Native vector OOXML exporter")
        node(app, "ep", "PresentationFormat", text="Custom")
        node(app, "ep", "Slides", text=len(self.scene.slides))
        node(app, "ep", "AppVersion", text="1.0000")
        parts["docProps/app.xml"] = app
        ct = root("ct", "Types")
        node(ct, "ct", "Default", {"Extension": "rels", "ContentType": "application/vnd.openxmlformats-package.relationships+xml"})
        node(ct, "ct", "Default", {"Extension": "xml", "ContentType": "application/xml"})
        overrides = {"ppt/presentation.xml": "presentationml.presentation.main",
                     "ppt/slideMasters/slideMaster1.xml": "presentationml.slideMaster",
                     "ppt/slideLayouts/slideLayout1.xml": "presentationml.slideLayout",
                     "ppt/theme/theme1.xml": "theme"}
        for i in range(1, len(self.scene.slides)+1):
            overrides[f"ppt/slides/slide{i}.xml"] = "presentationml.slide"
        for path, kind in overrides.items():
            node(ct, "ct", "Override", {"PartName": "/"+path, "ContentType": "application/vnd.openxmlformats-officedocument."+kind+"+xml"})
        node(ct, "ct", "Override", {"PartName": "/docProps/core.xml", "ContentType": "application/vnd.openxmlformats-package.core-properties+xml"})
        node(ct, "ct", "Override", {"PartName": "/docProps/app.xml", "ContentType": "application/vnd.openxmlformats-officedocument.extended-properties+xml"})
        parts["[Content_Types].xml"] = ct
        return {name: xml_bytes(xml) for name, xml in parts.items()}

    @staticmethod
    def theme():
        xml = root("a", "theme", {"name": "Scientific figure"})
        elements = node(xml, "a", "themeElements")
        scheme = node(elements, "a", "clrScheme", {"name": "Scientific"})
        palette = {"dk1": "243447", "lt1": "FFFFFF", "dk2": "334155", "lt2": "F1F5F9",
                   "accent1": "2563EB", "accent2": "0D9488", "accent3": "EA580C", "accent4": "7C3AED",
                   "accent5": "0891B2", "accent6": "BE185D", "hlink": "0563C1", "folHlink": "954F72"}
        for name, value in palette.items():
            node(node(scheme, "a", name), "a", "srgbClr", {"val": value})
        fonts = node(elements, "a", "fontScheme", {"name": "Scientific"})
        for tag in ("majorFont", "minorFont"):
            font = node(fonts, "a", tag)
            node(font, "a", "latin", {"typeface": "Arial"})
            node(font, "a", "ea", {"typeface": "Microsoft YaHei"})
            node(font, "a", "cs", {"typeface": "Arial"})
            node(font, "a", "font", {"script": "Hans", "typeface": "Microsoft YaHei"})
        fmt = node(elements, "a", "fmtScheme", {"name": "Scientific"})
        fills = node(fmt, "a", "fillStyleLst")
        for _ in range(3):
            node(node(fills, "a", "solidFill"), "a", "schemeClr", {"val": "phClr"})
        lines = node(fmt, "a", "lnStyleLst")
        for width in (9525, 19050, 28575):
            ln = node(lines, "a", "ln", {"w": width, "cap": "flat", "cmpd": "sng", "algn": "ctr"})
            node(node(ln, "a", "solidFill"), "a", "schemeClr", {"val": "phClr"})
            node(ln, "a", "prstDash", {"val": "solid"})
            node(ln, "a", "miter", {"lim": "800000"})
        effects = node(fmt, "a", "effectStyleLst")
        for _ in range(3):
            node(node(effects, "a", "effectStyle"), "a", "effectLst")
        background = node(fmt, "a", "bgFillStyleLst")
        for _ in range(3):
            node(node(background, "a", "solidFill"), "a", "schemeClr", {"val": "phClr"})
        node(xml, "a", "objectDefaults")
        node(xml, "a", "extraClrSchemeLst")
        return xml


def read_scene(path):
    def reject_constant(value):
        raise SceneError(f"JSON constant {value} is forbidden")
    def reject_duplicate_keys(pairs):
        obj = {}
        for key, value in pairs:
            require(key not in obj, f"JSON duplicate key '{key}' is forbidden")
            obj[key] = value
        return obj
    with Path(path).open("r", encoding="utf-8-sig") as fp:
        raw = json.load(fp, parse_constant=reject_constant, object_pairs_hook=reject_duplicate_keys)
    return Scene(raw)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as fp:
        json.dump(value, fp, ensure_ascii=False, indent=2, allow_nan=False)
        fp.write("\n")


def build(scene_path, out_path, report_path=None):
    scene_path, out_path = Path(scene_path), Path(out_path)
    require(out_path.suffix.lower() == ".pptx", "--out must have .pptx extension")
    require(scene_path.resolve() != out_path.resolve(), "--out cannot overwrite scene JSON")
    if report_path:
        require(Path(report_path).resolve() not in {scene_path.resolve(), out_path.resolve()},
                "--report cannot overwrite input or PPTX")
    scene = read_scene(scene_path)
    package = Exporter(scene).package()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # Audit a temporary package before replacing the requested output.
    fd, temporary = tempfile.mkstemp(prefix=".vector-ppt-", suffix=".pptx", dir=str(out_path.parent))
    os.close(fd)
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, content in package.items():
                archive.writestr(name, content)
        from audit_pptx import audit_pptx
        audit = audit_pptx(temporary)
        require(audit["passed"], "generated PPTX failed XML audit: " + "; ".join(audit["errors"]))
        os.replace(temporary, out_path)
        audit["file"] = str(out_path.resolve())
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    count_keys = ("text_count", "shape_count", "path_count", "connector_count", "group_count", "raster_count", "element_count")
    report = {"passed": True, "output": str(out_path.resolve()), "source": str(scene_path.resolve()),
              "canvas": {"width": scene.width, "height": scene.height,
                         "slide_width_in": scene.slide_width, "slide_height_in": scene.slide_height},
              "slide_count": len(scene.slides),
              "counts": {key: sum(s[key] for s in scene.stats) for key in count_keys},
              "slides": scene.stats, "warnings": scene.warnings, "xml_audit": audit,
              "limitations": ["XML audit does not verify visual fidelity or font availability.",
                               "Open and inspect in PowerPoint/WPS for text fit and visual comparison."]}
    if report_path:
        write_json(report_path, report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("scene", help="Reviewed scene JSON (UTF-8)")
    parser.add_argument("--out", required=True, help="Output .pptx path")
    parser.add_argument("--report", help="Output JSON validation report")
    args = parser.parse_args(argv)
    try:
        report = build(args.scene, args.out, args.report)
    except (SceneError, OSError, json.JSONDecodeError, zipfile.BadZipFile, ET.ParseError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    counts = report["counts"]
    print(f"OK: {report['output']} | slides={report['slide_count']} "
          f"text={counts['text_count']} shapes={counts['shape_count']} paths={counts['path_count']} "
          f"connectors={counts['connector_count']} raster=0")
    for warning in report["warnings"]:
        print("WARNING: " + warning, file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
