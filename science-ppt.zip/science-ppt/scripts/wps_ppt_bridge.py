"""Render and prove native-text editability in WPS using private PPTX copies.

Windows-only COM operations, with pywin32 optional until invoked. stdout is a
single JSON object; errors exit nonzero and diagnostics go to stderr.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import struct
import sys
import tempfile
from typing import Any
import xml.etree.ElementTree as ET
import zipfile

from harness_wps_adapter import PresentationSession, readiness


PPTX_MAIN_TYPE = "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"
CHINESE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_pptx(path: str | Path) -> Path:
    path = Path(path).expanduser().resolve(strict=True)
    if not path.is_file() or path.suffix.lower() != ".pptx":
        raise ValueError(f"Expected an existing .pptx file: {path}")
    with zipfile.ZipFile(path) as archive:
        required = ("[Content_Types].xml", "ppt/presentation.xml")
        for member in required:
            info = archive.getinfo(member)
            if info.file_size > 16 * 1024 * 1024:
                raise ValueError(f"Unexpectedly large PPTX metadata: {member}")
        types = ET.fromstring(archive.read(required[0]))
        declared = any(
            node.attrib.get("PartName") == "/ppt/presentation.xml"
            and node.attrib.get("ContentType") == PPTX_MAIN_TYPE
            for node in types
        )
        if not declared:
            raise ValueError("File is not a standard OpenXML .pptx presentation.")
        ET.fromstring(archive.read(required[1]))
    return path


def new_path(value: str | Path, suffix: str | None = None) -> Path:
    requested = Path(value).expanduser()
    if requested.exists() or requested.is_symlink():
        raise FileExistsError(f"Refusing to overwrite existing path: {requested}")
    path = requested.resolve()
    if suffix and path.suffix.lower() != suffix:
        raise ValueError(f"Output must use {suffix}: {path}")
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite existing path: {path}")
    return path


def write_report(path: Path, payload: dict[str, Any]) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def png_size(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise OSError(f"Slide export did not produce a PNG image: {path}")
    width, height = struct.unpack(">II", header[16:24])
    if width < 1 or height < 1:
        raise OSError(f"PNG export has invalid dimensions: {path}")
    return width, height


def assert_unchanged(source: Path, digest: str) -> None:
    if sha256(source) != digest:
        raise OSError("Source file changed during verification; result cannot establish preservation.")


def application_info(session: PresentationSession) -> dict[str, Any]:
    return {"engine": session.engine, "progid": session.progid,
            "application_version": session.version,
            "reused_existing_application": session.reused_existing}


def render(args) -> dict[str, Any]:
    source = validate_pptx(args.pptx)
    output_dir = new_path(args.out_dir)
    if args.width < 1 or args.width > 8192:
        raise ValueError("Render width must be between 1 and 8192 pixels.")
    source_digest = sha256(source)
    output_dir.mkdir(parents=True, exist_ok=False)
    work_copy = output_dir / "render-source-copy.pptx"
    shutil.copy2(source, work_copy)
    report_path = output_dir / "render-report.json"
    images = []
    with PresentationSession(args.engine) as session:
        presentation = session.open_copy(work_copy)
        slide_count = int(presentation.Slides.Count)
        if slide_count < 1:
            raise ValueError("Presentation has no slides to render.")
        width_pt = float(presentation.PageSetup.SlideWidth)
        height_pt = float(presentation.PageSetup.SlideHeight)
        if width_pt <= 0 or height_pt <= 0:
            raise ValueError("Presentation has invalid slide dimensions in points.")
        height_px = max(1, round(args.width * height_pt / width_pt))
        for slide_index in range(1, slide_count + 1):
            path = output_dir / f"slide-{slide_index:03d}.png"
            if path.exists():
                raise FileExistsError(f"Refusing to overwrite: {path}")
            slide = presentation.Slides.Item(slide_index)
            slide.Export(str(path), "PNG", args.width, height_px)
            width, height = png_size(path)
            images.append({"slide": slide_index, "path": str(path),
                           "width_px": width, "height_px": height})
            slide = None
        info = application_info(session)
        session.close_copy(presentation)
        presentation = None
    assert_unchanged(source, source_digest)
    result = {"ok": True, "operation": "render", **info,
              "source": str(source), "source_sha256": source_digest,
              "source_unchanged": True, "working_copy": str(work_copy),
              "slide_count": slide_count,
              "slide_size_pt": {"width": width_pt, "height": height_pt},
              "images": images, "visual_qa": "pending", "report": str(report_path)}
    write_report(report_path, result)
    return result


def text_candidates(presentation):
    """Yield existing native text objects, including groups and table cells."""
    def walk(shape, path, depth=0):
        if depth > 12:
            return
        try:
            if int(shape.HasTextFrame) != 0 and int(shape.TextFrame.HasText) != 0:
                text_range = shape.TextFrame.TextRange
                text = str(text_range.Text)
                if CHINESE.search(text):
                    yield path, text_range, text, str(shape.Name)
        except AttributeError:
            pass
        except Exception as exc:
            # Some COM shape types expose a member but reject access. A failed
            # read is not evidence that a native label exists.
            print(f"Skip inaccessible text object {path}: {exc}", file=sys.stderr)
        try:
            if int(shape.Type) == 6:  # msoGroup
                for index in range(1, int(shape.GroupItems.Count) + 1):
                    yield from walk(shape.GroupItems.Item(index),
                                    path + [["group", index]], depth + 1)
        except Exception as exc:
            print(f"Skip inaccessible group object {path}: {exc}", file=sys.stderr)
        try:
            if int(shape.HasTable) != 0:
                for row in range(1, int(shape.Table.Rows.Count) + 1):
                    for col in range(1, int(shape.Table.Columns.Count) + 1):
                        yield from walk(shape.Table.Cell(row, col).Shape,
                                        path + [["cell", row, col]], depth + 1)
        except AttributeError:
            pass
        except Exception as exc:
            print(f"Skip inaccessible table object {path}: {exc}", file=sys.stderr)

    for slide_index in range(1, int(presentation.Slides.Count) + 1):
        slide = presentation.Slides.Item(slide_index)
        for shape_index in range(1, int(slide.Shapes.Count) + 1):
            yield from walk(slide.Shapes.Item(shape_index),
                            [["slide", slide_index], ["shape", shape_index]])


def resolve_shape(presentation, path):
    shape = None
    for item in path:
        if item[0] == "slide":
            slide = presentation.Slides.Item(item[1])
        elif item[0] == "shape":
            shape = slide.Shapes.Item(item[1])
        elif item[0] == "group":
            shape = shape.GroupItems.Item(item[1])
        elif item[0] == "cell":
            shape = shape.Table.Cell(item[1], item[2]).Shape
        else:
            raise ValueError(f"Unknown shape path entry: {item}")
    return shape


def verify_edit(args) -> dict[str, Any]:
    source = validate_pptx(args.pptx)
    output = new_path(args.out, ".pptx")
    report_path = new_path(output.with_suffix(".verification.json"))
    output.parent.mkdir(parents=True, exist_ok=True)
    source_digest = sha256(source)
    # Keep the isolated copy for review. Its unique directory cannot contain an
    # already-open user deck; no recursive deletion or application quit occurs.
    work_dir = Path(tempfile.mkdtemp(prefix=f".{output.stem}-edit-", dir=output.parent))
    work_copy = work_dir / "edit-source-copy.pptx"
    shutil.copy2(source, work_copy)
    with PresentationSession(args.engine) as session:
        presentation = session.open_copy(work_copy)
        chosen = None
        for candidate in text_candidates(presentation):
            if chosen is None:
                chosen = candidate
            if 1 <= len(candidate[2].strip()) <= 80:
                chosen = candidate
                break
        if chosen is None:
            raise ValueError("No existing native Chinese text label found; editability cannot be proved.")
        shape_path, text_range, original_text, shape_name = chosen
        edited_text = original_text.rstrip("\r\n") + "（编辑验证）" + original_text[len(original_text.rstrip("\r\n")):]
        text_range.Text = edited_text
        observed_text = str(text_range.Text)
        if observed_text != edited_text or observed_text == original_text:
            raise OSError("COM did not retain the requested native-text change.")
        text_range = None
        chosen = None
        candidate = None
        session.save_pptx(presentation, output)
        session.close_copy(presentation)
        presentation = None
        validate_pptx(output)
        reopened = session.open_copy(output)
        persisted_shape = resolve_shape(reopened, shape_path)
        persisted_text = str(persisted_shape.TextFrame.TextRange.Text)
        if persisted_text != edited_text or persisted_text == original_text:
            raise OSError("Reopened PPTX does not contain the verified native-text change.")
        persisted_shape = None
        slide_count = int(reopened.Slides.Count)
        info = application_info(session)
        session.close_copy(reopened)
        reopened = None
    assert_unchanged(source, source_digest)
    result = {"ok": True, "operation": "verify-edit", **info,
              "source": str(source), "source_sha256": source_digest,
              "source_unchanged": True, "working_copy": str(work_copy),
              "output": str(output), "output_sha256": sha256(output),
              "slide_count": slide_count, "native_text_edit_verified": True,
              "evidence": {"shape_path": shape_path, "shape_name": shape_name,
                           "before": original_text, "after_in_memory": observed_text,
                           "after_reopen": persisted_text},
              "visual_qa": "pending", "report": str(report_path)}
    write_report(report_path, result)
    return result


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--engine", choices=("wps", "powerpoint"), default="wps",
                        help="Explicit COM engine; default WPS, never silently falls back.")
    commands = parser.add_subparsers(dest="operation", required=True)
    check = commands.add_parser("readiness", help="Check imports and COM registration; never starts an app.")
    render_parser = commands.add_parser("render", help="Render all slides from a private PPTX copy into a NEW directory.")
    render_parser.add_argument("--pptx", required=True)
    render_parser.add_argument("--out-dir", required=True)
    render_parser.add_argument("--width", type=int, default=1600, help="PNG width in pixels (1..8192).")
    edit_parser = commands.add_parser("verify-edit", help="Modify one existing native Chinese label in a copy, save and reopen.")
    edit_parser.add_argument("--pptx", required=True)
    edit_parser.add_argument("--out", required=True, help="NEW .pptx output; .verification.json is also NEW.")
    # Accept the explicit engine beside either the command or its options.
    for command in (check, render_parser, edit_parser):
        command.add_argument("--engine", choices=("wps", "powerpoint"), default=argparse.SUPPRESS)
    return parser.parse_args(argv)


def main(argv=None) -> int:
    try:
        args = parse_args(argv)
    except SystemExit as exc:
        if exc.code:
            print(json.dumps({"ok": False, "error_type": "ArgumentError",
                              "error": "Invalid command arguments; see stderr."},
                             ensure_ascii=False))
        return int(exc.code or 0)
    try:
        if args.operation == "readiness":
            result = readiness(args.engine)
        elif args.operation == "render":
            result = render(args)
        else:
            result = verify_edit(args)
        print(json.dumps(result, ensure_ascii=False))
        return 0 if result.get("ok") else 1
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        print(json.dumps({"ok": False, "operation": args.operation,
                          "engine": args.engine, "error_type": type(exc).__name__,
                          "error": str(exc)}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    # A JSON bridge must have a stable encoding even on a Chinese Windows host.
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    raise SystemExit(main())
