<#
.SYNOPSIS
Render a local PPTX with installed Microsoft PowerPoint, preserving user decks.
.DESCRIPTION
Creates a NEW preview folder below the PPTX directory. Opens a temporary copy
read-only without a document window, exports PNGs, then closes only that copy.
Never calls Application.Quit, Save, SaveAs, or closes any other presentation.
PowerPoint is optional; this does not install Office or claim visual QA.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$PptxPath,
    [Parameter(Mandatory = $true)][string]$OutDir,
    [ValidateRange(320, 7680)][int]$Width = 1920
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Assert-NoReparsePath([string]$Path) {
    $current = $Path
    while (-not [string]::IsNullOrEmpty($current)) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Symbolic link/reparse path is not allowed: $current"
            }
        }
        $parent = [IO.Directory]::GetParent($current)
        if ($null -eq $parent) { break }
        $current = $parent.FullName
    }
}

function Release-Com([object]$Value) {
    if ($null -ne $Value -and [Runtime.InteropServices.Marshal]::IsComObject($Value)) {
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($Value)
    }
}

if ($env:OS -ne 'Windows_NT') { throw 'This optional renderer requires Windows and installed Microsoft PowerPoint.' }
foreach ($pathArgument in @($PptxPath, $OutDir)) {
    $absolute = $pathArgument -match '^[A-Za-z]:[\\/]' -or $pathArgument -match '^\\\\[^\\]+\\[^\\]+[\\/]'
    if (-not $absolute -or $pathArgument -match '(^|[\\/])\.\.([\\/]|$)') {
        throw 'PptxPath and OutDir must be absolute paths without .. components.'
    }
}
$source = [IO.Path]::GetFullPath($PptxPath)
$previewDir = [IO.Path]::GetFullPath($OutDir)
Assert-NoReparsePath $source
Assert-NoReparsePath $previewDir
if (-not (Test-Path -LiteralPath $source -PathType Leaf) -or [IO.Path]::GetExtension($source) -ine '.pptx') {
    throw 'PptxPath must name an existing .pptx file.'
}
$jobDir = [IO.Path]::GetDirectoryName($source)
$jobPrefix = $jobDir.TrimEnd([char[]]'\/') + [IO.Path]::DirectorySeparatorChar
if (-not $previewDir.StartsWith($jobPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'OutDir must be a new subdirectory below the PPTX directory.'
}
if (Test-Path -LiteralPath $previewDir) { throw 'OutDir already exists; choose a new folder to prevent overwrite.' }

$app = $null
$presentations = $null
$deck = $null
$slides = $null
$pageSetup = $null
$copyPath = $null
$created = $false
$rendered = @()
$failure = $null
$report = [ordered]@{
    status = 'pending'
    source = $source
    preview_dir = $previewDir
    renderer = 'Microsoft PowerPoint COM'
    closes_only_own_copy = $true
    visual_qa = 'pending'
}
$stage = 'initialize PowerPoint'
try {
    # PowerPoint may reuse its existing application instance. Never quit it.
    $app = New-Object -ComObject PowerPoint.Application
    $presentations = $app.Presentations
    $report.application_version = [string]$app.Version
    $report.presentations_before = [int]$presentations.Count
    $stage = 'create preview directory and copy source'
    # Create exclusively: no existing preview or files may be replaced.
    [void][IO.Directory]::CreateDirectory($previewDir)
    $created = $true
    Assert-NoReparsePath $previewDir
    $copyPath = Join-Path $previewDir ('_render-input-' + [guid]::NewGuid().ToString('N') + '.pptx')
    [IO.File]::Copy($source, $copyPath, $false)
    $report.copy_path = $copyPath
    $report.source_bytes = [long](Get-Item -LiteralPath $source).Length
    $report.copy_bytes = [long](Get-Item -LiteralPath $copyPath).Length
    $report.source_sha256 = [string](Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    $report.copy_sha256 = [string](Get-FileHash -LiteralPath $copyPath -Algorithm SHA256).Hash
    if ($report.source_bytes -ne $report.copy_bytes -or $report.source_sha256 -ne $report.copy_sha256) {
        throw 'Renderer copy differs from source; source may have changed during copy.'
    }
    $stage = 'open own read-only PPTX copy'
    # msoTrue=-1 ReadOnly; msoFalse=0 Untitled and WithWindow.
    $deck = $presentations.Open($copyPath, -1, 0, 0)
    $slides = $deck.Slides
    $pageSetup = $deck.PageSetup
    $height = [int][Math]::Round($Width * [double]$pageSetup.SlideHeight / [double]$pageSetup.SlideWidth)
    $report.slide_count = [int]$slides.Count
    $report.width_px = $Width
    $report.height_px = $height
    for ($index = 1; $index -le $slides.Count; $index++) {
        $stage = "export slide $index PNG"
        $slide = $null
        try {
            $slide = $slides.Item($index)
            $pngPath = Join-Path $previewDir ('slide-{0:D3}.png' -f $index)
            if (Test-Path -LiteralPath $pngPath) { throw "Preview file already exists: $pngPath" }
            $slide.Export($pngPath, 'PNG', $Width, $height)
            if (-not (Test-Path -LiteralPath $pngPath -PathType Leaf) -or (Get-Item -LiteralPath $pngPath).Length -eq 0) {
                throw "PowerPoint did not produce slide $index PNG."
            }
            $rendered += $pngPath
        } finally { Release-Com $slide }
    }
    $report.status = 'rendered'
    $report.images = $rendered
    $report.message = 'PNG export succeeded. Inspect every preview against the text brief and design plan before marking visual QA passed.'
} catch {
    $failure = $_.Exception.Message
    $report.status = 'error'
    $report.error = $failure
    $report.error_stage = $stage
    $report.images = $rendered
} finally {
    Release-Com $pageSetup
    Release-Com $slides
    if ($null -ne $deck) {
        try { $deck.Close() } catch {
            $failure = 'Could not close the renderer copy: ' + $_.Exception.Message
            $report.status = 'error'
            $report.error = $failure
        }
        Release-Com $deck
    }
    if ($null -ne $presentations) {
        try { $report.presentations_after = [int]$presentations.Count } catch { }
    }
    Release-Com $presentations
    Release-Com $app
    # Delete only our known copy, after PowerPoint closed it; no recursive delete.
    if ($null -ne $copyPath -and (Test-Path -LiteralPath $copyPath)) {
        try {
            Assert-NoReparsePath $copyPath
            if (-not $copyPath.StartsWith($previewDir.TrimEnd([char[]]'\/') + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
                throw 'Temporary copy escaped preview directory.'
            }
            Remove-Item -LiteralPath $copyPath
        } catch {
            $report.temporary_copy_retained = $copyPath
            $report.cleanup_note = $_.Exception.Message
        }
    }
}
if ($created) {
    $reportPath = Join-Path $previewDir 'render-report.json'
    $json = $report | ConvertTo-Json -Depth 8
    $stream = [IO.File]::Open($reportPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    $writer = New-Object IO.StreamWriter($stream, (New-Object Text.UTF8Encoding($false)))
    try { $writer.WriteLine($json) } finally { $writer.Dispose() }
}
$report | ConvertTo-Json -Depth 8
if ($null -ne $failure) { exit 2 }
