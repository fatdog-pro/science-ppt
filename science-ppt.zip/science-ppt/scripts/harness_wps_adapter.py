"""Safe, optional COM adapter for scientific PowerPoint verification in WPS.

Adapted from yb2460/harness-anything, WPS/ppt-engine/pptengine/wps.py.
Copyright (c) 2026 cli-anything-wps contributors. Distributed under MIT;
see ../supporting-skills/wps-ppt-automation/LICENSE and SOURCE.md.

The caller must provide a private copy of its presentation. The adapter never
quits an application, kills a process, or closes a presentation it did not open.
"""
from __future__ import annotations

import importlib.util
import os
from pathlib import Path
import sys
import threading
from typing import Any


PROGIDS = {"wps": "KWPP.Application", "powerpoint": "PowerPoint.Application"}
PPTX_FORMAT = 24  # ppSaveAsOpenXMLPresentation; 1 is legacy binary .ppt.


class PresentationConnectionError(RuntimeError):
    """The selected presentation application could not be used."""


def readiness(engine: str = "wps") -> dict[str, Any]:
    """Check modules and registered ProgID without creating a COM application."""
    if engine not in PROGIDS:
        raise ValueError(f"Unsupported presentation engine: {engine}")
    result: dict[str, Any] = {
        "operation": "readiness", "engine": engine, "progid": PROGIDS[engine],
        "platform": sys.platform, "starts_application": False,
        "dependencies": {}, "com_registered": False,
    }
    for module in ("pythoncom", "win32com.client"):
        try:
            available = importlib.util.find_spec(module) is not None
        except (ImportError, ModuleNotFoundError, ValueError):
            available = False
        result["dependencies"][module] = available
    if sys.platform == "win32":
        import winreg

        # HKCR is a merged registration view; also inspect the other bitness.
        views = (0, winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY)
        for view in views:
            try:
                with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT,
                                    PROGIDS[engine] + "\\CLSID", 0,
                                    winreg.KEY_READ | view) as key:
                    clsid = str(winreg.QueryValueEx(key, "")[0])
                with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT,
                                    "CLSID\\" + clsid, 0,
                                    winreg.KEY_READ | view):
                    pass
                result.update(com_registered=True, clsid=clsid)
                break
            except OSError:
                continue
    result["ready"] = (
        sys.platform == "win32" and result["com_registered"]
        and all(result["dependencies"].values())
    )
    result["ok"] = result["ready"]
    return result


class PresentationSession:
    """A thread-local COM lifetime with explicitly owned presentations only."""

    def __init__(self, engine: str = "wps"):
        if engine not in PROGIDS:
            raise ValueError(f"Unsupported presentation engine: {engine}")
        self.engine = engine
        self.progid = PROGIDS[engine]
        self.app = None
        self.reused_existing = False
        self.version = None
        self._pythoncom = None
        self._thread = None
        self._owned: list[Any] = []

    def __enter__(self) -> "PresentationSession":
        if sys.platform != "win32":
            raise PresentationConnectionError("Presentation COM requires Windows.")
        if self._pythoncom is not None:
            raise PresentationConnectionError("Session is already initialized.")
        try:
            import pythoncom
            import win32com.client
        except ImportError as exc:
            raise PresentationConnectionError(
                "Missing optional pywin32 in this Python interpreter."
            ) from exc
        pythoncom.CoInitialize()
        self._pythoncom = pythoncom
        self._thread = threading.get_ident()
        try:
            try:
                self.app = win32com.client.GetActiveObject(self.progid)
                self.reused_existing = True
            except pythoncom.com_error:
                self.app = win32com.client.Dispatch(self.progid)
            _ = self.app.Presentations.Count  # Validate RPC before any file open.
            self.app.Visible = -1  # msoTrue; WPS requires a visible application.
            try:
                self.version = str(self.app.Version)
            except (pythoncom.com_error, AttributeError):
                self.version = None
            return self
        except Exception as exc:
            self.app = None
            self._release_com()
            raise PresentationConnectionError(
                f"Cannot connect to selected engine {self.engine} ({self.progid}): {exc}"
            ) from exc

    def _check_thread(self) -> None:
        if self._pythoncom is None or threading.get_ident() != self._thread:
            raise PresentationConnectionError("COM session must remain on its initialized thread.")

    def open_copy(self, path: Path):
        """Open a caller-owned working copy and register it for safe close."""
        self._check_thread()
        path = Path(path).resolve(strict=True)
        if path.suffix.lower() != ".pptx" or not path.is_file():
            raise ValueError(f"Expected an existing .pptx working copy: {path}")
        normalized = os.path.normcase(str(path))
        # Even a self-owned file must not be reused if the user already opened it.
        for index in range(1, int(self.app.Presentations.Count) + 1):
            candidate = self.app.Presentations.Item(index)
            try:
                current = os.path.normcase(str(Path(str(candidate.FullName)).resolve()))
                if current == normalized:
                    raise PresentationConnectionError(f"Working copy is already open: {path}")
            finally:
                candidate = None
        pres = self.app.Presentations.Open(str(path), 0, 0, -1)
        self._owned.append(pres)
        return pres

    def save_pptx(self, presentation, path: Path) -> None:
        self._check_thread()
        if not any(item is presentation for item in self._owned):
            raise PresentationConnectionError("Refusing to save an unowned presentation.")
        path = Path(path).resolve()
        if path.suffix.lower() != ".pptx":
            raise ValueError("Output must use the .pptx extension.")
        if path.exists():
            raise FileExistsError(f"Refusing to overwrite: {path}")
        presentation.SaveAs(str(path), PPTX_FORMAT)
        if not path.is_file() or path.stat().st_size == 0:
            raise OSError(f"Application SaveAs did not produce a nonempty file: {path}")

    def close_copy(self, presentation) -> None:
        self._check_thread()
        owned_index = next((i for i, item in enumerate(self._owned)
                            if item is presentation), None)
        if owned_index is None:
            raise PresentationConnectionError("Refusing to close an unowned presentation.")
        # A verifier may have unsaved changes on its disposable copy. Suppress
        # the prompt only for this owned presentation, never global app alerts.
        presentation.Saved = -1
        presentation.Close()
        del self._owned[owned_index]

    def _release_com(self) -> None:
        pythoncom = self._pythoncom
        self._pythoncom = None
        self._thread = None
        if pythoncom is not None:
            pythoncom.CoUninitialize()

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        self._check_thread()
        errors = []
        for presentation in list(reversed(self._owned)):
            try:
                self.close_copy(presentation)
            except Exception as close_error:
                errors.append(str(close_error))
        self._owned.clear()
        presentation = None
        self.app = None  # Release our proxy; never call Application.Quit().
        self._release_com()
        if errors:
            message = "Cannot close one or more owned copies: " + "; ".join(errors)
            if exc_type is None:
                raise PresentationConnectionError(message)
            print(message, file=sys.stderr)
        return False
