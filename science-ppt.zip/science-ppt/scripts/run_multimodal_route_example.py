"""Reproduce the bundled multimodal sensing and diagnosis route in visible WPS."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys


def checked_path(value, must_exist=False):
    path = Path(value)
    if not path.is_absolute():
        raise ValueError("All file paths must be absolute.")
    path = Path(os.path.abspath(path))
    for candidate in [path, *path.parents]:
        if candidate.exists() or candidate.is_symlink():
            info = candidate.lstat()
            if candidate.is_symlink() or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
                raise ValueError("Symbolic links and reparse points are not allowed: " + str(candidate))
    if must_exist and not path.is_file():
        raise ValueError("Expected an existing file: " + str(path))
    return path


def write_json(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def run_step(command, log_path, timeout):
    try:
        completed = subprocess.run(
            command, capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=timeout, shell=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except subprocess.TimeoutExpired as exc:
        # A foreground helper's presentation remains available in WPS; the
        # application and user presentations are never terminated.
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode("utf-8", "replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode("utf-8", "replace")
        log_path.write_text(stdout + "\n" + stderr + "\nTimeout.\n", encoding="utf-8")
        raise RuntimeError("Step timed out; inspect " + str(log_path)) from exc
    log_path.write_text(completed.stdout + "\n" + completed.stderr, encoding="utf-8")
    return completed


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def run(out_dir, wps_python=None, export_only=False):
    out_dir = checked_path(out_dir)
    if out_dir.exists():
        raise ValueError("Use a new output directory; existing outputs are never overwritten.")
    skill_root = Path(__file__).resolve().parent.parent
    scripts = skill_root / "scripts"
    example = skill_root / "assets" / "examples" / "multimodal-sensing-diagnosis"
    scene = checked_path(str(example / "scene.json"), True)
    brief = checked_path(str(example / "brief.json"), True)
    for script in ("build_pptx.py", "audit_pptx.py", "assemble_wps_foreground.py"):
        checked_path(str(scripts / script), True)
    out_dir.mkdir(parents=True)
    shutil.copyfile(scene, out_dir / "scene.json")
    shutil.copyfile(brief, out_dir / "brief.json")
    source_hash = hashlib.sha256(scene.read_bytes()).hexdigest()
    result = {
        "status": "pending", "example": "multimodal-sensing-diagnosis",
        "output_directory": str(out_dir), "scene_sha256": source_hash,
        "job_dir": str(out_dir),
        "source_scene": str(scene), "scene_unchanged": True,
        "export_pptx": str(out_dir / "figure-editable.pptx"),
        "foreground_pptx": str(out_dir / "multimodal-route-foreground.pptx"),
        "structural_validation": "pending", "foreground_status": "pending",
        "visual_inspection": "pending", "no_deliberate_delays": True,
        "qa_report": str(out_dir / "qa.json"),
        "qa_path": str(out_dir / "qa.json"),
        "pptx_path": str(out_dir / "figure-editable.pptx"),
        "build_report_path": str(out_dir / "build-report.json"),
        "audit_report_path": str(out_dir / "audit-report.json"),
    }
    try:
        build = run_step([
            sys.executable, "-E", "-S", "-X", "utf8", str(scripts / "build_pptx.py"),
            str(out_dir / "scene.json"), "--out", result["export_pptx"],
            "--report", str(out_dir / "build-report.json"),
        ], out_dir / "build.log", 60)
        if build.returncode != 0:
            raise RuntimeError("Native PPTX build failed; inspect build.log.")
        audit = run_step([
            sys.executable, "-E", "-S", "-X", "utf8", str(scripts / "audit_pptx.py"),
            result["export_pptx"], "--out", str(out_dir / "audit-report.json"),
        ], out_dir / "audit.log", 60)
        audit_report = read_json(out_dir / "audit-report.json")
        if audit.returncode != 0 or not audit_report.get("passed"):
            raise RuntimeError("Native PPTX structural audit failed; inspect audit-report.json.")
        result.update(structural_validation="passed", slide_count=audit_report["slide_count"], native_counts=audit_report["counts"])
        if export_only:
            result.update(status="complete", foreground_status="pending", application_validation="pending; export-only requested")
        else:
            report_path = out_dir / "foreground-report.json"
            try:
                interpreter = checked_path(wps_python or sys.executable, True)
                foreground = run_step([
                    str(interpreter), "-E", "-X", "utf8", str(scripts / "assemble_wps_foreground.py"),
                    "--source", result["export_pptx"], "--out", result["foreground_pptx"],
                    "--report", str(report_path), "--preview-dir", str(out_dir / "wps-preview"),
                ], out_dir / "foreground.log", 240)
                foreground_report = read_json(report_path) if report_path.is_file() else {}
                state = foreground_report.get("status", "error")
                foreground_returncode = foreground.returncode
            except (ValueError, FileNotFoundError, PermissionError) as exc:
                foreground_report = {"status": "unavailable", "error": "WPS Python interpreter is unavailable: " + str(exc)}
                write_json(report_path, foreground_report)
                state = "unavailable"
                foreground_returncode = 1
            result["foreground_status"] = state
            result["foreground_report"] = str(report_path)
            result["foreground_report_path"] = str(report_path)
            if state == "complete" and not foreground_report.get("physical_new_window_verified", False):
                state = "error"
                foreground_report["error"] = "The independent WPS window was not verified."
            result["physical_new_window_verified"] = foreground_report.get("physical_new_window_verified", False)
            for field in ("focus_policy", "window_size_policy", "initial_window_observation", "window_observation", "foreground_verified"):
                if field in foreground_report:
                    result[field] = foreground_report[field]
            if foreground_returncode != 0 or state != "complete":
                result.update(status="pending" if state == "unavailable" else "error", error=foreground_report.get("error", "WPS assembly failed; inspect foreground.log."))
                result["application_validation"] = "pending"
            else:
                final_audit = run_step([
                    sys.executable, "-E", "-S", "-X", "utf8", str(scripts / "audit_pptx.py"),
                    result["foreground_pptx"], "--out", str(out_dir / "foreground-audit-report.json"),
                ], out_dir / "foreground-audit.log", 60)
                final_report = read_json(out_dir / "foreground-audit-report.json")
                if final_audit.returncode != 0 or not final_report.get("passed"):
                    raise RuntimeError("WPS output structural audit failed; inspect foreground-audit-report.json.")
                if final_report["counts"] != audit_report["counts"] or final_report["slide_count"] != audit_report["slide_count"]:
                    raise RuntimeError("WPS assembly changed native object counts.")
                result.update(status="complete", application_validation="passed; WPS assembled, saved and exported preview", left_open_for_user=foreground_report.get("left_open_for_user", False), source_pptx_unchanged=foreground_report.get("source_unchanged", False))
                result.update(pptx_path=result["foreground_pptx"], foreground_report_path=str(report_path), foreground_audit_report_path=str(out_dir / "foreground-audit-report.json"), preview_path=str(out_dir / "wps-preview" / "final-preview.png"), reference_preview_path=str(out_dir / "wps-preview" / "original-preview.png"))
    except Exception as exc:
        result.update(status="error", error=str(exc))
    result["scene_unchanged"] = hashlib.sha256(scene.read_bytes()).hexdigest() == source_hash
    if not result["scene_unchanged"]:
        result.update(status="error", error="The bundled scene changed during the demonstration.")
    write_json(out_dir / "qa.json", result)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", required=True, help="New absolute directory for this reproduction")
    parser.add_argument("--wps-python", help="Absolute Python executable with pywin32; defaults to this interpreter")
    parser.add_argument("--export-only", action="store_true", help="Build and audit only; WPS/application and visual verification remain pending")
    args = parser.parse_args(argv)
    try:
        result = run(args.out_dir, args.wps_python, args.export_only)
    except Exception as exc:
        result = {"status": "error", "error": str(exc)}
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0 if result["status"] in {"complete", "pending"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
