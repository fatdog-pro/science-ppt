# 文本需求示例：Chiplet 科研组会的三页图解

## 用户需求

请做三页 16:9 的中文科研图解，介绍 Chiplet 的封装架构、分层互连和研究权衡。输出一个可用 WPS 演示和 PowerPoint 打开的 `.pptx`，图中文字、形状、连接符、剖面和立体表面都要能编辑。画面精致、留白充分、层次明确，每页使用符合内容的构图。直接由文字组织原生矢量对象。

## 内容与证据边界

1. **封装架构**：采用概念 2.5D 结构，计算、加速与 I/O 芯粒并排置于硅中介层，中介层下方为封装基板。顶部功能芯粒、微凸点、横向金属互连、中介层、基板分别建成有语义名称的可编辑对象。外观不代表任何具体商业产品，层厚与接触点数量仅用于结构示意。
2. **互连机制**：采用 UCIe 1.0 的平面协议层、D2D 适配层与物理层。图左表达逻辑层次，图右表达微凸点—中介层走线—微凸点的电互连剖面，两图通过物理层映射关系相连。Standard Package / Advanced Package 是封装实现类别，不添加到三层协议堆栈中。可靠传输功能取决于配置。
3. **研究权衡**：把“切分边界—互连方案—测试与可靠性”画为拟议联合设计迭代。右侧列出带宽与时延、热与供电、材料与应力、测试与成本的验证问题。这是设计归纳，不是本组实验结果。不绘制任何无数据支撑的成本、温度或良率曲线。

## 视觉约定

- 统一画幅：1600×900 设计坐标，对应 13⅓×7½ 英寸。
- 颜色：深蓝 `#152C43` 为正文与封面底色，青绿 `#087F8C` 为机制与重点，铜金 `#D7A24A` 为物理接触／互连；浅色辅助面板只支持内容分层。
- 主标题 52px = 31.2pt；正文和主要图示标签 30–38px = 18–22.8pt。来源及页码 22–24px = 13.2–14.4pt。
- 第1页：深色封面型构图，左侧原生立体封装，右侧两段结构解释。
- 第2页：浅色技术构图，左侧分层堆栈，右侧物理剖面。
- 第3页：浅色研究讨论构图，左侧闭环关系，右侧纵向研究问题。
- 单向语义关系使用一个原生连接符及其箭头；金属走线没有箭头。立体表面是原生自由路径，不是 SVG 或图片。

## 原始来源

- S1：imec, [Chiplets: Piecing Together the Next Generation of Chips, Part I](https://www.imec-int.com/en/articles/chiplets-piecing-together-next-generation-chips-part-i)，2024。用于概念分割、2.5D 并排连接及系统层权衡。
- S2：UCIe Consortium, [Building an Open Chiplet Ecosystem](https://www.uciexpress.org/_files/ugd/0c1418_c5970a68ab214ffc97fab16d11581449.pdf)，2022。用于 UCIe 1.0 平面层次和封装类别区分。
- S3：imec, [Chiplets: Piecing Together the Next Generation of Chips, Part II](https://www.imec-int.com/en/articles/chiplets-piecing-together-next-generation-chips-part-ii-0)，2024。用于 KGD、互连与组装后测试的研究问题。

## 可运行输入

完整三页输入为 `example-text-vector-scene.json`；`example-multipage-scene.json` 是同一示例。`example-scene.json` 保留第1页，可用于单页任务。三者都没有图片输入，也不依赖生图模型。用主技能通用入口在独立 WPS 新窗口可见构建，不只导出源稿：

```text
python <skill-root>/scripts/run_science_ppt.py --scene <skill-root>/assets/example-text-vector-scene.json --out-dir <new-job-directory> --wps-python <absolute-python-with-pywin32>
```

有 STDIO 连接器时，将该文件的完整 scene 内容交给 `export_scene`，默认也执行可见构建。只有用户明确仅导出或不启动 WPS 时才加 `--export-only` / `"export_only":true`。窗口尊重用户焦点与尺寸，不加演示停顿。示例用于展示精致构图和原生编辑对象的组织方式；实际科研任务仍需按用户材料核对对象、术语、关系和数据。
