# 芯片封装的发展历程：来源与适用范围

核验日期：2026-10-11。全部结构图为自行绘制的原生可编辑概念示意，非真实尺寸、非产品实测截面；重复接点与层数仅作示意。年代阶段不是技术首次发明时间；量产、发布与标准公开分别标注。

1. [Computer History Museum：封装首次考虑系统设计](https://www.computerhistory.org/siliconengine/package-is-the-first-to-accommodate-system-design-considerations/)。支持第1–2页：早期金属罐/陶瓷/扁平封装，1965 Fairchild 14引脚陶瓷 DIP 档案节点，1970年代初塑封 DIP 量产。采用博物馆1965节点，不与其他资料1964说法混用。
2. [日本半导体历史馆：1970年代封装](https://www.shmj.or.jp/english/packaging/pac70s.html)、[1980年代封装](https://www.shmj.or.jp/english/packaging/pac80s.html)。支持第2–3页：消费电子推动塑封材料和工艺；1977 QFP记录及1980年代表面贴装扩展。不是“1980年发明QFP”。
3. [Intel BGA Design（1997）](https://download.intel.com/design/intarch/technote/bga_des.pdf)。支持第4页：高引脚数的BGA应用与板级设计。文中有引线键合BGA，支持BGA不等于倒装互连。
4. [TI AN-1126 BGA](https://www.ti.com/lit/an/snoa021c/snoa021c.pdf)，第3–4页与13页。支持第4页：SMT兼容、底部焊球布局、基板、引线键合、装配及隐藏焊点检测。不推广单一器件参数为全部BGA能力。
5. [IEEE IRDS 2024：Electronic Packaging Tutorial Part 1](https://irds.ieee.org/images/files/pdf/2024/2024IRDS_EPT-Part1.pdf)，印刷页26–28。支持第5页：1960年代IBM C4起源，芯片有源面朝下、芯片面阵列凸点与互连路径。
6. [Amkor Flip Chip](https://amkor.com/technology/flip-chip/)。支持第5页：缩短芯片互连路径、面阵列接点；1999是Amkor提供OSAT FCiP服务节点，不是倒装发明年份。
7. [Intel MicroBGA原始新闻稿（1996-12-02）](https://www.intel.com/pressroom/archive/releases/1996/fl120296.htm)。支持第6页：1996宣布采用、1997计划在部分闪存导入；MicroBGA/CSP小型化是具体产品例，不等于WLCSP首次出现。
8. [Amkor WLCSP](https://amkor.com/packaging/wafer-level-packaging/wlcsp/)。支持第6页：晶圆级凸点与可选RDL，裸片范围内的fan-in与板级连接。2009是该公司的CSPn3方案量产，不是整个WLCSP发明时间。
9. [IEEE Heterogeneous Integration Roadmap 2021：Wafer Level Packaging](https://eps.ieee.org/images/files/HIR_2021/ch23_wlp.pdf)。支持第6页：fan-out/eWLB的模塑重构晶圆与RDL；Infineon eWLB于2009年初量产。
10. [TSMC 2016年报：技术发展](https://investor.tsmc.com/static/annualReports/2016/english/e_5_2.html)。支持第6页：2016 InFO PoP进入大量生产，不是fan-out发明年份。
11. [ASE System-in-Package](https://ase.aseglobal.com/system-in-package/)。支持第7页：SiP整合系统或子系统，可包含逻辑、存储、MEMS与无源器件；系统集成概念可采用多种封装互连工艺。
12. [TSMC CoWoS](https://3dfabric.tsmc.com/english/dedicatedFoundry/technology/cowos.htm)。支持第8页：2012量产；典型CoWoS-S硅中介层上的逻辑与HBM并排、TSV向下连接基板。CoWoS还有其他中介层/桥接变体，图不代表全部变体。
13. [SK hynix：HBM发展历程](https://news.skhynix.com/cn/hbm-design-head-myeong-jae-park/)、[公司技术历史](https://news.skhynix.com/en/heritage/)。支持第8页：2013年12月第一代HBM推出，TSV支持DRAM垂直堆叠；不是2013已大规模部署。示意层数不代表具体HBM产品。
14. [Intel 2018架构与Foveros发布](https://www.intc.com/news-events/press-releases/detail/106/new-intel-architectures-and-technologies-target-expanded)。支持第9页：2018宣布Foveros逻辑垂直堆叠，不标为2018量产。
15. [TSMC 2022年报](https://investor.tsmc.com/static/annualReports/2022/english/index.html)，技术发展部分（印刷页50–52）。支持第9页：2022 SoIC CoW进入量产，官方例为SRAM叠到逻辑晶圆。
16. [Intel Packaging](https://www.intel.com/content/www/us/en/foundry/packaging.html)。支持第9页：Foveros Direct的Cu-to-Cu混合键合；不能把所有Foveros或所有HBM解释为混合键合。EMIB自2017量产，局部硅桥区别于全尺寸硅中介层。
17. [UCIe 1.0官方发布（2022-03-02）](https://www.uciexpress.org/_files/ugd/0c1418_e7fa0820a56042d192bfa4e7d3493742.pdf)。支持第10页：封装内die-to-die物理层、协议/软件模型和合规测试；UCIe是互连标准，不是一种封装结构，也不代表所有Chiplet都采用它。
18. [IEEE HIR热管理](https://eps.ieee.org/images/files/HIR_2023/ch20_thermalfinal.pdf)、[IEEE HIR测试技术](https://eps.ieee.org/images/files/HIR_2024/HIR_2024_ch17_Test_Technology.pdf)。支持第9–10页：热、电源、热机械可靠性、KGD与互连测试等协同设计约束。没有添加无来源性能百分比或预测曲线。
19. [Intel 1999 Packaging Databook 第1章](https://www.intel.com/content/dam/www/public/us/en/documents/packaging-databooks/packaging--chapter-01-databook.pdf)。支持第1、5、10页：DIP、QFP、PGA、PBGA、CSP等方案并存；电气、热、机械、体积、可靠性与成本折中。

三种分类维度贯穿全篇：DIP/QFP/BGA描述外形与板级连接；引线键合/倒装描述裸片互连；SiP/Chiplet描述系统集成组织。各维度可组合，历史不是单一方案依次淘汰。
